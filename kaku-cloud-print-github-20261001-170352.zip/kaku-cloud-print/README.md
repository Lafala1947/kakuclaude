# 卡库云印 · 多材质卡片定制平台

React + TypeScript 前台与 Node.js 24 接口服务。五类费用（设计、印刷、纸张、后道工艺、物流）用 Excel 可打开的 CSV 管理；会员、产品、首页、会话、报价和订单保存在服务器私有文本文件中，不使用数据库。

云端印刷平台整体框架已加入：客户端按使用地区与生产需求找印厂，员工端查看接单到交付的业务全景。首期计划接入 6–10 家印厂或设备；真实入驻资料、印厂账号、独立报价与订单分派尚待接入。见 [平台框架说明](docs/云端印刷平台框架.md)。

## 本地运行

```powershell
npm ci
npm run build:server
npm run staff:create -- --email pricing@kaku.local --name 价格管理员 --group pricing --credentials-file data/local-accounts/pricing.credentials.txt
npm run staff:create -- --email sales@kaku.local --name 销售管理员 --group sales --credentials-file data/local-accounts/sales.credentials.txt
npm run staff:create -- --email pages@kaku.local --name 页面管理员 --group pages --credentials-file data/local-accounts/pages.credentials.txt
npm run dev
```

随机员工密码写入指定的本地私有文件，不打印到日志。创建员工时须停止 API。前台 http://127.0.0.1:5173/ ，后台 http://127.0.0.1:5173/#/admin 。Vite 将 /api 转发到本机 8787 端口；服务端代码修改后需重启开发命令。

## 数据联动

- 页面组发布产品、分类和上下架，产品中心及首页产品模块读取正式数据；产品身份贯穿报价和订单。
- 页面组编辑首页模块，先保存本地草稿、预览，再发布到服务器。
- 价格组维护 CSV 费用、工艺及加价率，发布后前台按服务器费率算价；后台可试算未发布草稿。
- 会员真实注册、登录并持久保存。销售组管理会员、等级、停用状态和订单。
- 会员等级初始全部原价；销售组保存的折扣只作用于制作费，设计和物流不打折。
- 下单时服务器检查报价有效性、文件归属、价格版本与幂等键。会员只能查自己的订单和文件；销售组管理全部订单。
- 销售组人工审核印品文件，退回后会员补稿重审；保留各版文件及审核记录，文件通过且订单确认后才能开始生产。见 [文件审核使用说明](docs/文件审核使用说明.md)。

首次数据种子位于 public/。初始费用**未发布、未设置加价率**，必须由价格组确认后才能报价。初始化后以私有 data/ 数据为准，不要将该目录放入网站公开目录。没有默认员工密码，会员注册不能选择后台权限。

## 页面

| 页面 | 路由 |
| --- | --- |
| 首页 / 产品中心 | / / #/products |
| 关于我们（内容来自 alabel.cn/about） | #/about |
| 在线报价 | #/quote |
| 注册 / 登录 / 我的订单 | #/register / #/login / #/orders |
| 后台入口 | #/admin |
| 客户选厂 / 印厂详情 | #/factories / #/factories/:factoryId |
| 云端工厂总览 / 模块框架 | #/admin/factory / #/admin/factory/:moduleId |
| 价格管理 | #/admin/pricing |
| 会员 / 订单管理 | #/admin/members / #/admin/orders |
| 文件审核工作台（销售组） | #/admin/reviews |
| 首页 / 产品管理 | #/admin/pages / #/admin/products |

## 构建与部署

```powershell
npm test
npm run build
```

产物 dist/ 为前台、server-dist/ 为接口程序。部署目录、HTTPS、systemd、Nginx 与备份见 [云服务器部署说明](docs/云服务器部署.md)。仅支持单台单进程写入私有文件，不启用多进程或多副本。

可选运行 `npm run build:static` 生成旧的静态预览：保留 CSV / JSON 导入导出和演示页面，不能保存真实会员或提交订单。见 [静态预览说明](docs/静态预览说明.md)。接口版不能只上传 dist 而省略服务端。

当前未接支付、短信、邮箱验证或快递追踪。注册邮箱作为登录标识，不代表已验证邮箱所有权。价格与工艺可用性由经营方确认，不是参考站真实费率。

