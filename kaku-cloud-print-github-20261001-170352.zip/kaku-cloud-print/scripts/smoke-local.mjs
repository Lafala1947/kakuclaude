import { readFile } from 'node:fs/promises';
import assert from 'node:assert/strict';

const origin = 'http://127.0.0.1:5173';
const call = (path, options = {}) => fetch(`${origin}/api${path}`, {
  ...options, headers: { Origin: origin, 'X-Kaku-Request': '1', ...options.headers },
});
assert.equal((await call('/health')).status, 200);
const pricing = await (await call('/config/pricing')).json();
assert.equal(pricing.data.published, false, '初始本地费用应由经营者确认发布');
for (const group of ['pricing', 'sales', 'pages']) {
  const credentials = JSON.parse(await readFile(`data/local-accounts/${group}.credentials.txt`, 'utf8'));
  const response = await call('/auth/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(credentials) });
  assert.equal(response.status, 200);
  assert.match(response.headers.get('set-cookie'), /HttpOnly/);
  const { user } = await response.json();
  assert.equal(user.group, group);
  const headers = { Cookie: response.headers.get('set-cookie').split(';')[0], 'X-Kaku-User-Id': user.id };
  assert.equal((await call('/members', { headers })).status, group === 'sales' ? 200 : 403);
  assert.equal((await call('/orders', { headers })).status, group === 'sales' ? 200 : 403);
  const review = await call('/orders/__smoke_missing_order__/file-review', { method: 'POST', headers: { ...headers, 'Content-Type': 'application/json' }, body: JSON.stringify({ revision: 1, decision: 'rejected', checks: [], comment: '接口存在性校验，无实际订单' }) });
  assert.equal(review.status, group === 'sales' ? 404 : 403, '审核接口应存在且仅销售组有权访问');
  assert.equal((await call('/auth/logout', { method: 'POST', headers })).status, 200);
  assert.equal((await (await call('/session', { headers: { Cookie: headers.Cookie } })).json()).user, null);
}
const front = await fetch(origin);
assert.equal(front.status, 200);
assert.match(await front.text(), /卡库云印/);
console.log('Local smoke passed: website, API proxy, three staff logins, RBAC, logout; initial pricing remains unpublished.');
