import { mkdir, access } from "node:fs/promises";
import { spawnSync } from "node:child_process";

// Explicit allowlist keeps private accounts, sessions, orders and uploaded files out of deployment archives.
const files = [
  "dist",
  "server-dist",
  "public",
  "deploy",
  "README.md",
  "docs/云服务器部署.md",
  "docs/文件审核使用说明.md",
  "docs/云端印刷平台框架.md",
];
await Promise.all(files.map((path) => access(path)));
await mkdir("release", { recursive: true });
const archive = "release/kaku-cloud-server.tar.gz";
const result = spawnSync("tar", ["-czf", archive, ...files], {
  stdio: "inherit",
});
if (result.error) throw result.error;
if (result.status !== 0) throw new Error("部署包创建失败");
console.log(`部署包已生成：${archive}（不含私有数据和密码）`);
