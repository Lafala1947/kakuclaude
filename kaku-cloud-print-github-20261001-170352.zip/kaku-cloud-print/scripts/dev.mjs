import { build } from "esbuild";
import { spawn } from "node:child_process";

await build({
  entryPoints: ["src/server/entry.ts"],
  outfile: "server-dist/entry.mjs",
  bundle: true,
  platform: "node",
  format: "esm",
  target: "node24",
});
const children = [
  spawn(process.execPath, ["server-dist/entry.mjs"], {
    stdio: ["inherit", "inherit", "inherit", "ipc"],
    env: process.env,
  }),
  spawn(
    process.execPath,
    ["node_modules/vite/bin/vite.js", "--host", "127.0.0.1"],
    { stdio: "inherit", env: process.env },
  ),
];
let closing = false;
function close(code = 0) {
  if (closing) return;
  closing = true;
  for (const child of children) {
    if (child.connected) child.send("shutdown");
    else child.kill();
  }
  process.exitCode = code;
}
for (const child of children) {
  child.on("error", (error) => {
    console.error(error.message);
    close(1);
  });
  child.on("exit", (code) => close(code ?? 0));
}
process.on("SIGINT", () => close());
process.on("SIGTERM", () => close());
