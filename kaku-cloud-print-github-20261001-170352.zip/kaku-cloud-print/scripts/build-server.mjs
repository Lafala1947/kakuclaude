import { build } from "esbuild";

await build({
  entryPoints: ["src/server/entry.ts", "src/server/cli.ts"],
  outdir: "server-dist",
  outExtension: { ".js": ".mjs" },
  platform: "node",
  target: "node24",
  format: "esm",
  bundle: true,
  sourcemap: true,
});
