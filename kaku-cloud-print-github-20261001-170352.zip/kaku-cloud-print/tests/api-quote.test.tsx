// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import { defaultConfig } from "../src/lib/config";
import { calculateQuote } from "../src/lib/pricing";
import { defaultInput } from "../src/shared/contracts";
import QuotePage from "../src/client/QuotePage";
const mocks = vi.hoisted(() => ({
  request: vi.fn(),
  user: { id: "member-1", role: "member" } as {
    id: string;
    role: string;
  } | null,
}));
vi.mock("../src/client/api/client", () => ({
  apiEnabled: true,
  apiRequest: mocks.request,
}));
vi.mock("../src/client/api/SessionContext", () => ({
  useSession: () => ({ user: mocks.user, loading: false }),
}));
const config = { ...defaultConfig, published: true, markup: 0.3 };
const product = {
  id: "thanks",
  code: "KK-P002",
  name: "感谢卡",
  categoryId: "paper",
  categoryName: "纸卡",
};
const serverQuote = {
  ...calculateQuote(defaultInput, config),
  total: 1234.56,
  quoteId: "quote-1",
  expiresAt: "2099-01-01T00:00:00Z",
  tier: "普通会员",
};
afterEach(() => {
  cleanup();
  mocks.request.mockReset();
  mocks.user = { id: "member-1", role: "member" };
});
describe("server quotation wiring", () => {
  it("sends specs and product identity and displays the authoritative server amount", async () => {
    mocks.request.mockResolvedValue(serverQuote);
    render(
      <MemoryRouter>
        <QuotePage config={config} product={product} />
      </MemoryRouter>,
    );
    fireEvent.click(screen.getByRole("button", { name: "算价" }));
    await screen.findByText("1,234.56");
    expect(mocks.request).toHaveBeenCalledWith(
      "/quotes",
      expect.objectContaining({
        method: "POST",
        body: JSON.stringify({ input: defaultInput, productId: "thanks" }),
      }),
    );
    expect(screen.getByRole("link", { name: "查看我的订单" })).toBeTruthy();
  });
  it("does not fall back to local pricing when the API fails", async () => {
    mocks.request.mockRejectedValue(new Error("费用版本已更改，请重试"));
    render(
      <MemoryRouter>
        <QuotePage config={config} />
      </MemoryRouter>,
    );
    fireEvent.click(screen.getByRole("button", { name: "算价" }));
    expect(await screen.findByRole("alert")).toHaveProperty(
      "textContent",
      "费用版本已更改，请重试",
    );
    expect(
      (screen.getByRole("button", { name: "生成报价单" }) as HTMLButtonElement)
        .disabled,
    ).toBe(true);
  });
  it("discards a pending quote and private order form when the member changes", async () => {
    let resolve!: (value: unknown) => void;
    mocks.request.mockImplementation(
      () =>
        new Promise((done) => {
          resolve = done;
        }),
    );
    const view = render(
      <MemoryRouter>
        <QuotePage config={config} />
      </MemoryRouter>,
    );
    fireEvent.click(screen.getByRole("button", { name: "算价" }));
    const signal = mocks.request.mock.calls[0][1].signal as AbortSignal;
    mocks.user = null;
    view.rerender(
      <MemoryRouter>
        <QuotePage config={config} />
      </MemoryRouter>,
    );
    resolve(serverQuote);
    await waitFor(() => expect(signal.aborted).toBe(true));
    expect(screen.queryByText("1,234.56")).toBeNull();
    expect(
      (screen.getByRole("button", { name: "立即下单" }) as HTMLButtonElement)
        .disabled,
    ).toBe(true);
    expect(
      screen.getByText("请先登录会员账号，再重新算价并提交订单。"),
    ).toBeTruthy();
  });
});
