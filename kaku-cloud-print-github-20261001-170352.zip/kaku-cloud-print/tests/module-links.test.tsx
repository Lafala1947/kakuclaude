// @vitest-environment jsdom
import {afterEach,describe,it,expect,vi} from 'vitest';
import {render,screen,fireEvent,cleanup,within} from '@testing-library/react';
import {MemoryRouter} from 'react-router-dom';
import App from '../src/client/App';
import {MemberProvider} from '../src/client/members/MemberContext';
import {serializeProducts,type ProductDocument} from '../src/shared/products';
import productFixture from './fixtures/products.json';
const defaultProducts = productFixture as ProductDocument;
import {defaultHomepage,serializeHomepage} from '../src/shared/homepage';
import {defaultConfig} from '../src/lib/config';
import {serializePricingCsv} from '../src/lib/csv';
const download=vi.hoisted(()=>vi.fn());
vi.mock('../src/client/utils',async()=>({...await vi.importActual('../src/client/utils'),download}));
afterEach(()=>{cleanup();vi.restoreAllMocks();download.mockReset();});
function setup(path:string,products=defaultProducts){
 vi.spyOn(globalThis,'fetch').mockImplementation(async input=>new Response(String(input).includes('products.json')?serializeProducts(products):String(input).includes('homepage.json')?serializeHomepage(defaultHomepage):serializePricingCsv({...structuredClone(defaultConfig),published:true,markup:.3})));
 return render(<MemoryRouter initialEntries={[path]}><MemberProvider><App/></MemberProvider></MemoryRouter>);
}
describe('product quotation data interface',()=>{
 it('carries product identity into the quotation and exported quote',async()=>{
  setup('/products/thanks');fireEvent.click(await screen.findByRole('link',{name:'纸质卡片通用报价'}));
  expect(await screen.findByText('当前产品：品牌感谢卡')).toBeTruthy();
  fireEvent.click(screen.getByRole('button',{name:'算价'}));fireEvent.click(screen.getByRole('button',{name:'生成报价单'}));
  const dialog=screen.getByRole('dialog');expect(within(dialog).getByText('KK-P002')).toBeTruthy();expect(within(dialog).getByText('品牌感谢卡')).toBeTruthy();
  fireEvent.click(within(dialog).getByRole('button',{name:'下载报价单'}));expect(download.mock.calls[0][0]).toContain('KK-P002');expect(download.mock.calls[0][0]).toContain('品牌感谢卡');
 });
 it.each(['missing','insert'])('rejects unavailable product %s instead of offering an unrelated price',async id=>{
  const data=structuredClone(defaultProducts);data.products[0].active=false;setup(`/quote?product=${id}`,data);
  expect(await screen.findByRole('heading',{name:'该产品暂不可报价'})).toBeTruthy();expect(screen.queryByRole('button',{name:'算价'})).toBeNull();
 });
 it('rejects showcase-only products and duplicate product parameters',async()=>{
  const data=structuredClone(defaultProducts);data.products[0].quoteMode='inquiry';const view=setup('/quote?product=insert',data);
  expect(await screen.findByRole('heading',{name:'该产品暂不可报价'})).toBeTruthy();view.unmount();
  setup('/quote?product=insert&product=thanks');expect(await screen.findByRole('heading',{name:'产品参数无效'})).toBeTruthy();
 });
 it('exports product names as spreadsheet text rather than formulas',async()=>{
  const data=structuredClone(defaultProducts);data.products[0].name='=1+1';setup('/quote?product=insert',data);
  await screen.findByRole('button',{name:'算价'});fireEvent.click(screen.getByRole('button',{name:'算价'}));fireEvent.click(screen.getByRole('button',{name:'生成报价单'}));fireEvent.click(screen.getByRole('button',{name:'下载报价单'}));
  expect(download.mock.calls[0][0]).toContain("'=1+1");
 });
});
