// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import {
  act,
  cleanup,
  fireEvent,
  render,
  renderHook,
  screen,
  waitFor,
} from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import {
  HomeContentProvider,
  useHomeContent,
} from "../src/client/content/HomeContentContext";
import PageAdmin from "../src/client/content/PageAdmin";
import {
  ProductsProvider,
  useProducts,
} from "../src/client/products/ProductsContext";
import ProductAdmin from "../src/client/products/ProductAdmin";
import AdminPage from "../src/client/AdminPage";
import { defaultHomepage } from "../src/shared/homepage";
import { defaultProducts } from "../src/shared/products";
import { defaultConfig } from "../src/lib/config";
import { DraftProvider } from "../src/client/DraftContext";
vi.mock("../src/client/api/client", async () => ({
  ...(await vi.importActual("../src/client/api/client")),
  apiEnabled: true,
}));
afterEach(() => {
  cleanup();
  localStorage.clear();
  vi.restoreAllMocks();
});
const response = (data: unknown, status = 200) =>
  new Response(JSON.stringify(data), { status });
function HomeState() {
  const { deployed, draft } = useHomeContent();
  return (
    <>
      <output data-testid="deployed">{deployed.modules[0].title}</output>
      <output data-testid="draft">{draft.modules[0].title}</output>
    </>
  );
}
function setupHome() {
  render(
    <MemoryRouter>
      <HomeContentProvider>
        <PageAdmin />
        <HomeState />
      </HomeContentProvider>
    </MemoryRouter>,
  );
}
it("publishes validated home content and immediately updates the storefront", async () => {
  let written: any;
  vi.spyOn(globalThis, "fetch").mockImplementation(async (_url, init) => {
    if (init?.method === "PUT") {
      written = JSON.parse(String(init.body));
      return response({ revision: "r2", data: written.data });
    }
    return response({ revision: "r1", data: defaultHomepage });
  });
  setupHome();
  fireEvent.change(await screen.findByLabelText("模块标题"), {
    target: { value: "已发布新首页" },
  });
  fireEvent.click(screen.getByRole("button", { name: "发布到服务器" }));
  await waitFor(() =>
    expect(screen.getByTestId("deployed").textContent).toBe("已发布新首页"),
  );
  expect(written.revision).toBe("r1");
});
it.each([500, 409])(
  "preserves homepage draft and deployed content on HTTP %s and requires deliberate reload",
  async (status) => {
    vi.spyOn(globalThis, "fetch").mockImplementation(async (_url, init) =>
      init?.method === "PUT"
        ? response({ error: "服务器拒绝" }, status)
        : response({ revision: "r1", data: defaultHomepage }),
    );
    setupHome();
    fireEvent.change(await screen.findByLabelText("模块标题"), {
      target: { value: "未发布草稿" },
    });
    fireEvent.click(screen.getByRole("button", { name: "发布到服务器" }));
    await screen.findByRole("alert");
    expect(screen.getByTestId("draft").textContent).toBe("未发布草稿");
    expect(screen.getByTestId("deployed").textContent).toBe(
      defaultHomepage.modules[0].title,
    );
    if (status === 409) {
      expect(screen.getByRole("alert").textContent).toContain(
        "加载服务器最新版本",
      );
      fireEvent.click(
        screen.getByRole("button", { name: "加载服务器最新版本" }),
      );
      expect(screen.getByTestId("draft").textContent).toBe("未发布草稿");
      fireEvent.click(
        screen.getByRole("button", { name: "确认加载并替换草稿" }),
      );
      await waitFor(() =>
        expect(screen.getByTestId("draft").textContent).toBe(
          defaultHomepage.modules[0].title,
        ),
      );
    }
  },
);
it("keeps edits made while a homepage publish is in flight", async () => {
  let finish!: (r: Response) => void;
  let published: any;
  vi.spyOn(globalThis, "fetch").mockImplementation(async (_url, init) => {
    if (init?.method === "PUT") {
      published = JSON.parse(String(init.body)).data;
      return new Promise((r) => {
        finish = r;
      });
    }
    return response({ revision: "r1", data: defaultHomepage });
  });
  setupHome();
  fireEvent.change(await screen.findByLabelText("模块标题"), {
    target: { value: "提交版本" },
  });
  fireEvent.click(screen.getByRole("button", { name: "发布到服务器" }));
  fireEvent.change(screen.getByLabelText("模块标题"), {
    target: { value: "继续编辑版本" },
  });
  await act(async () => finish(response({ revision: "r2", data: published })));
  expect(screen.getByTestId("draft").textContent).toBe("继续编辑版本");
  expect(screen.getByTestId("deployed").textContent).toBe("提交版本");
});
function ProductState() {
  const { deployed } = useProducts();
  return (
    <output data-testid="products">
      {deployed?.products[0].active ? "active" : "inactive"}
    </output>
  );
}
it("publishes product visibility to the storefront", async () => {
  vi.spyOn(globalThis, "fetch").mockImplementation(async (_url, init) =>
    response({
      revision: init?.method === "PUT" ? "r2" : "r1",
      data:
        init?.method === "PUT"
          ? JSON.parse(String(init.body)).data
          : defaultProducts,
    }),
  );
  render(
    <MemoryRouter>
      <ProductsProvider>
        <ProductAdmin />
        <ProductState />
      </ProductsProvider>
    </MemoryRouter>,
  );
  fireEvent.click(
    await screen.findByRole("button", {
      name: `下架 ${defaultProducts.products[0].name}`,
    }),
  );
  fireEvent.click(screen.getByRole("button", { name: "发布到服务器" }));
  await waitFor(() =>
    expect(screen.getByTestId("products").textContent).toBe("inactive"),
  );
});
it("publishes pricing with a revision then reloads the live pricing", async () => {
  let written: any;
  const reload = vi.fn().mockResolvedValue(undefined);
  vi.spyOn(globalThis, "fetch").mockImplementation(async (_url, init) => {
    if (init?.method === "PUT") {
      written = JSON.parse(String(init.body));
      return response({ revision: "r2", data: written.data });
    }
    return response({ revision: "r1", data: defaultConfig });
  });
  render(
    <MemoryRouter>
      <AdminPage deployed={defaultConfig} onReload={reload} />
    </MemoryRouter>,
  );
  await waitFor(() =>
    expect(
      (
        screen.getByRole("button", {
          name: "发布到服务器",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(false),
  );
  fireEvent.click(screen.getByRole("button", { name: "发布到服务器" }));
  await waitFor(() => expect(reload).toHaveBeenCalledOnce());
  expect(written.revision).toBe("r1");
  expect(written.data.version).toBe(defaultConfig.version + 1);
});
it.each([500, 409])(
  "retains edited pricing and does not refresh live pricing on failed publish %s",
  async (status) => {
    const reload = vi.fn().mockResolvedValue(undefined);
    vi.spyOn(globalThis, "fetch").mockImplementation(async (_url, init) =>
      init?.method === "PUT"
        ? response({ error: "未保存" }, status)
        : response({ revision: "r1", data: defaultConfig }),
    );
    render(
      <MemoryRouter>
        <AdminPage deployed={defaultConfig} onReload={reload} />
      </MemoryRouter>,
    );
    await waitFor(() =>
      expect(
        (
          screen.getByRole("button", {
            name: "发布到服务器",
          }) as HTMLButtonElement
        ).disabled,
      ).toBe(false),
    );
    fireEvent.click(screen.getByRole("button", { name: /设计费/ }));
    const field = screen.getByLabelText(/文件调整/);
    fireEvent.change(field, { target: { value: "123" } });
    fireEvent.click(screen.getByRole("button", { name: "发布到服务器" }));
    await screen.findByRole("alert");
    expect((field as HTMLInputElement).value).toBe("123");
    expect(reload).not.toHaveBeenCalled();
  },
);
it("blocks pricing publication when the loaded revision belongs to a newer config than the editor", async () => {
  vi.spyOn(globalThis, "fetch").mockResolvedValue(
    response({ revision: "r2", data: { ...defaultConfig, version: 2 } }),
  );
  render(
    <MemoryRouter>
      <AdminPage deployed={defaultConfig} onReload={async () => {}} />
    </MemoryRouter>,
  );
  await screen.findByText(/服务器配置已被其他人更新/);
  expect(
    (screen.getByRole("button", { name: "发布到服务器" }) as HTMLButtonElement)
      .disabled,
  ).toBe(true);
});
it("keeps the base pricing revision with the draft across editor remounts", async () => {
  let revision = "r1";
  vi.spyOn(globalThis, "fetch").mockImplementation(async () =>
    response({
      revision,
      data: { ...defaultConfig, version: revision === "r1" ? 1 : 2 },
    }),
  );
  function Workspace({ show }: { show: boolean }) {
    return (
      <MemoryRouter>
        <DraftProvider>
          {show && (
            <AdminPage deployed={defaultConfig} onReload={async () => {}} />
          )}
        </DraftProvider>
      </MemoryRouter>
    );
  }
  const view = render(<Workspace show />);
  await waitFor(() =>
    expect(
      (
        screen.getByRole("button", {
          name: "发布到服务器",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(false),
  );
  fireEvent.click(screen.getByRole("button", { name: /设计费/ }));
  fireEvent.change(screen.getByLabelText(/文件调整/), {
    target: { value: "88" },
  });
  view.rerender(<Workspace show={false} />);
  revision = "r2";
  view.rerender(<Workspace show />);
  await screen.findByText(/服务器配置已被其他人更新/);
  fireEvent.click(screen.getByRole("button", { name: /设计费/ }));
  expect((screen.getByLabelText(/文件调整/) as HTMLInputElement).value).toBe(
    "88",
  );
  expect(
    (screen.getByRole("button", { name: "发布到服务器" }) as HTMLButtonElement)
      .disabled,
  ).toBe(true);
});
it("requires applying product editor changes before publishing them", async () => {
  let written: any;
  vi.spyOn(globalThis, "fetch").mockImplementation(async (_url, init) => {
    if (init?.method === "PUT") {
      written = JSON.parse(String(init.body));
      return response({ revision: "r2", data: written.data });
    }
    return response({ revision: "r1", data: defaultProducts });
  });
  render(
    <MemoryRouter>
      <ProductsProvider>
        <ProductAdmin />
      </ProductsProvider>
    </MemoryRouter>,
  );
  fireEvent.click(
    await screen.findByRole("button", {
      name: `编辑 ${defaultProducts.products[0].name}`,
    }),
  );
  fireEvent.change(screen.getByLabelText("产品名称"), {
    target: { value: "新产品名称" },
  });
  expect(
    (screen.getByRole("button", { name: "发布到服务器" }) as HTMLButtonElement)
      .disabled,
  ).toBe(true);
  const unload = new Event("beforeunload", { cancelable: true });
  window.dispatchEvent(unload);
  expect(unload.defaultPrevented).toBe(true);
  fireEvent.click(screen.getByRole("button", { name: "保存产品到草稿" }));
  fireEvent.click(screen.getByRole("button", { name: "发布到服务器" }));
  await screen.findByText("已发布到服务器，公开内容已更新。");
  expect(written.data.products[0].name).toBe("新产品名称");
});
it("does not silently rebase a locally saved homepage draft from an old revision", async () => {
  const draft = structuredClone(defaultHomepage);
  draft.modules[0].title = "旧版本草稿";
  localStorage.setItem("kaku-homepage-draft-v1", JSON.stringify(draft));
  localStorage.setItem("kaku-homepage-draft-v1-revision", "r0");
  vi.spyOn(globalThis, "fetch").mockResolvedValue(
    response({ revision: "r1", data: defaultHomepage }),
  );
  setupHome();
  await screen.findByText(/服务器配置已被其他人更新/);
  expect(screen.getByTestId("draft").textContent).toBe("旧版本草稿");
  expect(
    (screen.getByRole("button", { name: "发布到服务器" }) as HTMLButtonElement)
      .disabled,
  ).toBe(true);
});
it("ignores an initial configuration read that returns after an explicit fresh reload", async () => {
  let oldResponse!: (r: Response) => void;
  const fresh = structuredClone(defaultHomepage);
  fresh.modules[0].title = "最新首页";
  vi.spyOn(globalThis, "fetch")
    .mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          oldResponse = resolve;
        }),
    )
    .mockResolvedValueOnce(response({ revision: "r2", data: fresh }));
  const view = renderHook(() => useHomeContent(), {
    wrapper: HomeContentProvider,
  });
  await act(async () => {
    await view.result.current.reload?.();
  });
  expect(view.result.current.deployed.modules[0].title).toBe("最新首页");
  await act(async () =>
    oldResponse(response({ revision: "r1", data: defaultHomepage })),
  );
  expect(view.result.current.deployed.modules[0].title).toBe("最新首页");
  expect(view.result.current.draft.modules[0].title).toBe("最新首页");
});
it("retains an old pricing draft revision restored while the initial GET is still pending", async () => {
  let finish!: (r: Response) => void;
  vi.spyOn(globalThis, "fetch")
    .mockImplementationOnce(
      () =>
        new Promise((resolve) => {
          finish = resolve;
        }),
    )
    .mockImplementation(async () =>
      response({ revision: "r1", data: defaultConfig }),
    );
  localStorage.setItem(
    "yinhao-pricing-draft-v1",
    JSON.stringify({ ...defaultConfig, design: { adjust: 88, custom: 0 } }),
  );
  localStorage.setItem("yinhao-pricing-draft-v1-revision", "r0");
  function Workspace({ show }: { show: boolean }) {
    return (
      <MemoryRouter>
        <DraftProvider>
          {show && (
            <AdminPage deployed={defaultConfig} onReload={async () => {}} />
          )}
        </DraftProvider>
      </MemoryRouter>
    );
  }
  const view = render(<Workspace show />);
  fireEvent.click(screen.getByRole("button", { name: "恢复本机草稿" }));
  await act(async () =>
    finish(response({ revision: "r1", data: defaultConfig })),
  );
  view.rerender(<Workspace show={false} />);
  view.rerender(<Workspace show />);
  await screen.findByText(/服务器配置已被其他人更新/);
  expect(
    (screen.getByRole("button", { name: "发布到服务器" }) as HTMLButtonElement)
      .disabled,
  ).toBe(true);
});
