// @vitest-environment jsdom
import { afterEach, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen, within } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import FactoryDirectory from '../src/client/factory/FactoryDirectory';
import { matchesFactory, parseFactoryDirectory, type PrintFactory } from '../src/shared/factories';
const factory: PrintFactory = {
  id: 'factory-a', name: '测试工厂', kind: 'factory', operator: '测试承接公司', active: true,
  address: '测试工业园', description: '测试用资料',
  regions: [{ province: '广东省', city: '深圳市', district: '南山区' }],
  materials: ['paper'], crafts: ['lamination', 'diecut'], equipment: ['测试印刷机'],
};
afterEach(() => { cleanup(); vi.restoreAllMocks(); });
it('requires matching region, material and every requested craft, without treating missing capabilities as available', () => {
  const query = { province: '广东省', city: '深圳市', district: '南山区', material: 'paper', crafts: ['lamination'] };
  expect(matchesFactory(factory, query)).toBe(true);
  expect(matchesFactory(factory, { ...query, district: '福田区' })).toBe(false);
  expect(matchesFactory(factory, { ...query, material: 'pvc' })).toBe(false);
  expect(matchesFactory(factory, { ...query, crafts: ['lamination', 'foil'] })).toBe(false);
  expect(matchesFactory({ ...factory, active: false }, query)).toBe(false);
  expect(matchesFactory({ ...factory, regions: [{ ...factory.regions[0], district: '*' }] }, query)).toBe(true);
});
it('rejects duplicate IDs and equipment without a responsible operator', () => {
  expect(() => parseFactoryDirectory(JSON.stringify({ version: 1, factories: [factory, factory] }))).toThrow();
  expect(() => parseFactoryDirectory(JSON.stringify({ version: 1, factories: [{ ...factory, kind: 'equipment', operator: '' }] }))).toThrow();
});
function setup(factories: PrintFactory[] = [], path = '/factories') {
  vi.spyOn(globalThis, 'fetch').mockResolvedValue(new Response(JSON.stringify({ version: 1, factories })));
  render(<MemoryRouter initialEntries={[path]}><Routes><Route path="/factories/:factoryId?" element={<FactoryDirectory />} /></Routes></MemoryRouter>);
}
it('shows an honest onboarding empty state with no invented factory records', async () => {
  setup();
  expect(await screen.findByText('首批印厂正在接入')).toBeTruthy();
  expect(screen.queryByRole('link', { name: /选择此印厂/ })).toBeNull();
});
it('filters before choosing a factory and preserves the usage area on the detail route', async () => {
  setup([factory]);
  await screen.findByText('填写使用地区后查看匹配印厂');
  fireEvent.change(screen.getByLabelText('省 / 直辖市'), { target: { value: '广东省' } });
  fireEvent.change(screen.getByLabelText('城市'), { target: { value: '深圳市' } });
  fireEvent.change(screen.getByLabelText('区 / 县'), { target: { value: '南山区' } });
  fireEvent.change(screen.getByLabelText('卡片材质'), { target: { value: 'paper' } });
  fireEvent.click(screen.getByRole('button', { name: '查找可承接印厂' }));
  fireEvent.click(await screen.findByRole('link', { name: '选择此印厂' }));
  expect(screen.getByRole('heading', { name: '测试工厂' })).toBeTruthy();
  expect(within(screen.getByRole('complementary')).getByText('广东省 / 深圳市 / 南山区')).toBeTruthy();
  expect(screen.getByRole('button', { name: '该印厂报价下单待开通' }).hasAttribute('disabled')).toBe(true);
});
it('does not show a paused factory through a direct detail link', async () => {
  setup([{ ...factory, active: false }], '/factories/factory-a');
  expect(await screen.findByRole('heading', { name: '该印厂暂不可选' })).toBeTruthy();
});
it('distinguishes a failed load from an empty directory', async () => {
  vi.spyOn(globalThis, 'fetch').mockRejectedValue(new Error('network failed'));
  render(<MemoryRouter><FactoryDirectory /></MemoryRouter>);
  expect(await screen.findByRole('alert')).toBeTruthy();
  expect(screen.queryByText('首批印厂正在接入')).toBeNull();
});
it('preserves draft and submitted criteria when switching map and list views', async () => {
  setup([factory]);
  await screen.findByRole('region', { name: '印厂位置地图' });
  fireEvent.change(screen.getByLabelText('省 / 直辖市'), { target: { value: '广东省' } });
  fireEvent.click(screen.getByRole('button', { name: '列表显示' }));
  expect((screen.getByLabelText('省 / 直辖市') as HTMLInputElement).value).toBe('广东省');
  expect(screen.queryByRole('region', { name: '印厂位置地图' })).toBeNull();
  fireEvent.change(screen.getByLabelText('城市'), { target: { value: '深圳市' } });
  fireEvent.change(screen.getByLabelText('区 / 县'), { target: { value: '南山区' } });
  fireEvent.change(screen.getByLabelText('卡片材质'), { target: { value: 'paper' } });
  fireEvent.click(screen.getByRole('button', { name: '查找可承接印厂' }));
  expect(screen.getByRole('link', { name: '选择此印厂' }).getAttribute('href')).toContain('view=list');
  fireEvent.click(screen.getByRole('button', { name: '地图显示' }));
  expect(screen.getByRole('region', { name: '印厂位置地图' })).toBeTruthy();
  expect(screen.getByRole('link', { name: '选择此印厂' }).getAttribute('href')).toContain('material=paper');
});
