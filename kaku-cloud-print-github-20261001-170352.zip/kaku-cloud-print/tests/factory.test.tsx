// @vitest-environment jsdom
import { afterEach, expect, it, vi } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { MemoryRouter, Route, Routes } from 'react-router-dom';
import { AdminAccessProvider, AdminGuard } from '../src/client/admin/AdminAccess';
import FactoryWorkspace from '../src/client/factory/FactoryWorkspace';
const state = vi.hoisted(() => ({ group: 'sales' as string | null, role: 'staff', loading: false, error: '' }));
vi.mock('../src/client/api/client', () => ({ apiEnabled: true }));
vi.mock('../src/client/api/SessionContext', () => ({ useSession: () => ({
  user: state.group ? { role: state.role, group: state.group } : null,
  loading: state.loading, error: state.error, refresh: vi.fn(), logout: vi.fn(),
}) }));
afterEach(() => { cleanup(); state.group = 'sales'; state.role = 'staff'; state.loading = false; state.error = ''; });
function setup(path = '/admin/factory') {
  return render(<MemoryRouter initialEntries={[path]}><AdminAccessProvider><Routes>
    <Route path="/admin/factory/:moduleId?" element={<AdminGuard><FactoryWorkspace /></AdminGuard>} />
  </Routes></AdminAccessProvider></MemoryRouter>);
}
it('connects the overview to module plans and their adjacent stages', () => {
  setup();
  expect(screen.getByRole('heading', { name: '云端印刷工厂' })).toBeTruthy();
  fireEvent.click(screen.getAllByRole('link', { name: /生产计划/ })[0]);
  expect(screen.getByRole('heading', { level: 1, name: '生产计划' })).toBeTruthy();
  expect(screen.getByText('功能待建设，当前仅展示模块框架。')).toBeTruthy();
  expect(screen.getByText('审核通过的文件版本、订单规格、数量与交期')).toBeTruthy();
  expect(screen.getByRole('link', { name: /下一环节.*车间生产/ }).getAttribute('href')).toBe('/admin/factory/production');
});
it.each(['pricing', 'pages', 'sales'])('only exposes authorized operational shortcuts for %s', (group) => {
  state.group = group;
  setup('/admin/factory/intake');
  const links = screen.getAllByRole('link').map(link => link.getAttribute('href'));
  expect(links.includes('/admin/orders')).toBe(group === 'sales');
  expect(links.includes('/admin/pricing')).toBe(group === 'pricing');
  expect(links.includes('/admin/products')).toBe(group === 'pages');
});
it('keeps review details deferred while linking the existing review module', () => {
  setup('/admin/factory/prepress');
  expect(screen.getByText('基础流程已接入，审核细则后续完善。')).toBeTruthy();
  expect(screen.getAllByRole('link').some(link => link.getAttribute('href') === '/admin/reviews')).toBe(true);
});
it.each(['anonymous', 'member', 'loading', 'error'])('does not expose the workspace during %s identity state', (kind) => {
  if (kind === 'anonymous') state.group = null;
  if (kind === 'member') state.role = 'member';
  if (kind === 'loading') state.loading = true;
  if (kind === 'error') state.error = '身份服务暂不可用';
  setup();
  expect(screen.queryByRole('heading', { name: '云端印刷工厂' })).toBeNull();
});
it('provides a recovery route for unknown modules', () => {
  setup('/admin/factory/missing');
  expect(screen.getByRole('heading', { name: '模块不存在' })).toBeTruthy();
  expect(screen.getByRole('link', { name: '返回工厂总览' }).getAttribute('href')).toBe('/admin/factory');
});
