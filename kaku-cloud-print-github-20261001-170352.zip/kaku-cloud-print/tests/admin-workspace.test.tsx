// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
  within,
  act,
} from "@testing-library/react";
import { MemoryRouter, useNavigate } from "react-router-dom";
import App from "../src/client/App";
import { MemberProvider } from "../src/client/members/MemberContext";
import { DraftProvider } from "../src/client/DraftContext";
import {
  defaultHomepage,
  parseHomepage,
  serializeHomepage,
  newItem,
  newModule,
} from "../src/shared/homepage";
import { serializePricingCsv } from "../src/lib/csv";
import { defaultConfig } from "../src/lib/config";

const download = vi.hoisted(() => vi.fn());
vi.mock("../src/client/utils", async () => ({
  ...(await vi.importActual("../src/client/utils")),
  download,
}));
afterEach(() => {
  cleanup();
  localStorage.clear();
  vi.restoreAllMocks();
  download.mockReset();
});
function Jump() {
  const go = useNavigate();
  return <button onClick={() => go("/admin/pages")}>直接访问页面管理</button>;
}
function setup(
  path = "/admin",
  pricingFails = false,
  publishedHome = defaultHomepage,
  homeResponse?: Promise<Response>,
) {
  vi.spyOn(globalThis, "fetch").mockImplementation(async (input) =>
    String(input).includes("homepage.json")
      ? (homeResponse ?? new Response(serializeHomepage(publishedHome)))
      : pricingFails
        ? Promise.reject(new Error("offline"))
        : new Response(serializePricingCsv(defaultConfig)),
  );
  return render(
    <MemoryRouter initialEntries={[path]}>
      <DraftProvider>
        <MemberProvider>
          <App />
          <Jump />
        </MemberProvider>
      </DraftProvider>
    </MemoryRouter>,
  );
}
describe("homepage document contract", () => {
  it("refuses a formatted export that exceeds the import size limit", () => {
    const document = structuredClone(defaultHomepage);
    document.modules = Array.from({ length: 10 }, (_, m) => ({
      ...structuredClone(defaultHomepage.modules[2]),
      id: `module-${m}`,
      items: Array.from({ length: 20 }, (_, i) => ({
        ...structuredClone(defaultHomepage.modules[2].items[0]),
        id: `item-${m}-${i}`,
        text: "",
      })),
    }));
    const length = Math.floor(
      (499900 - new TextEncoder().encode(JSON.stringify(document)).length) /
        200,
    );
    for (const module of document.modules)
      for (const item of module.items) item.text = "a".repeat(length);
    expect(() => parseHomepage(JSON.stringify(document))).not.toThrow();
    expect(() => serializeHomepage(document)).toThrow(/500 KB/);
  });
  it("can create content on HTTP hosts without randomUUID", () => {
    vi.spyOn(crypto, "randomUUID").mockImplementation(undefined as never);
    Object.defineProperty(crypto, "randomUUID", {
      value: undefined,
      configurable: true,
    });
    const item = newItem(),
      module = newModule("products");
    expect(item.id).toBeTruthy();
    expect(module.id).toBeTruthy();
    expect(
      new Set([item.id, module.id, ...module.items.map((i) => i.id)]).size,
    ).toBe(5);
  });
  it("round trips modules and rejects unsafe or broken documents", () => {
    expect(parseHomepage(serializeHomepage(defaultHomepage))).toEqual(
      defaultHomepage,
    );
    const bad = structuredClone(defaultHomepage);
    bad.modules[0].actionHref = "javascript:alert(1)";
    expect(() => parseHomepage(JSON.stringify(bad))).toThrow(/链接/);
    bad.modules[0].actionHref = "/quote";
    bad.modules[0].image = "data:image/svg+xml,<svg/>";
    expect(() => parseHomepage(JSON.stringify(bad))).toThrow(/图片/);
    expect(() => parseHomepage("{bad")).toThrow();
    expect(() =>
      parseHomepage(JSON.stringify({ ...defaultHomepage, modules: [] })),
    ).toThrow();
    expect(() =>
      parseHomepage(
        JSON.stringify({
          ...defaultHomepage,
          modules: defaultHomepage.modules.map((m) => ({
            ...m,
            enabled: false,
          })),
        }),
      ),
    ).toThrow(/显示/);
    expect(() =>
      parseHomepage(
        JSON.stringify({
          ...defaultHomepage,
          modules: [defaultHomepage.modules[0], defaultHomepage.modules[0]],
        }),
      ),
    ).toThrow(/重复/);
  });
});
describe("group administration and homepage editing", () => {
  it("prevents saving or exporting defaults while the deployed homepage is still loading", async () => {
    let complete!: (value: Response) => void;
    const loading = new Promise<Response>((resolve) => {
      complete = resolve;
    });
    setup("/admin", false, defaultHomepage, loading);
    fireEvent.click(screen.getByRole("button", { name: "进入页面组" }));
    expect(
      (
        screen.getByRole("button", {
          name: "保存本地草稿",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
    expect(
      (
        screen.getByRole("button", {
          name: "下载首页配置",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
    expect(
      (screen.getByRole("button", { name: "预览草稿" }) as HTMLButtonElement)
        .disabled,
    ).toBe(true);
    const published = structuredClone(defaultHomepage);
    published.modules[0].title = "服务器上的新内容";
    await act(async () => {
      complete(new Response(serializeHomepage(published)));
    });
    expect(
      ((await screen.findByLabelText("模块标题")) as HTMLTextAreaElement).value,
    ).toBe("服务器上的新内容");
    expect(localStorage.getItem("kaku-homepage-draft-v1")).toBeNull();
  });
  it("loads published homepage content from its text configuration", async () => {
    const published = structuredClone(defaultHomepage);
    published.modules[0].title = "已发布的卡片首页";
    setup("/", false, published);
    expect(
      await screen.findByRole("heading", {
        level: 1,
        name: "已发布的卡片首页",
      }),
    ).toBeTruthy();
  });
  it("warns before leaving with unsaved edits and clears the warning after saving", async () => {
    setup();
    fireEvent.click(screen.getByRole("button", { name: "进入页面组" }));
    await screen.findByLabelText("模块标题");
    fireEvent.change(screen.getByLabelText("模块标题"), {
      target: { value: "需要保存" },
    });
    const dirtyEvent = new Event("beforeunload", { cancelable: true });
    window.dispatchEvent(dirtyEvent);
    expect(dirtyEvent.defaultPrevented).toBe(true);
    fireEvent.click(screen.getByRole("button", { name: "保存本地草稿" }));
    const savedEvent = new Event("beforeunload", { cancelable: true });
    window.dispatchEvent(savedEvent);
    expect(savedEvent.defaultPrevented).toBe(false);
  });
  it("does not render unsafe draft links in preview", async () => {
    setup();
    fireEvent.click(screen.getByRole("button", { name: "进入页面组" }));
    await screen.findByLabelText("模块标题");
    fireEvent.change(screen.getByLabelText("主按钮链接"), {
      target: { value: "javascript:alert(1)" },
    });
    fireEvent.click(screen.getByRole("link", { name: "预览草稿" }));
    expect(
      screen.getByRole("heading", { name: "草稿需要修正后再预览" }),
    ).toBeTruthy();
    expect(screen.queryByRole("link", { name: "开始在线报价" })).toBeNull();
  });
  it("allows sales with a broken pricing file, and blocks access after exit", async () => {
    setup("/admin", true);
    fireEvent.click(screen.getByRole("button", { name: "进入销售组" }));
    expect(await screen.findByText("演示客户 01")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "退出管理组" }));
    expect(screen.queryByText("演示客户 01")).toBeNull();
    expect(
      screen.getByRole("heading", { name: "请选择后台管理组" }),
    ).toBeTruthy();
  });
  it("restores a local draft without exposing it on the public homepage", async () => {
    const local = structuredClone(defaultHomepage);
    local.modules[0].title = "本地未发布内容";
    localStorage.setItem("kaku-homepage-draft-v1", serializeHomepage(local));
    setup();
    fireEvent.click(screen.getByRole("button", { name: "进入页面组" }));
    await screen.findByLabelText("模块标题");
    expect(
      (screen.getByLabelText("模块标题") as HTMLTextAreaElement).value,
    ).toBe("本地未发布内容");
    fireEvent.click(screen.getByRole("link", { name: "卡库云印首页" }));
    expect(
      screen.queryByRole("heading", { name: "本地未发布内容" }),
    ).toBeNull();
    expect(
      screen.getByRole("heading", { level: 1, name: /多材质卡片/ }),
    ).toBeTruthy();
  });
  it("reports storage failure without losing edits or claiming they were saved", async () => {
    setup();
    fireEvent.click(screen.getByRole("button", { name: "进入页面组" }));
    await screen.findByLabelText("模块标题");
    fireEvent.change(screen.getByLabelText("模块标题"), {
      target: { value: "待保存内容" },
    });
    vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => {
      throw new Error("存储空间不足");
    });
    fireEvent.click(screen.getByRole("button", { name: "保存本地草稿" }));
    expect(screen.getByRole("alert").textContent).toContain("存储空间不足");
    expect(
      (screen.getByLabelText("模块标题") as HTMLTextAreaElement).value,
    ).toBe("待保存内容");
  });
  it("rejects malformed imports and applies a valid import only after confirmation", async () => {
    setup();
    fireEvent.click(screen.getByRole("button", { name: "进入页面组" }));
    const title = (await screen.findByLabelText(
      "模块标题",
    )) as HTMLTextAreaElement;
    fireEvent.change(screen.getByLabelText("导入首页配置文件"), {
      target: { files: [{ size: 10, text: async () => "{broken" }] },
    });
    expect(await screen.findByRole("alert")).toBeTruthy();
    expect(title.value).toContain("多材质卡片");
    const imported = structuredClone(defaultHomepage);
    imported.modules[0].title = "导入的新首页";
    fireEvent.change(screen.getByLabelText("导入首页配置文件"), {
      target: {
        files: [{ size: 100, text: async () => serializeHomepage(imported) }],
      },
    });
    await screen.findByRole("button", { name: "确认导入配置" });
    expect(title.value).toContain("多材质卡片");
    fireEvent.click(screen.getByRole("button", { name: "确认导入配置" }));
    expect(
      (screen.getByLabelText("模块标题") as HTMLTextAreaElement).value,
    ).toBe("导入的新首页");
    fireEvent.click(screen.getByRole("button", { name: "下载首页配置" }));
    expect(parseHomepage(download.mock.calls[0][0])).toEqual(imported);
  });
  it("can edit, add, reorder and remove content items", async () => {
    setup();
    fireEvent.click(screen.getByRole("button", { name: "进入页面组" }));
    await screen.findByLabelText("模块标题");
    fireEvent.click(
      screen.getByRole("button", { name: "选择模块 面向不同应用的卡片方案" }),
    );
    fireEvent.click(screen.getByRole("button", { name: "新增条目" }));
    fireEvent.change(screen.getByLabelText("条目 4 标题"), {
      target: { value: "会员卡应用" },
    });
    fireEvent.click(screen.getByRole("button", { name: "条目 4 上移" }));
    fireEvent.click(screen.getByRole("button", { name: "删除条目 1" }));
    fireEvent.click(screen.getByRole("button", { name: "下载首页配置" }));
    const items = parseHomepage(download.mock.calls[0][0]).modules.find(
      (m) => m.type === "products",
    )!.items;
    expect(items).toHaveLength(3);
    expect(items[1].title).toBe("会员卡应用");
  });
  it("blocks direct URLs without a role and cross-group routes after entry", async () => {
    setup("/admin/members");
    expect(
      screen.getByRole("heading", { name: "请选择后台管理组" }),
    ).toBeTruthy();
    fireEvent.click(screen.getByRole("link", { name: "返回后台入口" }));
    fireEvent.click(screen.getByRole("button", { name: "进入价格组" }));
    expect(
      await screen.findByText("费用表管理", { selector: "b" }),
    ).toBeTruthy();
    const nav = screen.getByRole("navigation", { name: "后台管理模块" });
    expect(within(nav).queryByRole("link", { name: /会员管理/ })).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "直接访问页面管理" }));
    expect(
      screen.getByRole("heading", { name: "当前组无权访问此模块" }),
    ).toBeTruthy();
  });
  it("edits draft modules, previews and exports without changing public home", async () => {
    setup();
    fireEvent.click(screen.getByRole("button", { name: "进入页面组" }));
    await screen.findByLabelText("模块标题");
    fireEvent.change(screen.getByLabelText("模块标题"), {
      target: { value: "定制你的品牌卡片" },
    });
    fireEvent.click(screen.getByRole("button", { name: "保存本地草稿" }));
    expect(localStorage.getItem("kaku-homepage-draft-v1")).toContain(
      "定制你的品牌卡片",
    );
    fireEvent.click(screen.getByRole("button", { name: "下载首页配置" }));
    expect(download.mock.calls[0][1]).toBe("homepage.json");
    expect(parseHomepage(download.mock.calls[0][0]).modules[0].title).toBe(
      "定制你的品牌卡片",
    );
    fireEvent.click(screen.getByRole("link", { name: "预览草稿" }));
    expect(
      screen.getByRole("heading", { level: 1, name: "定制你的品牌卡片" }),
    ).toBeTruthy();
    fireEvent.click(screen.getByRole("link", { name: "卡库云印首页" }));
    expect(
      screen.getByRole("heading", { level: 1, name: /多材质卡片/ }),
    ).toBeTruthy();
  });
  it("supports module creation, ordering, hiding and confirmed deletion", async () => {
    setup();
    fireEvent.click(screen.getByRole("button", { name: "进入页面组" }));
    await screen.findByLabelText("模块标题");
    fireEvent.click(screen.getByRole("button", { name: "新增模块" }));
    fireEvent.change(screen.getByLabelText("模块标题"), {
      target: { value: "新材料介绍" },
    });
    fireEvent.click(screen.getByRole("button", { name: "模块上移" }));
    fireEvent.click(screen.getByLabelText("在首页显示"));
    fireEvent.click(screen.getByRole("button", { name: "下载首页配置" }));
    const document = parseHomepage(download.mock.calls[0][0]);
    expect(document.modules.at(-2)?.title).toBe("新材料介绍");
    expect(document.modules.at(-2)?.enabled).toBe(false);
    fireEvent.click(screen.getByRole("button", { name: "删除模块" }));
    fireEvent.click(screen.getByRole("button", { name: "确认删除模块" }));
    expect(
      screen.queryByRole("button", { name: /选择模块 新材料介绍/ }),
    ).toBeNull();
  });
});
