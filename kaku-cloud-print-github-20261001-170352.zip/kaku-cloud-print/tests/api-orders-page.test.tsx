// @vitest-environment jsdom
import { afterEach, expect, it, vi } from "vitest";
import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import OrdersPage from "../src/client/order/OrdersPage";
import type { SessionUser } from "../src/shared/api";
const mocked = vi.hoisted(() => ({
  request: vi.fn(),
  user: { id: "sales1", role: "staff", group: "sales" } as SessionUser | null,
}));
vi.mock("../src/client/api/client", () => ({
  apiEnabled: true,
  apiRequest: mocked.request,
  apiFileUrl: (id: string) => `/api/files/${id}`,
}));
vi.mock("../src/client/api/SessionContext", () => ({
  useSession: () => ({ user: mocked.user, loading: false }),
}));
const order = {
  id: "order123",
  memberId: "member1",
  createdAt: "2026-10-01T00:00:00Z",
  status: "submitted",
  quote: { total: 200, totalQuantity: 500, input: { width: 90, height: 54 } },
  orderName: "首单印刷",
  notes: "",
  contact: "测试联系",
  recipient: {
    name: "张三",
    phone: "13800138000",
    region: "广东",
    address: "测试路1号",
  },
  files: [{ id: "file1", name: "卡片.pdf", kind: "print", size: 20 }],
};
afterEach(() => {
  cleanup();
  mocked.request.mockReset();
  mocked.user = { id: "sales1", role: "staff", group: "sales" } as SessionUser;
});
it("displays orders and attachment URLs fetched under the signed-in session", async () => {
  mocked.request.mockResolvedValue({ orders: [order] });
  render(
    <MemoryRouter>
      <OrdersPage admin />
    </MemoryRouter>,
  );
  expect(await screen.findByRole("heading", { name: "首单印刷" })).toBeTruthy();
  expect(
    screen.getByRole("link", { name: "印品 · 卡片.pdf" }).getAttribute("href"),
  ).toBe("/api/files/file1");
  fireEvent.change(screen.getByPlaceholderText("订单编号、名称、联系人"), {
    target: { value: "不存在" },
  });
  expect(screen.queryByText("张三")).toBeNull();
  expect(screen.getByText("没有匹配的订单")).toBeTruthy();
});
it("preserves the previous status if saving is rejected", async () => {
  mocked.request.mockImplementation((_path, options) =>
    options?.method === "PATCH"
      ? Promise.reject(new Error("无权更改状态"))
      : Promise.resolve({ orders: [order] }),
  );
  render(
    <MemoryRouter>
      <OrdersPage admin />
    </MemoryRouter>,
  );
  const select = (await screen.findByLabelText(
    "订单 order123 状态",
  )) as HTMLSelectElement;
  fireEvent.change(select, { target: { value: "producing" } });
  expect(await screen.findByRole("alert")).toHaveProperty(
    "textContent",
    "无权更改状态",
  );
  expect(select.value).toBe("submitted");
  expect(mocked.request).toHaveBeenCalledWith("/orders/order123", {
    method: "PATCH",
    body: JSON.stringify({ status: "producing" }),
  });
});
it("clears private orders on sign-out and ignores a late response", async () => {
  let done!: (value: unknown) => void;
  mocked.request.mockImplementation(
    () =>
      new Promise((resolve) => {
        done = resolve;
      }),
  );
  const view = render(
    <MemoryRouter>
      <OrdersPage admin />
    </MemoryRouter>,
  );
  const signal = mocked.request.mock.calls[0][1].signal as AbortSignal;
  mocked.user = null;
  view.rerender(
    <MemoryRouter>
      <OrdersPage admin />
    </MemoryRouter>,
  );
  done({ orders: [order] });
  await waitFor(() => expect(signal.aborted).toBe(true));
  expect(screen.queryByText("首单印刷")).toBeNull();
  expect(screen.getByRole("heading", { name: "请先登录" })).toBeTruthy();
});
it("lets a member recover and deliberately remove an abandoned upload", async () => {
  mocked.user = { id: "member1", role: "member", group: null } as SessionUser;
  mocked.request.mockImplementation((path, options) =>
    Promise.resolve(
      path === "/orders"
        ? { orders: [] }
        : options?.method === "DELETE"
          ? { ok: true }
          : {
              files: [
                {
                  id: "unused",
                  name: "未提交.pdf",
                  kind: "print",
                  size: 30,
                  createdAt: "2026-10-01T00:00:00Z",
                },
              ],
            },
    ),
  );
  render(
    <MemoryRouter>
      <OrdersPage />
    </MemoryRouter>,
  );
  expect(await screen.findByRole("link", { name: "未提交.pdf" })).toBeTruthy();
  fireEvent.click(screen.getByRole("button", { name: "删除 未提交.pdf" }));
  expect(
    mocked.request.mock.calls.some((call) => call[1]?.method === "DELETE"),
  ).toBe(false);
  fireEvent.click(screen.getByRole("button", { name: "确认删除文件" }));
  await waitFor(() =>
    expect(screen.queryByRole("link", { name: "未提交.pdf" })).toBeNull(),
  );
  expect(mocked.request).toHaveBeenCalledWith("/files/unused", {
    method: "DELETE",
  });
});
