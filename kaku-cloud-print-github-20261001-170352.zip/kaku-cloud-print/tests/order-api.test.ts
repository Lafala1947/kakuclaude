import { afterEach, describe, expect, it, vi } from "vitest";
import { apiOrderGateway } from "../src/client/order/apiGateway";
import { defaultInput } from "../src/shared/contracts";
import { calculateQuote } from "../src/lib/pricing";
import { defaultConfig } from "../src/lib/config";
const quote = () => ({
  ...calculateQuote(defaultInput, {
    ...defaultConfig,
    published: true,
    markup: 0.3,
  }),
  quoteId: "q_verified",
  expiresAt: "2099-01-01T00:00:00Z",
});
afterEach(() => vi.restoreAllMocks());
describe("real order adapter", () => {
  it("submits the server quote ID instead of trusting browser totals", async () => {
    const fetcher = vi
      .spyOn(globalThis, "fetch")
      .mockResolvedValue(new Response(JSON.stringify({ orderId: "order_1" })));
    const result = await apiOrderGateway.submit(
      {
        quote: { ...quote(), total: 0.01 },
        recipient: {
          name: "测试",
          phone: "13800138000",
          region: "广东",
          address: "测试地址",
        },
        contact: "test@example.com",
        orderName: "测试订单",
        notes: "",
        files: { print: ["file_1"], proof: [], certificate: [] },
      },
      "retry-key",
      new AbortController().signal,
    );
    expect(result.orderId).toBe("order_1");
    const options = fetcher.mock.calls[0][1]!;
    expect(JSON.parse(options.body as string)).toMatchObject({
      quoteId: "q_verified",
    });
    expect(JSON.parse(options.body as string)).not.toHaveProperty("quote");
    expect(new Headers(options.headers).get("Idempotency-Key")).toBe(
      "retry-key",
    );
    expect(options.credentials).toBe("include");
  });
  it("refuses a local-only quotation before transmitting files or an order", async () => {
    const fetcher = vi.spyOn(globalThis, "fetch");
    const localQuote = calculateQuote(defaultInput, {
      ...defaultConfig,
      published: true,
      markup: 0.3,
    });
    await expect(
      apiOrderGateway.submit(
        {
          quote: localQuote,
          recipient: { name: "", phone: "", region: "", address: "" },
          contact: "",
          orderName: "",
          notes: "",
          files: { print: [], proof: [], certificate: [] },
        },
        "retry",
        new AbortController().signal,
      ),
    ).rejects.toThrow("重新算价");
    expect(fetcher).not.toHaveBeenCalled();
  });
  it("uploads file bytes using an encoded filename and propagates server validation", async () => {
    const fetcher = vi
      .spyOn(globalThis, "fetch")
      .mockResolvedValue(
        new Response(JSON.stringify({ error: "登录已过期" }), { status: 401 }),
      );
    const file = new File(["print"], "测试 & 卡片.pdf");
    await expect(
      apiOrderGateway.upload(file, "print", new AbortController().signal),
    ).rejects.toThrow("登录已过期");
    expect(fetcher.mock.calls[0][0]).toContain(encodeURIComponent(file.name));
    expect(fetcher.mock.calls[0][1]?.body).toBe(file);
  });
});
