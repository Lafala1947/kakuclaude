// @vitest-environment node
import { afterEach, beforeEach, describe, expect, it } from 'vitest';
import { mkdtemp, mkdir, writeFile, readFile, copyFile, rm } from 'node:fs/promises';
import { basename, dirname, join, resolve } from 'node:path';
import { tmpdir } from 'node:os';
import type { Server } from 'node:http';
import { createApiServer, provisionStaff } from '../src/server/server';
import { defaultInput } from '../src/shared/contracts';
import { defaultConfig } from '../src/lib/config';
import { serializePricingCsv } from '../src/lib/csv';
import type { ApiOrder } from '../src/shared/api';
import type { State } from '../src/server/store';

const origin = 'http://localhost:5173';
const allChecks = ['artwork', 'size', 'bleed', 'color', 'fonts', 'crafts'];
let dir: string, server: Server, base: string, sales: string, pricing: string, member: string, other: string, orderId: string, originalFile: string;
async function start() {
  server = await createApiServer({ dataDir: dir, seedDir: join(dir, 'seed'), origin });
  await new Promise<void>(r => server.listen(0, '127.0.0.1', r));
  base = `http://127.0.0.1:${(server.address() as {port: number}).port}/api`;
}
async function stop() {
  if (server?.listening) await new Promise<void>((r, j) => server.close(e => e ? j(e) : r()));
}
async function request(path: string, method = 'GET', body?: unknown, cookie = member, headers: Record<string, string> = {}) {
  const response = await fetch(base + path, {
    method, headers: { Origin: origin, 'X-Kaku-Request': '1', Cookie: cookie, ...(body === undefined ? {} : {'Content-Type': 'application/json'}), ...headers },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return { status: response.status, body: await response.json(), cookie: response.headers.get('set-cookie')?.split(';')[0] ?? '' };
}
async function upload(name = 'art.pdf', cookie = member, kind = 'print') {
  const response = await fetch(base + `/files?kind=${kind}&name=${name}`, {
    method: 'POST', headers: { Origin: origin, 'X-Kaku-Request': '1', Cookie: cookie, 'Content-Type': 'application/octet-stream' }, body: 'artwork',
  });
  expect(response.status).toBe(201);
  return (await response.json()).id as string;
}
const review = (revision: unknown, decision = 'approved', checks = allChecks, comment = '', cookie = sales) => request(`/orders/${orderId}/file-review`, 'POST', { revision, decision, checks, comment }, cookie);
const resubmit = (revision: unknown, print: string[], extra = {}, cookie = member) => request(`/orders/${orderId}/files`, 'PUT', { revision, files: {print, proof: [], certificate: []}, comment: '已修订', ...extra }, cookie);
const status = (value: string) => request(`/orders/${orderId}`, 'PATCH', {status: value}, sales);
async function current(): Promise<ApiOrder> { return (await request('/orders')).body.orders[0]; }
async function editDisk(edit: (state: State) => void) {
  await stop();
  const state = JSON.parse(await readFile(join(dir, 'state.json'), 'utf8'));
  edit(state);
  await writeFile(join(dir, 'state.json'), JSON.stringify(state));
  await start();
}
beforeEach(async () => {
  dir = await mkdtemp(join(tmpdir(), 'kaku-review-'));
  await mkdir(join(dir, 'seed'));
  await writeFile(join(dir, 'seed', 'pricing.csv'), serializePricingCsv({...defaultConfig, published: true, markup: 0.3, design: {adjust: 100, custom: 200}}));
  for (const name of ['products.json', 'homepage.json']) await copyFile(join('public', name), join(dir, 'seed', name));
  for (const group of ['sales', 'pricing'] as const) await provisionStaff({dataDir: dir, seedDir: join(dir, 'seed'), email: `${group}@test.cn`, name: group, group, password: 'safe-test-password-123'});
  await start();
  sales = (await request('/auth/login', 'POST', { email: 'sales@test.cn', password: 'safe-test-password-123'}, '')).cookie;
  pricing = (await request('/auth/login', 'POST', { email: 'pricing@test.cn', password: 'safe-test-password-123'}, '')).cookie;
  member = (await request('/auth/register', 'POST', {email: 'member@test.cn', password: 'safe-member-password', name: '客户'}, '')).cookie;
  other = (await request('/auth/register', 'POST', {email: 'other@test.cn', password: 'safe-member-password', name: '其他客户'}, '')).cookie;
  originalFile = await upload();
  const quote = await request('/quotes', 'POST', {input: defaultInput});
  const created = await request('/orders', 'POST', {
    quoteId: quote.body.quoteId, contact: '13800138000', recipient: {name: '客户', phone: '13800138000'},
    files: { print: [originalFile], proof: [], certificate: [] },
  }, member, {'Idempotency-Key': 'review-order'});
  expect(created.status).toBe(201);
  orderId = created.body.orderId;
});
afterEach(async () => {
  await stop();
  // Only remove the verified dedicated test directory, never the app data directory.
  if (dir && dirname(resolve(dir)) === resolve(tmpdir()) && basename(dir).startsWith('kaku-review-')) await rm(dir, {recursive: true, force: true});
});

describe('order file review API', () => {
  it('persists rejection, replacement snapshots, reapproval and production with an unchanged quote across restart', async () => {
    const initial = await current();
    expect(initial.fileReview).toMatchObject({status: 'pending', revision: 1, fileVersion: 1, history: []});
    const rejected = await review(1, 'rejected', ['size'], '出血不足');
    expect(rejected.status).toBe(200);
    expect(rejected.body.order.fileReview).toMatchObject({status: 'rejected', revision: 2, reviewer: {name: 'sales'}, history: [{ action: 'rejected', fileVersion: 1, files: [{id: originalFile}], comment: '出血不足' }]});
    const replacement = await upload('revised.pdf');
    await editDisk(state => { state.quotes = []; state.orders[0].quote.expiresAt = '2000-01-01T00:00:00.000Z'; });
    const quoteSnapshot = (await current()).quote;
    const revised = await resubmit(2, [replacement], { quote: {total: 0}, contact: 'forged' });
    expect(revised.status).toBe(200);
    expect(revised.body.order.quote).toEqual(quoteSnapshot);
    expect(revised.body.order.contact).toBe(initial.contact);
    expect(revised.body.order.files.map((f: {id: string}) => f.id)).toEqual([replacement]);
    expect(revised.body.order.fileReview).toMatchObject({status: 'pending', revision: 3, fileVersion: 2, checks: [], comment: '', reviewedAt: null, reviewer: null, history: [{action: 'rejected', files: [{id: originalFile}]}, {action: 'resubmitted', fileVersion: 2, files: [{id: replacement}], actor: {name: '客户'}}]});
    expect((await status('confirmed')).status).toBe(200);
    expect((await status('producing')).status).toBe(409);
    const approved = await review(3);
    expect(approved.status).toBe(200);
    expect(approved.body.order.fileReview).toMatchObject({status: 'approved', revision: 4, fileVersion: 2, checks: allChecks});
    expect((await status('producing')).status).toBe(200);
    expect((await review(4, 'rejected', [], 'late')).status).toBe(409);
    expect((await resubmit(4, [originalFile])).status).toBe(409);
    expect((await status('shipped')).status).toBe(200);
    expect((await status('confirmed')).status).toBe(409);
    await stop(); await start();
    expect(await current()).toEqual({...approved.body.order, status: 'shipped'});
  });

  it('requires sales, all six distinct known approval checks, a rejection reason and current numeric revision', async () => {
    for (const cookie of [member, other, pricing]) expect((await review(1, 'approved', allChecks, '', cookie)).status).toBe(403);
    expect((await review(1, 'approved', allChecks, '', '')).status).toBe(401);
    for (const checks of [[], allChecks.slice(1), [...allChecks, 'bogus'], [...allChecks, 'artwork']]) expect((await review(1, 'approved', checks)).status).toBe(400);
    expect((await review(1, 'rejected', [], '  ')).status).toBe(400);
    expect((await request(`/orders/${orderId}/file-review`, 'POST', {revision: 1, decision: 'approved', checks: 'artwork', comment: ''}, sales)).status).toBe(400);
    expect((await review(1, 'bogus')).status).toBe(400);
    for (const revision of [0, '1', null, 999, 1.5]) expect((await review(revision)).status).toBe(409);
    const responses = await Promise.all([review(1), review(1)]);
    expect(responses.map(r => r.status).sort()).toEqual([200, 409]);
    const result = await current();
    expect(result.fileReview?.history).toHaveLength(1);
    expect(result.fileReview?.history[0]).toMatchObject({action: 'approved', actor: {name: 'sales'}, files: [{id: originalFile}]});
    expect((await review(2, 'rejected', [], '发现新问题')).status).toBe(200);
    expect((await current()).fileReview?.history).toHaveLength(2);
  });

  it('limits replacement to owner and rejected editable orders, validates file IDs and rejects concurrent resubmission', async () => {
    const replacement = await upload('new.pdf'), foreign = await upload('foreign.pdf', other), proof = await upload('proof.pdf', member, 'proof');
    expect((await resubmit(1, [replacement])).status).toBe(409);
    expect((await review(1, 'rejected', [], '需修正')).status).toBe(200);
    expect((await resubmit(2, [replacement], {}, other)).status).toBe(404);
    expect((await resubmit(2, [replacement], {}, sales)).status).toBe(403);
    expect((await resubmit(2, [replacement], {}, '')).status).toBe(401);
    for (const files of [[originalFile], [], [foreign], [proof], ['missing'], [replacement, replacement]]) expect((await resubmit(2, files)).status).toBe(400);
    expect((await resubmit(1, [replacement])).status).toBe(409);
    const replies = await Promise.all([resubmit(2, [replacement]), resubmit(2, [replacement])]);
    expect(replies.map(r => r.status).sort()).toEqual([200, 409]);
    expect((await current()).fileReview).toMatchObject({revision: 3, fileVersion: 2});
    expect((await current()).fileReview?.history).toHaveLength(2);
    expect((await resubmit(3, [originalFile])).status).toBe(409);
  });

  it('protects historical downloads and excludes history from pending files and upload quota', async () => {
    expect((await review(1, 'rejected', [], '出血')).status).toBe(200);
    const replacement = await upload('new.pdf');
    expect((await resubmit(2, [replacement])).status).toBe(200);
    expect((await request('/files')).body.files).toEqual([]);
    expect((await request('/files/' + originalFile, 'DELETE')).status).toBe(409);
    expect((await request('/files/' + originalFile, 'DELETE', undefined, other)).status).toBe(404);
    for (const cookie of [member, sales]) {
      const response = await fetch(base + '/files/' + originalFile, {headers: {Cookie: cookie}});
      expect(response.status).toBe(200);
      expect(await response.text()).toBe('artwork');
    }
    expect((await request('/files/' + originalFile, 'GET', undefined, other)).status).toBe(404);
    for (let i = 0; i < 20; i++) await upload(`pending-${i}.pdf`);
    expect((await request('/files')).body.files).toHaveLength(20);
    expect((await current()).fileReview?.history[0].files[0].id).toBe(originalFile);
  });

  it('enforces combined replacement limits while allowing retained current files', async () => {
    expect((await review(1, 'rejected', [], '追加')).status).toBe(200);
    const additions: string[] = [];
    for (let i = 0; i < 20; i++) additions.push(await upload(`file-${i}.pdf`));
    expect((await resubmit(2, [originalFile, ...additions])).status).toBe(400);
    await editDisk(state => { state.files.find(f => f.id === additions[0])!.size = 100 * 1024 * 1024; });
    expect((await resubmit(2, [originalFile, additions[0]])).status).toBe(400);
    expect((await resubmit(2, [originalFile, additions[1]])).status).toBe(200);
    expect((await current()).files.map(f => f.id)).toEqual([originalFile, additions[1]]);
  });

  it('defaults legacy orders to pending, enforces state transitions and permits legacy production to ship', async () => {
    await editDisk(state => { delete state.orders[0].fileReview; });
    expect((await current()).fileReview).toMatchObject({status: 'pending', history: []});
    expect((await status('producing')).status).toBe(409);
    expect((await status('shipped')).status).toBe(409);
    expect((await status('confirmed')).status).toBe(200);
    expect((await status('confirmed')).status).toBe(200);
    expect((await status('producing')).status).toBe(409);
    await editDisk(state => { state.orders[0].status = 'producing'; delete state.orders[0].fileReview; });
    expect((await status('shipped')).status).toBe(200);
    expect((await review(1)).status).toBe(409);
    expect((await status('cancelled')).status).toBe(409);
  });

  it('checks request origin and expected identity for both mutations', async () => {
    expect((await request(`/orders/${orderId}/file-review`, 'POST', {revision: 1, decision: 'approved', checks: allChecks, comment: ''}, sales, {Origin: 'https://foreign.test'})).status).toBe(403);
    expect((await request(`/orders/${orderId}/file-review`, 'POST', {revision: 1, decision: 'approved', checks: allChecks, comment: ''}, sales, {'X-Kaku-User-Id': 'wrong'})).status).toBe(401);
    expect((await review(1, 'rejected', [], '修订')).status).toBe(200);
    const replacement = await upload('new.pdf');
    const body = {revision: 2, files: {print: [replacement], proof: [], certificate: []}, comment: ''};
    expect((await request(`/orders/${orderId}/files`, 'PUT', body, member, {Origin: 'https://foreign.test'})).status).toBe(403);
    expect((await request(`/orders/${orderId}/files`, 'PUT', body, member, {'X-Kaku-User-Id': 'wrong'})).status).toBe(401);
    expect((await current()).fileReview).toMatchObject({revision: 2, status: 'rejected'});
  });

  it('freezes cancelled rejected orders and leaves their files and audit unchanged', async () => {
    expect((await review(1, 'rejected', [], '需修正')).status).toBe(200);
    const replacement = await upload('new.pdf');
    expect((await status('cancelled')).status).toBe(200);
    const cancelled = await current();
    expect((await resubmit(2, [replacement])).status).toBe(409);
    expect((await review(2)).status).toBe(409);
    expect((await status('confirmed')).status).toBe(409);
    expect((await status('cancelled')).status).toBe(200);
    expect(await current()).toEqual(cancelled);
    expect((await request('/orders/missing/file-review', 'POST', {revision: 1, decision: 'approved', checks: allChecks}, sales)).status).toBe(404);
    expect((await request('/orders/missing/files', 'PUT', {revision: 1, files: {print: [replacement], proof: [], certificate: []}})).status).toBe(404);
  });
});
