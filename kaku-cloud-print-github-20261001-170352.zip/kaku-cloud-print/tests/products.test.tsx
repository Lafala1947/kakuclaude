// @vitest-environment jsdom
import { afterEach, describe, it, expect, vi } from "vitest";
import {
  render,
  screen,
  fireEvent,
  cleanup,
  within,
  act,
} from "@testing-library/react";
import { MemoryRouter, useNavigate } from "react-router-dom";
import App from "../src/client/App";
import { MemberProvider } from "../src/client/members/MemberContext";
import { DraftProvider } from "../src/client/DraftContext";
import {
  parseProducts,
  serializeProducts,
} from "../src/shared/products";
import productFixture from './fixtures/products.json';
import type { ProductDocument } from '../src/shared/products';
const defaultProducts = productFixture as ProductDocument;
import {
  defaultHomepage,
  serializeHomepage,
  newModule,
} from "../src/shared/homepage";
import { defaultConfig } from "../src/lib/config";
import { serializePricingCsv } from "../src/lib/csv";
const download = vi.hoisted(() => vi.fn());
vi.mock("../src/client/utils", async () => ({
  ...(await vi.importActual("../src/client/utils")),
  download,
}));
afterEach(() => {
  cleanup();
  localStorage.clear();
  vi.restoreAllMocks();
  download.mockReset();
});
function Jump() {
  const navigate = useNavigate();
  return (
    <button onClick={() => navigate("/admin/products")}>产品模块直达</button>
  );
}
function setup(
  path = "/admin",
  data = defaultProducts,
  home = defaultHomepage,
  productResponse?: Promise<Response>,
) {
  vi.spyOn(globalThis, "fetch").mockImplementation(async (input) =>
    productResponse && String(input).includes("products.json")
      ? productResponse
      : new Response(
          String(input).includes("products.json")
            ? serializeProducts(data)
            : String(input).includes("homepage.json")
              ? serializeHomepage(home)
              : serializePricingCsv(defaultConfig),
        ),
  );
  return render(
    <MemoryRouter initialEntries={[path]}>
      <DraftProvider>
        <MemberProvider>
          <App />
          <Jump />
        </MemberProvider>
      </DraftProvider>
    </MemoryRouter>,
  );
}
async function manage() {
  setup();
  fireEvent.click(screen.getByRole("button", { name: "进入页面组" }));
  fireEvent.click(screen.getByRole("link", { name: "产品管理" }));
  await screen.findByRole("button", { name: "编辑 包装插卡" });
}
describe("product document", () => {
  it.each(["quoteMode", "artwork", "material"])(
    "rejects array values in the %s enum",
    (field) => {
      const data = structuredClone(defaultProducts);
      if (field === "material") {
        (data.categories[0] as unknown as Record<string, unknown>).material = [
          "paper",
        ];
        data.products.forEach((p) => (p.quoteMode = "inquiry"));
      } else
        (data.products[0] as unknown as Record<string, unknown>)[field] = [
          field === "quoteMode" ? "paper" : "shape",
        ];
      expect(() => parseProducts(JSON.stringify(data))).toThrow();
    },
  );
  it("round trips and rejects duplicate codes, unknown categories and non-paper quoting", () => {
    expect(parseProducts(serializeProducts(defaultProducts))).toEqual(
      defaultProducts,
    );
    const bad = structuredClone(defaultProducts);
    bad.products[1].code = bad.products[0].code;
    expect(() => parseProducts(JSON.stringify(bad))).toThrow(/编号/);
    bad.products[1].code = "NEW";
    bad.products[0].categoryId = "missing";
    expect(() => parseProducts(JSON.stringify(bad))).toThrow(/分类/);
    bad.products[0].categoryId = "other";
    expect(() => parseProducts(JSON.stringify(bad))).toThrow(/纸质/);
    bad.products[0].quoteMode = "inquiry";
    bad.products[0].image = "javascript:alert(1)";
    expect(() => parseProducts(JSON.stringify(bad))).toThrow(/图片/);
  });
});
describe("product management", () => {
  it("retains unsaved category edits and blocks incomplete downloads", async () => {
    await manage();
    fireEvent.click(screen.getByRole("button", { name: "管理分类" }));
    fireEvent.click(screen.getByRole("button", { name: "编辑分类 纸质卡片" }));
    fireEvent.change(screen.getByLabelText("分类名称"), {
      target: { value: "纸卡新分类名称" },
    });
    expect(
      (
        screen.getByRole("button", {
          name: "下载产品配置",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
    expect(
      (
        screen.getByRole("button", {
          name: "保存产品草稿",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
    const event = new Event("beforeunload", { cancelable: true });
    window.dispatchEvent(event);
    expect(event.defaultPrevented).toBe(true);
    fireEvent.click(
      within(
        screen.getByRole("navigation", { name: "后台管理模块" }),
      ).getByRole("link", { name: "首页内容管理" }),
    );
    fireEvent.click(screen.getByRole("link", { name: "产品管理" }));
    expect((screen.getByLabelText("分类名称") as HTMLInputElement).value).toBe(
      "纸卡新分类名称",
    );
    fireEvent.click(screen.getByRole("button", { name: "保存分类到草稿" }));
    fireEvent.click(screen.getByRole("button", { name: "下载产品配置" }));
    expect(parseProducts(download.mock.calls[0][0]).categories[0].name).toBe(
      "纸卡新分类名称",
    );
  });
  it("waits for the deployed catalog before allowing draft export", async () => {
    let resolve!: (value: Response) => void;
    const pending = new Promise<Response>((done) => {
      resolve = done;
    });
    setup("/admin", defaultProducts, defaultHomepage, pending);
    fireEvent.click(screen.getByRole("button", { name: "进入产品管理" }));
    expect(
      (
        screen.getByRole("button", {
          name: "保存产品草稿",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
    expect(
      (
        screen.getByRole("button", {
          name: "下载产品配置",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
    const data = structuredClone(defaultProducts);
    data.products[0].name = "服务器新品";
    await act(async () => resolve(new Response(serializeProducts(data))));
    expect(
      await screen.findByRole("button", { name: "编辑 服务器新品" }),
    ).toBeTruthy();
  });
  it("does not resurrect default products when deployed configuration fails", async () => {
    setup(
      "/products",
      defaultProducts,
      defaultHomepage,
      Promise.resolve(new Response("{bad")),
    );
    expect(
      await screen.findByRole("heading", { name: "产品信息暂不可用" }),
    ).toBeTruthy();
    expect(screen.queryByRole("heading", { name: "包装插卡" })).toBeNull();
  });
  it("imports only after validation and confirmation, preserving edits on errors", async () => {
    await manage();
    fireEvent.change(screen.getByLabelText("导入产品配置文件"), {
      target: { files: [{ size: 10, text: async () => "{bad" }] },
    });
    expect((await screen.findByRole("alert")).textContent).toContain("JSON");
    expect(screen.getByRole("button", { name: "编辑 包装插卡" })).toBeTruthy();
    const imported = structuredClone(defaultProducts);
    imported.products[0].name = "导入产品";
    fireEvent.change(screen.getByLabelText("导入产品配置文件"), {
      target: {
        files: [{ size: 100, text: async () => serializeProducts(imported) }],
      },
    });
    const confirm = await screen.findByRole("button", { name: "确认导入产品" });
    expect(screen.queryByRole("button", { name: "编辑 导入产品" })).toBeNull();
    fireEvent.click(confirm);
    fireEvent.click(screen.getByRole("button", { name: "下载产品配置" }));
    expect(parseProducts(download.mock.calls[0][0])).toEqual(imported);
  });
  it("keeps incomplete product edits across navigation and blocks duplicate codes", async () => {
    await manage();
    fireEvent.click(screen.getByRole("button", { name: "编辑 包装插卡" }));
    fireEvent.change(screen.getByLabelText("产品名称"), {
      target: { value: "尚未保存名称" },
    });
    fireEvent.click(
      within(
        screen.getByRole("navigation", { name: "后台管理模块" }),
      ).getByRole("link", { name: "首页内容管理" }),
    );
    fireEvent.click(screen.getByRole("link", { name: "产品管理" }));
    expect((screen.getByLabelText("产品名称") as HTMLInputElement).value).toBe(
      "尚未保存名称",
    );
    fireEvent.change(screen.getByLabelText("产品编号"), {
      target: { value: "KK-P002" },
    });
    fireEvent.click(screen.getByRole("button", { name: "保存产品到草稿" }));
    expect(screen.getByRole("alert").textContent).toContain("编号");
    expect(
      (
        screen.getByRole("button", {
          name: "下载产品配置",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
  });
  it("adds and edits categories, filters and reorders products", async () => {
    await manage();
    fireEvent.click(screen.getByRole("button", { name: "管理分类" }));
    fireEvent.click(screen.getByRole("button", { name: "新增分类" }));
    fireEvent.change(screen.getByLabelText("分类名称"), {
      target: { value: "PVC 卡片" },
    });
    fireEvent.click(screen.getByRole("button", { name: "保存分类到草稿" }));
    fireEvent.click(screen.getByRole("button", { name: "编辑分类 PVC 卡片" }));
    fireEvent.change(screen.getByLabelText("分类名称"), {
      target: { value: "塑料卡片" },
    });
    fireEvent.click(screen.getByRole("button", { name: "保存分类到草稿" }));
    fireEvent.click(screen.getByRole("button", { name: "上移 品牌感谢卡" }));
    fireEvent.change(screen.getByRole("searchbox", { name: "搜索产品" }), {
      target: { value: "感谢" },
    });
    expect(screen.queryByRole("button", { name: "编辑 包装插卡" })).toBeNull();
    expect(
      (
        screen.getByRole("button", {
          name: "下移 品牌感谢卡",
        }) as HTMLButtonElement
      ).disabled,
    ).toBe(true);
    fireEvent.click(screen.getByRole("button", { name: "下载产品配置" }));
    const data = parseProducts(download.mock.calls[0][0]);
    expect(data.products[0].name).toBe("品牌感谢卡");
    expect(data.categories.at(-1)?.name).toBe("塑料卡片");
  });
  it("shows only active featured products in the optional homepage catalog module", async () => {
    const data = structuredClone(defaultProducts);
    data.products[0].active = false;
    data.products[1].featured = false;
    const home = {
      ...structuredClone(defaultHomepage),
      modules: [newModule("catalog")],
    };
    setup("/", data, home);
    expect(
      await screen.findByRole("heading", { name: "异形卡片" }),
    ).toBeTruthy();
    expect(screen.queryByRole("heading", { name: "包装插卡" })).toBeNull();
    expect(screen.queryByRole("heading", { name: "品牌感谢卡" })).toBeNull();
  });
  it("preserves draft edits if browser storage refuses a save", async () => {
    await manage();
    fireEvent.click(screen.getByRole("button", { name: "下架 包装插卡" }));
    vi.spyOn(Storage.prototype, "setItem").mockImplementation(() => {
      throw new Error("本机存储不可用");
    });
    fireEvent.click(screen.getByRole("button", { name: "保存产品草稿" }));
    expect(screen.getByRole("alert").textContent).toContain("本机存储不可用");
    expect(screen.getByRole("button", { name: "上架 包装插卡" })).toBeTruthy();
  });
  it("requires page-group access even for a direct URL", async () => {
    setup("/admin/products");
    expect(
      screen.getByRole("heading", { name: "请选择后台管理组" }),
    ).toBeTruthy();
    fireEvent.click(screen.getByRole("link", { name: "返回后台入口" }));
    fireEvent.click(screen.getByRole("button", { name: "进入价格组" }));
    expect(
      within(
        await screen.findByRole("navigation", { name: "后台管理模块" }),
      ).queryByRole("link", { name: "产品管理" }),
    ).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "产品模块直达" }));
    expect(
      screen.getByRole("heading", { name: "当前组无权访问此模块" }),
    ).toBeTruthy();
  });
  it("adds, edits, filters and exports a product while keeping public content separate", async () => {
    await manage();
    fireEvent.click(screen.getByRole("button", { name: "新增产品" }));
    fireEvent.change(screen.getByLabelText("产品编号"), {
      target: { value: "VIP-001" },
    });
    fireEvent.change(screen.getByLabelText("产品名称"), {
      target: { value: "品牌会员卡" },
    });
    fireEvent.change(screen.getByLabelText("产品简介"), {
      target: { value: "会员卡应用介绍" },
    });
    fireEvent.click(screen.getByRole("button", { name: "保存产品到草稿" }));
    fireEvent.click(screen.getByRole("button", { name: "上架 品牌会员卡" }));
    fireEvent.click(screen.getByRole("button", { name: "保存产品草稿" }));
    fireEvent.click(screen.getByRole("button", { name: "下载产品配置" }));
    const data = parseProducts(download.mock.calls[0][0]);
    expect(data.products.at(-1)?.name).toBe("品牌会员卡");
    expect(data.products.at(-1)?.active).toBe(true);
    fireEvent.click(screen.getByRole("link", { name: "预览产品草稿" }));
    expect(screen.getByRole("heading", { name: "品牌会员卡" })).toBeTruthy();
    fireEvent.click(screen.getByRole("link", { name: "产品中心" }));
    expect(screen.queryByRole("heading", { name: "品牌会员卡" })).toBeNull();
  });
  it("blocks deleting a referenced category and supports confirmed product deletion", async () => {
    await manage();
    fireEvent.click(screen.getByRole("button", { name: "管理分类" }));
    fireEvent.click(screen.getByRole("button", { name: "删除分类 纸质卡片" }));
    expect(screen.getByRole("alert").textContent).toContain("使用");
    fireEvent.click(screen.getByRole("button", { name: "删除 包装插卡" }));
    fireEvent.click(screen.getByRole("button", { name: "确认删除产品" }));
    expect(screen.queryByRole("button", { name: "编辑 包装插卡" })).toBeNull();
  });
  it("hides unpublished products from the public listing and direct detail links", async () => {
    const data = structuredClone(defaultProducts);
    data.products[0].active = false;
    const view = setup("/products", data);
    await screen.findByRole("heading", { name: "品牌感谢卡" });
    expect(screen.queryByRole("heading", { name: "包装插卡" })).toBeNull();
    view.unmount();
    setup("/products/insert", data);
    expect(
      await screen.findByRole("heading", { name: "产品不存在或已下架" }),
    ).toBeTruthy();
  });
});
