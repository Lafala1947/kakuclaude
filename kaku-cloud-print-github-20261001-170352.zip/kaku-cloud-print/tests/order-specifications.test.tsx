// @vitest-environment jsdom
import { afterEach, expect, it } from "vitest";
import { cleanup, render, screen } from "@testing-library/react";
import OrderSpecifications from "../src/client/order/OrderSpecifications";
import { calculateQuote } from "../src/lib/pricing";
import { defaultConfig } from "../src/lib/config";
import { defaultInput } from "../src/shared/contracts";
afterEach(cleanup);
it("shows the full saved specification including paper snapshot, quantities, faces and finishing", () => {
  const quote = calculateQuote(defaultInput, {
    ...defaultConfig,
    published: true,
    markup: 0.3,
    paper: { ...defaultConfig.paper, name: "订单专用卡纸", gsm: 320 },
  });
  quote.input = {
    ...quote.input,
    quantity: 500,
    variants: 2,
    sides: 2,
    ink: "spot",
    cutting: "die",
    lamination: 2,
    extras: ["circle", "uv"],
    circleDiameter: 40,
    crafts: ["foil"],
    foilArea: 8,
  };
  render(<OrderSpecifications quote={quote} />);
  expect(screen.getByText("订单专用卡纸 · 320 g/㎡")).toBeTruthy();
  expect(screen.getByText("500 张 / 款 × 2 款")).toBeTruthy();
  expect(screen.getByText("双面 · 四色加 1 专色")).toBeTruthy();
  expect(screen.getByText("模切 · 双面覆膜")).toBeTruthy();
  expect(screen.getByText(/热烫.*圆形.*局部UV/)).toBeTruthy();
  expect(screen.getByText("圆形直径 40 mm · 每张烫金面积 8 cm²")).toBeTruthy();
});
it("does not invent the material name for legacy orders with no material snapshot", () => {
  const quote = calculateQuote(defaultInput, {
    ...defaultConfig,
    published: true,
    markup: 0.3,
  });
  delete quote.materialSnapshot;
  render(<OrderSpecifications quote={quote} />);
  expect(screen.getByText(/历史订单未记录纸张名称和克重/)).toBeTruthy();
});
