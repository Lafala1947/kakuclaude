// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  act,
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
  within,
} from "@testing-library/react";
import { defaultInput } from "../src/shared/contracts";
import { defaultConfig } from "../src/lib/config";
import { calculateQuote } from "../src/lib/pricing";
import OrderDetails from "../src/client/order/OrderDetails";
import type { OrderGateway } from "../src/client/order/types";

afterEach(() => {
  cleanup();
  localStorage.clear();
});

function props(gateway?: OrderGateway) {
  const config = structuredClone(defaultConfig);
  config.published = true;
  config.markup = 0.3;
  const quote = calculateQuote(defaultInput, config);
  return {
    quote,
    shipping: "pickup" as const,
    region: "local" as const,
    logisticsEnabled: true,
    onDeliveryChange: vi.fn(),
    gateway,
  };
}

function file(name: string, size = 10, modified = 1) {
  return new File([new Uint8Array(size)], name, { lastModified: modified });
}

function fillRecipient() {
  fireEvent.click(screen.getByRole("button", { name: /新增地址/ }));
  const dialog = screen.getByRole("dialog", { name: "编辑收货人信息" });
  fireEvent.change(within(dialog).getByRole("textbox", { name: "收货人" }), {
    target: { value: "张三" },
  });
  fireEvent.change(within(dialog).getByRole("textbox", { name: "联系电话" }), {
    target: { value: "13800138000" },
  });
  fireEvent.click(within(dialog).getByRole("button", { name: "使用此地址" }));
  fireEvent.change(screen.getByRole("textbox", { name: "联系方式" }), {
    target: { value: "13800138000" },
  });
}

describe("order details", () => {
  it("reuses uploaded files when recalculating after a rejected quote", async () => {
    const gateway: OrderGateway = {
      upload: vi.fn().mockResolvedValue({ id: "file-1", name: "art.pdf" }),
      submit: vi
        .fn()
        .mockRejectedValueOnce(new Error("报价过期"))
        .mockResolvedValueOnce({ orderId: "order-new" }),
    };
    const properties = props(gateway),
      view = render(<OrderDetails {...properties} />);
    fillRecipient();
    fireEvent.change(screen.getByLabelText("选择印品文件"), {
      target: { files: [file("art.pdf")] },
    });
    fireEvent.click(screen.getByRole("button", { name: "立即下单" }));
    await screen.findByText(/报价过期/);
    view.rerender(
      <OrderDetails
        {...properties}
        quote={{
          ...properties.quote,
          quoteId: "new-quote",
          total: properties.quote.total + 1,
        }}
      />,
    );
    fireEvent.click(screen.getByRole("button", { name: "立即下单" }));
    await screen.findByText(/order-new/);
    expect(gateway.upload).toHaveBeenCalledTimes(1);
  });
  it("cleans up unsubmitted uploaded files when removing them after a failed order", async () => {
    const remove = vi.fn().mockResolvedValue({ ok: true });
    const gateway = {
      upload: vi.fn().mockResolvedValue({ id: "file-1", name: "art.pdf" }),
      submit: vi.fn().mockRejectedValue(new Error("报价过期")),
      remove,
    };
    render(<OrderDetails {...props(gateway)} />);
    fillRecipient();
    fireEvent.change(screen.getByLabelText("选择印品文件"), {
      target: { files: [file("art.pdf")] },
    });
    fireEvent.click(screen.getByRole("button", { name: "立即下单" }));
    await screen.findByText(/报价过期/);
    fireEvent.click(screen.getByRole("button", { name: "移除 art.pdf" }));
    await waitFor(() =>
      expect(remove).toHaveBeenCalledWith("file-1", expect.any(AbortSignal)),
    );
    expect(screen.queryByText("art.pdf")).toBeNull();
  });
  it("holds files locally, preserves same-name files with distinct metadata, and disables submit without a gateway", () => {
    render(<OrderDetails {...props()} />);
    const input = screen.getByLabelText("选择印品文件");
    fireEvent.change(input, {
      target: { files: [file("art.pdf", 10, 1), file("art.pdf", 12, 2)] },
    });
    expect(screen.getAllByText("art.pdf")).toHaveLength(2);
    expect(screen.getAllByText(/已选择，尚未上传/)).toHaveLength(2);
    expect(screen.getByText(/上传与订单接口尚未配置/)).toBeTruthy();
    expect(
      (screen.getByRole("button", { name: "立即下单" }) as HTMLButtonElement)
        .disabled,
    ).toBe(true);
    fireEvent.click(screen.getByRole("button", { name: /清空已选文件/ }));
    expect(screen.queryByText("art.pdf")).toBeNull();
  });

  it("rejects unsupported files and enforces the aggregate size limit", () => {
    render(<OrderDetails {...props()} />);
    const input = screen.getByLabelText("选择印品文件");
    fireEvent.change(input, { target: { files: [file("script.exe")] } });
    expect(screen.getByRole("alert").textContent).toContain("文件格式不支持");
    fireEvent.change(input, {
      target: { files: [file("huge.pdf", 100 * 1024 * 1024 + 1)] },
    });
    expect(screen.getByRole("alert").textContent).toContain("100 MB");
    expect(screen.queryByText("huge.pdf")).toBeNull();
  });

  it("saves a common address only through the explicit save action", () => {
    render(<OrderDetails {...props()} />);
    fillRecipient();
    expect(localStorage.getItem("insert-card-common-addresses-v1")).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "编辑" }));
    const dialog = screen.getByRole("dialog", { name: "编辑收货人信息" });
    fireEvent.click(
      within(dialog).getByRole("button", { name: "保存为常用地址" }),
    );
    expect(
      JSON.parse(
        localStorage.getItem("insert-card-common-addresses-v1") ?? "[]",
      ),
    ).toHaveLength(1);
  });

  it("uploads files and submits exactly once through the configured gateway", async () => {
    const gateway: OrderGateway = {
      upload: vi.fn().mockResolvedValue({ id: "file-1", name: "art.pdf" }),
      submit: vi.fn().mockResolvedValue({ orderId: "order-1" }),
    };
    const onPendingChange = vi.fn();
    const properties = { ...props(gateway), onPendingChange };
    const view = render(<OrderDetails {...properties} />);
    fillRecipient();
    fireEvent.change(screen.getByLabelText("选择印品文件"), {
      target: { files: [file("art.pdf")] },
    });
    fireEvent.click(screen.getByRole("button", { name: "立即下单" }));
    await waitFor(() =>
      expect(screen.getByText(/订单已提交，编号：order-1/)).toBeTruthy(),
    );
    expect(gateway.upload).toHaveBeenCalledTimes(1);
    expect(gateway.submit).toHaveBeenCalledTimes(1);
    expect(onPendingChange.mock.calls.map(([value]) => value)).toEqual([
      true,
      false,
    ]);
    expect(
      (gateway.submit as ReturnType<typeof vi.fn>).mock.calls[0][0].files.print,
    ).toEqual(["file-1"]);
    expect(
      (screen.getByRole("button", { name: "立即下单" }) as HTMLButtonElement)
        .disabled,
    ).toBe(true);
    view.rerender(
      <OrderDetails
        {...properties}
        quote={{ ...properties.quote, createdAt: "recalculated-later" }}
      />,
    );
    expect(screen.getByText(/订单已提交，编号：order-1/)).toBeTruthy();
    expect(
      (screen.getByRole("button", { name: "立即下单" }) as HTMLButtonElement)
        .disabled,
    ).toBe(true);
    view.rerender(
      <OrderDetails
        {...properties}
        quote={{ ...properties.quote, total: properties.quote.total + 1 }}
      />,
    );
    expect(screen.queryByText(/订单已提交，编号：order-1/)).toBeNull();
  });

  it("keeps the idempotency key and uploaded file IDs on retry after submit failure", async () => {
    const gateway: OrderGateway = {
      upload: vi.fn().mockResolvedValue({ id: "file-1", name: "art.pdf" }),
      submit: vi
        .fn()
        .mockRejectedValueOnce(new Error("network down"))
        .mockResolvedValueOnce({ orderId: "order-2" }),
    };
    const properties = props(gateway);
    const view = render(<OrderDetails {...properties} />);
    fillRecipient();
    fireEvent.change(screen.getByLabelText("选择印品文件"), {
      target: { files: [file("art.pdf")] },
    });
    fireEvent.click(screen.getByRole("button", { name: "立即下单" }));
    await waitFor(() =>
      expect(screen.getByText(/提交失败：network down/)).toBeTruthy(),
    );
    expect(screen.queryByText(/订单已提交/)).toBeNull();
    view.rerender(
      <OrderDetails
        {...properties}
        quote={{ ...properties.quote, createdAt: "recalculated-later" }}
      />,
    );
    fireEvent.click(screen.getByRole("button", { name: "立即下单" }));
    await waitFor(() =>
      expect(screen.getByText(/订单已提交，编号：order-2/)).toBeTruthy(),
    );
    expect(gateway.upload).toHaveBeenCalledTimes(1);
    expect(gateway.submit).toHaveBeenCalledTimes(2);
    const calls = (gateway.submit as ReturnType<typeof vi.fn>).mock.calls;
    expect(calls[0][1]).toBe(calls[1][1]);
    expect(calls[0][0]).toEqual(calls[1][0]);
    expect(calls[1][0].quote.createdAt).toBe(properties.quote.createdAt);
  });

  it("does not submit if unmounted while an upload is still resolving", async () => {
    let resolveUpload!: (value: { id: string; name: string }) => void;
    const gateway: OrderGateway = {
      upload: vi.fn().mockImplementation(
        () =>
          new Promise((resolve) => {
            resolveUpload = resolve;
          }),
      ),
      submit: vi.fn(),
    };
    const view = render(<OrderDetails {...props(gateway)} />);
    fillRecipient();
    fireEvent.change(screen.getByLabelText("选择印品文件"), {
      target: { files: [file("art.pdf")] },
    });
    fireEvent.click(screen.getByRole("button", { name: "立即下单" }));
    await waitFor(() => expect(gateway.upload).toHaveBeenCalledTimes(1));
    const signal = (gateway.upload as ReturnType<typeof vi.fn>).mock
      .calls[0][2] as AbortSignal;
    view.unmount();
    expect(signal.aborted).toBe(true);
    await act(async () => {
      resolveUpload({ id: "late-file", name: "art.pdf" });
    });
    expect(gateway.submit).not.toHaveBeenCalled();
  });

  it("rejects a quote for an outdated delivery method before upload", () => {
    const gateway: OrderGateway = { upload: vi.fn(), submit: vi.fn() };
    render(<OrderDetails {...props(gateway)} shipping="express" />);
    fireEvent.click(screen.getByRole("button", { name: "立即下单" }));
    expect(screen.getByText(/报价已变化/)).toBeTruthy();
    expect(gateway.upload).not.toHaveBeenCalled();
    expect(gateway.submit).not.toHaveBeenCalled();
  });
});
