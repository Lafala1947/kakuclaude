import { describe, expect, it } from "vitest";
import { defaultInput } from "../src/shared/contracts";
import { defaultConfig, validateConfig } from "../src/lib/config";
import { calculateQuote, validateInput } from "../src/lib/pricing";
import { parsePricingCsv, serializePricingCsv } from "../src/lib/csv";
import { readFileSync } from "node:fs";

const published = () => ({ ...defaultConfig, published: true, markup: 0.3 });

describe("workbook quotation", () => {
  it("matches the 127-up, 525-sheet workbook baseline without intermediate rounding", () => {
    const quote = calculateQuote(defaultInput, defaultConfig, {
      preview: true,
    });
    expect(quote.cost.imposition).toBe(127);
    expect(quote.cost.processingQuantity).toBe(525);
    expect(quote.cost.sheetTotal).toBeCloseTo(1011.8238125, 8);
    expect(quote.cost.total).toBeCloseTo(1011.8238125 / 127, 8);
    expect(quote.total).toBe(7.97);
  });

  it("charges foil by finished pattern area and each die-plate addition once", () => {
    const quote = calculateQuote(
      {
        ...defaultInput,
        crafts: ["foil", "texture", "emboss", "deboss", "texture"],
      },
      defaultConfig,
      { preview: true },
    );
    expect(quote.cost.sheetTotal).toBeCloseTo(1248.0738125, 8);
    expect(quote.cost.crafts.foil).toBeCloseTo(2.1, 8);
    expect(quote.cost.total).toBeCloseTo(1248.0738125 / 127 + 2.1, 8);
    expect(quote.input.crafts).toEqual(["foil", "texture", "emboss", "deboss"]);
  });

  it.each([0, 1, 2, 3])(
    "adds %i plate crafts to one base die plate",
    (count) => {
      const crafts = (["texture", "emboss", "deboss"] as const).slice(0, count);
      const quote = calculateQuote({ ...defaultInput, crafts }, defaultConfig, {
        preview: true,
      });
      expect(quote.cost.sheetTotal).toBeCloseTo(
        count ? 1188.0738125 + count * 20 : 1011.8238125,
        8,
      );
    },
  );

  it("applies markup to design per variant, adds unmarked freight, and balances displayed totals", () => {
    const config = published();
    config.design = { adjust: 15, custom: 25 };
    config.logistics = {
      ...config.logistics,
      enabled: true,
      firstWeight: 1,
      firstPrice: 8,
      additionalPrice: 3,
      packagingWeight: 0.2,
      remoteMultiplier: 2,
    };
    const quote = calculateQuote(
      {
        ...defaultInput,
        variants: 2,
        design: "custom",
        shipping: "express",
        region: "remote",
      },
      config,
    );
    expect(quote.cost.design).toBe(50);
    expect(quote.weight).toBeCloseTo(0.2 + 0.09 * 0.054 * 0.3 * 1000, 8);
    expect(quote.shippingTotal).toBe(22);
    expect(quote.total).toBe(107.71);
    expect(
      quote.productionTotal + quote.designTotal + quote.shippingTotal,
    ).toBeCloseTo(quote.total, 8);
  });

  it("requires publication for a public quote and permits unpublished cost preview", () => {
    expect(() => calculateQuote(defaultInput, defaultConfig)).toThrow(
      /发布|加价/,
    );
    expect(
      calculateQuote(defaultInput, defaultConfig, { preview: true }).total,
    ).toBe(7.97);
  });

  it("rejects impossible dimensions, variants beyond imposition, and invalid enums", () => {
    expect(() => validateInput({ ...defaultInput, width: -1 })).toThrow(
      /成品宽/,
    );
    expect(() => validateInput({ ...defaultInput, sides: 3 })).toThrow();
    expect(() =>
      calculateQuote({ ...defaultInput, variants: 128 }, defaultConfig, {
        preview: true,
      }),
    ).toThrow(/款数|拼数/);
    expect(() =>
      calculateQuote(
        { ...defaultInput, width: 0.1, height: 0.1 },
        defaultConfig,
        { preview: true },
      ),
    ).toThrow(/枚举|人工/);
  });

  it("requires a positive foil area and allows cumulative art on both faces", () => {
    expect(() =>
      validateInput({ ...defaultInput, crafts: ["foil"], foilArea: 0 }),
    ).toThrow(/烫金面积/);
    expect(
      validateInput({ ...defaultInput, crafts: ["foil"], foilArea: 80 })
        .foilArea,
    ).toBe(80);
    expect(() =>
      validateInput({ ...defaultInput, crafts: ["foil"], foilArea: 98 }),
    ).toThrow(/烫金面积/);
  });

  it("rejects express freight when shipping is disabled", () => {
    expect(() =>
      calculateQuote({ ...defaultInput, shipping: "express" }, defaultConfig, {
        preview: true,
      }),
    ).toThrow(/物流|快递/);
  });
});

describe("CSV configuration", () => {
  it("round-trips small valid rates without emitting exponent notation", () => {
    const config = {
      ...defaultConfig,
      finishing: {
        ...defaultConfig.finishing,
        foil: 0.0000001,
        lamination: 0.3,
      },
    };
    const csv = serializePricingCsv(config);
    expect(csv).toContain(",0.0000001,");
    expect(parsePricingCsv(csv)).toEqual(config);
  });
  it("round-trips every field including BOM, Chinese text, and quoted commas", () => {
    const config = {
      ...defaultConfig,
      paper: { ...defaultConfig.paper, name: "铜版纸,「高白」\n特选" },
    };
    const csv = serializePricingCsv(config);
    expect(csv.charCodeAt(0)).toBe(0xfeff);
    expect(parsePricingCsv(csv)).toEqual(config);
  });

  it("rejects incomplete, duplicate, unknown, and malformed CSV values", () => {
    const csv = serializePricingCsv(defaultConfig);
    expect(() =>
      parsePricingCsv(csv.replace(/paper,grammage|paper,gsm/, "paper,wrong")),
    ).toThrow();
    expect(() => parsePricingCsv(csv + csv.split("\r\n")[1] + "\r\n")).toThrow(
      /重复|格式/,
    );
    expect(() => parsePricingCsv(csv.replace(/,300,/, ",NaN,"))).toThrow();
  });

  it("rejects published configuration without a markup and spreadsheet formulas in text", () => {
    expect(() => validateConfig({ ...defaultConfig, published: true })).toThrow(
      /加价/,
    );
    expect(() =>
      validateConfig({
        ...defaultConfig,
        paper: { ...defaultConfig.paper, name: "=1+1" },
      }),
    ).toThrow();
  });

  it("ships a complete default CSV that parses to the exact built-in configuration", () => {
    const source = readFileSync("public/pricing.csv", "utf8");
    expect(source.charCodeAt(0)).toBe(0xfeff);
    expect(parsePricingCsv(source)).toEqual(defaultConfig);
  });
});

describe("expanded quotation catalog", () => {
  it("rejects unknown selections and prices that have not been configured", () => {
    expect(() =>
      validateInput({ ...defaultInput, material: "fake" }),
    ).toThrow();
    expect(() =>
      validateInput({ ...defaultInput, extras: ["fake"] }),
    ).toThrow();
    expect(() =>
      validateInput({ ...defaultInput, extras: ["uv", "uv"] }),
    ).toThrow();
    expect(() =>
      calculateQuote({ ...defaultInput, material: "white300" }, defaultConfig, {
        preview: true,
      }),
    ).toThrow(/纸|材料|配置/);
    expect(() =>
      calculateQuote({ ...defaultInput, ink: "spot" }, defaultConfig, {
        preview: true,
      }),
    ).toThrow(/专色|配置/);
    expect(() =>
      calculateQuote({ ...defaultInput, extras: ["uv"] }, defaultConfig, {
        preview: true,
      }),
    ).toThrow(/工艺|配置/);
  });

  it("uses the selected paper weight and ton price for production and shipping", () => {
    const config = structuredClone(defaultConfig);
    config.materials.market350 = {
      name: "市场350克铜版纸",
      gsm: 350,
      tonPrice: 5000,
      enabled: true,
    };
    const input = {
      ...defaultInput,
      material: "market350" as const,
      shipping: "express" as const,
    };
    config.logistics.enabled = true;
    const quote = calculateQuote(input, config, { preview: true });
    expect(quote.cost.paper).toBeCloseTo(
      (525 * 0.72215 * 350 * 5000) / 1e6 / 127,
      8,
    );
    expect(quote.weight).toBeCloseTo(0.09 * 0.054 * 0.35 * 500 + 0.2, 8);
  });

  it("requires a single selected coating and its number of sides", () => {
    expect(() =>
      validateInput({
        ...defaultInput,
        extras: ["matte", "gloss"],
        lamination: 1,
      }),
    ).toThrow(/覆膜|工艺/);
    expect(() =>
      validateInput({ ...defaultInput, extras: ["matte"], lamination: 0 }),
    ).toThrow(/覆膜/);
    expect(() =>
      validateInput({ ...defaultInput, extras: ["circle"], circleDiameter: 0 }),
    ).toThrow(/直径/);
    expect(() =>
      validateInput({
        ...defaultInput,
        extras: ["circle"],
        width: 40,
        height: 40,
        circleDiameter: 41,
      }),
    ).toThrow(/直径|圆形/);
    expect(() =>
      validateInput({ ...defaultInput, extras: ["sameKnife"] }),
    ).toThrow(/款/);
  });

  it("replaces generic lamination with selected coating and adds each setup once", () => {
    const config = structuredClone(defaultConfig);
    config.extras.matte = {
      enabled: true,
      rate: 2,
      setup: 3,
      unit: "sheetAreaSide",
    };
    const quote = calculateQuote(
      { ...defaultInput, extras: ["matte"], lamination: 2 },
      config,
      { preview: true },
    );
    expect(quote.cost.sheetTotal).toBeCloseTo(1011.8238125, 8);
    expect(quote.cost.crafts.matte).toBeCloseTo(
      ((2 * 0.72215 * 525) / 127) * 2 + 3,
      8,
    );
    expect(quote.cost.total).toBeCloseTo(
      1011.8238125 / 127 + ((2 * 0.72215 * 525) / 127) * 2 + 3,
      8,
    );
  });

  it.each([
    ["piece", 1053],
    ["sheet", (2 * 525) / 127 + 3],
    ["area", 2 * 0.00486 * 525 + 3],
    ["order", 5],
    ["variant", 5],
  ] as const)("prices a selected extra by %s", (unit, expected) => {
    const config = structuredClone(defaultConfig);
    config.extras.uv = { enabled: true, rate: 2, setup: 3, unit };
    const quote = calculateQuote({ ...defaultInput, extras: ["uv"] }, config, {
      preview: true,
    });
    expect(quote.cost.crafts.uv).toBeCloseTo(expected, 8);
  });

  it("charges one base die when several shape and premium options need it", () => {
    const config = structuredClone(defaultConfig);
    for (const id of ["premiumDie", "circle", "roundCorners"] as const)
      config.extras[id] = { enabled: true, rate: 2, setup: 0, unit: "order" };
    const quote = calculateQuote(
      {
        ...defaultInput,
        width: 40,
        height: 40,
        circleDiameter: 40,
        extras: ["premiumDie", "circle", "roundCorners"],
      },
      config,
      { preview: true },
    );
    const baseDie = calculateQuote(
      {
        ...defaultInput,
        width: 40,
        height: 40,
        circleDiameter: 40,
        cutting: "die",
      },
      config,
      { preview: true },
    );
    expect(quote.cost.sheetTotal).toBeCloseTo(baseDie.cost.sheetTotal, 8);
    expect(quote.cost.crafts.premiumDie).toBe(2);
    expect(quote.cost.crafts.circle).toBe(2);
    expect(quote.cost.crafts.roundCorners).toBe(2);
  });

  it("adds configured spot ink to printing while keeping sheet total on the base formula", () => {
    const config = structuredClone(defaultConfig);
    config.spotInk = { enabled: true, rate: 2, setup: 3, unit: "sheet" };
    const quote = calculateQuote({ ...defaultInput, ink: "spot" }, config, {
      preview: true,
    });
    expect(quote.cost.sheetTotal).toBeCloseTo(1011.8238125, 8);
    expect(quote.cost.crafts.spotInk).toBeCloseTo((2 * 525) / 127 + 3, 8);
    expect(quote.cost.printing).toBeCloseTo(500 / 127 + (2 * 525) / 127 + 3, 8);
  });

  it("normalizes a complete legacy config but rejects a partial extension", () => {
    const legacy = structuredClone(defaultConfig) as unknown as Record<
      string,
      unknown
    >;
    delete legacy.materials;
    delete legacy.spotInk;
    delete legacy.extras;
    expect(validateConfig(legacy)).toEqual(defaultConfig);
    expect(() =>
      validateConfig({ ...legacy, materials: defaultConfig.materials }),
    ).toThrow();
  });

  it("rejects sheet-area-side pricing for spot ink and non-coating crafts", () => {
    const spot = structuredClone(defaultConfig);
    spot.spotInk = { enabled: true, rate: 2, setup: 0, unit: "sheetAreaSide" };
    expect(() => validateConfig(spot)).toThrow(/专色印刷.*计费单位/);

    const extra = structuredClone(defaultConfig);
    extra.extras.uv = {
      enabled: true,
      rate: 2,
      setup: 0,
      unit: "sheetAreaSide",
    };
    expect(() => validateConfig(extra)).toThrow(/局部UV.*计费单位/);
  });

  it("migrates the old CSV only when all extension rows are absent", () => {
    const csv = serializePricingCsv(defaultConfig);
    const old = csv
      .split("\r\n")
      .filter((row) => !/^(materials|spotInk|extras),/.test(row))
      .join("\r\n");
    expect(parsePricingCsv(old)).toEqual(defaultConfig);
    expect(() =>
      parsePricingCsv(csv.replace(/^extras,uv\.rate,.*\r\n/m, "")),
    ).toThrow(/不完整|缺少/);
  });

  it("round-trips configured catalog fees and safe text", () => {
    const config = structuredClone(defaultConfig);
    config.materials.white300 = {
      name: "白卡,高白",
      gsm: 300,
      tonPrice: 4500,
      enabled: true,
    };
    config.spotInk = {
      enabled: true,
      rate: 0.0000001,
      setup: 10,
      unit: "sheet",
    };
    config.extras.uv = { enabled: true, rate: 0.25, setup: 8, unit: "area" };
    const csv = serializePricingCsv(config);
    expect(csv).toContain(",0.0000001,");
    expect(parsePricingCsv(csv)).toEqual(config);
  });
});
