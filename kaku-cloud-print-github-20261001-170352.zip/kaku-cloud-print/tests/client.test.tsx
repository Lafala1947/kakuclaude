// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
  within,
} from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import type { PricingConfig } from "../src/shared/contracts";
import { defaultConfig } from "../src/lib/config";
import { parsePricingCsv } from "../src/lib/csv";
import QuotePage from "../src/client/QuotePage";
import AdminPage from "../src/client/AdminPage";
import { DraftProvider } from "../src/client/DraftContext";

const download = vi.hoisted(() => vi.fn());
vi.mock("../src/client/utils", async () => ({
  ...(await vi.importActual("../src/client/utils")),
  download,
}));
afterEach(() => {
  cleanup();
  localStorage.clear();
  download.mockClear();
});
const published = (): PricingConfig => ({
  ...structuredClone(defaultConfig),
  published: true,
  markup: 0.3,
});

describe("static quotation workflow", () => {
  it("quotes configured materials and mutually exclusive coatings with a circle specification", () => {
    const config = published();
    config.materials.market350.enabled = true;
    config.materials.market350.tonPrice = 5000;
    for (const id of ["matte", "gloss", "circle"] as const) {
      config.extras[id].enabled = true;
      config.extras[id].rate = 0.3;
    }
    render(
      <MemoryRouter>
        <QuotePage config={config} />
      </MemoryRouter>,
    );
    fireEvent.click(screen.getByRole("button", { name: "市场350克铜版纸" }));
    fireEvent.click(screen.getByRole("checkbox", { name: "哑膜" }));
    fireEvent.click(screen.getByRole("checkbox", { name: "亮膜" }));
    expect(
      (screen.getByRole("checkbox", { name: "哑膜" }) as HTMLInputElement)
        .checked,
    ).toBe(false);
    fireEvent.click(screen.getByRole("checkbox", { name: "圆形" }));
    expect(
      (screen.getByRole("spinbutton", { name: "成品宽度" }) as HTMLInputElement)
        .value,
    ).toBe("40");
    expect(
      (screen.getByRole("checkbox", { name: "模切" }) as HTMLInputElement)
        .checked,
    ).toBe(true);
    fireEvent.click(screen.getByRole("button", { name: "算价" }));
    fireEvent.click(screen.getByRole("button", { name: "生成报价单" }));
    fireEvent.click(
      within(screen.getByRole("dialog")).getByRole("button", {
        name: "下载报价单",
      }),
    );
    expect(download.mock.calls[0][0]).toContain("市场350克铜版纸");
    expect(download.mock.calls[0][0]).toContain("40 × 40 mm");
    expect(download.mock.calls[0][0]).toContain("亮膜");
    expect(download.mock.calls[0][0]).not.toContain("哑膜");
  });
  it("keeps foil area and shipping region in the downloadable quotation", () => {
    const config = published();
    config.logistics.enabled = true;
    config.logistics.firstPrice = 8;
    render(
      <MemoryRouter>
        <QuotePage config={config} />
      </MemoryRouter>,
    );
    fireEvent.click(screen.getByRole("checkbox", { name: "热烫" }));
    fireEvent.change(screen.getByRole("spinbutton", { name: "每张烫金面积" }), {
      target: { value: "20" },
    });
    fireEvent.click(screen.getByRole("button", { name: "快递配送" }));
    fireEvent.change(screen.getByRole("combobox", { name: "配送区域" }), {
      target: { value: "remote" },
    });
    fireEvent.click(screen.getByRole("button", { name: "算价" }));
    fireEvent.click(screen.getByRole("button", { name: "生成报价单" }));
    const dialog = screen.getByRole("dialog");
    expect(within(dialog).getByText("20 cm²")).toBeTruthy();
    expect(within(dialog).getByText("偏远地区")).toBeTruthy();
    fireEvent.click(within(dialog).getByRole("button", { name: "下载报价单" }));
    expect(download.mock.calls[0][0]).toContain("快递配送");
    expect(download.mock.calls[0][0]).toContain("偏远地区");
    expect(download.mock.calls[0][0]).toContain("20 cm²");
  });
  it("blocks unpublished quotations while leaving specification choices usable", () => {
    render(
      <MemoryRouter>
        <QuotePage config={defaultConfig} />
      </MemoryRouter>,
    );
    expect(
      (screen.getByRole("button", { name: "生成报价单" }) as HTMLButtonElement)
        .disabled,
    ).toBe(true);
    expect(screen.getByText(/费用表尚未发布/)).toBeTruthy();
    fireEvent.click(screen.getByRole("radio", { name: "单面" }));
    expect(
      (screen.getByRole("radio", { name: "单面" }) as HTMLInputElement).checked,
    ).toBe(true);
    expect(
      (screen.getByRole("checkbox", { name: /^哑膜/ }) as HTMLInputElement)
        .disabled,
    ).toBe(true);
  });
  it("recalculates a changed specification and includes selected services in quote export", () => {
    const config = published();
    config.design.custom = 80;
    render(
      <MemoryRouter>
        <QuotePage config={config} />
      </MemoryRouter>,
    );
    fireEvent.click(screen.getByRole("button", { name: "算价" }));
    expect(screen.getByText("10.36")).toBeTruthy();
    fireEvent.click(screen.getByRole("radio", { name: "定制设计" }));
    expect(screen.queryByText("10.36")).toBeNull();
    expect(
      (screen.getByRole("button", { name: "生成报价单" }) as HTMLButtonElement)
        .disabled,
    ).toBe(true);
    fireEvent.click(screen.getByRole("button", { name: "算价" }));
    expect(screen.getByText("114.36")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "生成报价单" }));
    const dialog = screen.getByRole("dialog");
    expect(within(dialog).getByText("定制设计")).toBeTruthy();
    fireEvent.click(within(dialog).getByRole("button", { name: "下载报价单" }));
    expect(download.mock.calls[0][0]).toContain("114.36");
    expect(download.mock.calls[0][0]).toContain("定制设计");
    fireEvent.keyDown(document, { key: "Escape" });
    expect(screen.queryByRole("dialog")).toBeNull();
    fireEvent.change(screen.getByRole("spinbutton", { name: "成品宽度" }), {
      target: { value: "0" },
    });
    expect(
      (screen.getByRole("button", { name: "生成报价单" }) as HTMLButtonElement)
        .disabled,
    ).toBe(true);
    expect(screen.queryByText("114.36")).toBeNull();
  });
});

describe("CSV administration", () => {
  it("exports independently configured extra processing fees with their units", () => {
    render(
      <MemoryRouter>
        <AdminPage deployed={published()} onReload={async () => {}} />
      </MemoryRouter>,
    );
    fireEvent.click(screen.getByRole("checkbox", { name: "启用局部UV" }));
    fireEvent.change(
      screen.getByRole("spinbutton", { name: "局部UV加工单价" }),
      { target: { value: "0.25" } },
    );
    fireEvent.change(screen.getByRole("spinbutton", { name: "局部UV起步费" }), {
      target: { value: "30" },
    });
    const units = screen.getByRole("combobox", { name: "局部UV计价单位" });
    expect(
      within(units).queryByRole("option", { name: "元 / 大纸㎡ / 面" }),
    ).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "导出费用表" }));
    expect(parsePricingCsv(download.mock.calls[0][0]).extras.uv).toEqual({
      enabled: true,
      rate: 0.25,
      setup: 30,
      unit: "piece",
    });
  });
  it("preserves unsaved editing across page unmount and reloading deployed settings", () => {
    const config = published();
    const view = render(
      <DraftProvider>
        <MemoryRouter>
          <AdminPage deployed={config} onReload={async () => {}} />
        </MemoryRouter>
      </DraftProvider>,
    );
    fireEvent.change(screen.getByRole("spinbutton", { name: "烫金加工" }), {
      target: { value: "9" },
    });
    view.rerender(
      <DraftProvider>
        <MemoryRouter>
          <div>前台报价</div>
        </MemoryRouter>
      </DraftProvider>,
    );
    view.rerender(
      <DraftProvider>
        <MemoryRouter>
          <AdminPage
            deployed={{ ...published(), version: 3 }}
            onReload={async () => {}}
          />
        </MemoryRouter>
      </DraftProvider>,
    );
    expect(
      (screen.getByRole("spinbutton", { name: "烫金加工" }) as HTMLInputElement)
        .value,
    ).toBe("9");
    fireEvent.click(screen.getByRole("button", { name: "导出费用表" }));
    expect(parsePricingCsv(download.mock.calls[0][0]).version).toBe(4);
  });
  it("edits per-craft costs and exports a validated configuration without mutating deployed settings", () => {
    const deployed = published();
    render(
      <MemoryRouter>
        <AdminPage deployed={deployed} onReload={async () => {}} />
      </MemoryRouter>,
    );
    fireEvent.change(screen.getByRole("spinbutton", { name: "烫金加工" }), {
      target: { value: "6.25" },
    });
    fireEvent.click(screen.getByRole("button", { name: "导出费用表" }));
    const exported = parsePricingCsv(download.mock.calls[0][0]);
    expect(exported.finishing.foil).toBe(6.25);
    expect(exported.version).toBe(2);
    expect(deployed.finishing.foil).toBe(4);
    expect(screen.getByText(/请上传覆盖网站目录/)).toBeTruthy();
  });
  it("retains a saved local draft and rejects invalid config exports", () => {
    const view = render(
      <MemoryRouter>
        <AdminPage deployed={published()} onReload={async () => {}} />
      </MemoryRouter>,
    );
    fireEvent.change(screen.getByRole("spinbutton", { name: "烫金加工" }), {
      target: { value: "8" },
    });
    fireEvent.click(screen.getByRole("button", { name: "保存本机草稿" }));
    view.unmount();
    render(
      <MemoryRouter>
        <AdminPage deployed={published()} onReload={async () => {}} />
      </MemoryRouter>,
    );
    expect(
      (screen.getByRole("spinbutton", { name: "烫金加工" }) as HTMLInputElement)
        .value,
    ).toBe("4");
    fireEvent.click(screen.getByRole("button", { name: "恢复本机草稿" }));
    expect(
      (screen.getByRole("spinbutton", { name: "烫金加工" }) as HTMLInputElement)
        .value,
    ).toBe("8");
    fireEvent.change(screen.getByRole("spinbutton", { name: "烫金加工" }), {
      target: { value: "-1" },
    });
    fireEvent.click(screen.getByRole("button", { name: "导出费用表" }));
    expect(download).not.toHaveBeenCalled();
    expect(
      screen
        .getAllByRole("alert")
        .some((x) => x.textContent?.includes("烫金费")),
    ).toBe(true);
  });
  it("rejects malformed imports and keeps the currently edited fees", async () => {
    render(
      <MemoryRouter>
        <AdminPage deployed={published()} onReload={async () => {}} />
      </MemoryRouter>,
    );
    fireEvent.change(screen.getByRole("spinbutton", { name: "烫金加工" }), {
      target: { value: "7" },
    });
    const malformed = {
      name: "bad.csv",
      size: 25,
      text: async () =>
        "category,key,name,value,unit,description\nfinishing,foil,烫金,2,元,费用",
    };
    fireEvent.change(screen.getByLabelText("导入CSV费用表"), {
      target: { files: [malformed] },
    });
    await waitFor(() => expect(screen.getByRole("alert")).toBeTruthy());
    expect(
      (screen.getByRole("spinbutton", { name: "烫金加工" }) as HTMLInputElement)
        .value,
    ).toBe("7");
  });
});
