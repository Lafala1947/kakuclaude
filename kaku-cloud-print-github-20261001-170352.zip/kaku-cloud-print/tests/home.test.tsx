// @vitest-environment jsdom
import { afterEach, describe, it, expect, vi } from "vitest";
import {
  cleanup,
  render,
  screen,
  fireEvent,
  waitFor,
  within,
  act,
} from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import App from "../src/client/App";
import { MemberProvider } from "../src/client/members/MemberContext";
import { defaultConfig } from "../src/lib/config";
import { serializePricingCsv } from "../src/lib/csv";
import { defaultHomepage, serializeHomepage } from "../src/shared/homepage";
import { defaultProducts, serializeProducts } from "../src/shared/products";
afterEach(() => {
  cleanup();
  vi.restoreAllMocks();
  Object.defineProperty(window, "scrollY", { value: 0, configurable: true });
});
function setup(path = "/") {
  return render(
    <MemoryRouter initialEntries={[path]}>
      <MemberProvider>
        <App />
      </MemberProvider>
    </MemoryRouter>,
  );
}
describe("home and quotation navigation", () => {
  it("does not jump back to the top when background pricing finishes loading", async () => {
    let complete!: (response: Response) => void;
    vi.spyOn(globalThis, "fetch").mockImplementation((input) =>
      String(input).includes("homepage.json")
        ? Promise.resolve(new Response(serializeHomepage(defaultHomepage)))
        : String(input).includes("products.json")
          ? Promise.resolve(new Response(serializeProducts(defaultProducts)))
          : new Promise((resolve) => {
              complete = resolve;
            }),
    );
    const scroll = vi.spyOn(window, "scrollTo").mockImplementation(() => {});
    setup();
    Object.defineProperty(window, "scrollY", {
      value: 300,
      configurable: true,
    });
    await act(async () => {
      complete(
        new Response(serializePricingCsv(structuredClone(defaultConfig))),
      );
    });
    expect(scroll).not.toHaveBeenCalled();
  });
  it("shows the homepage independently of pricing availability", async () => {
    vi.spyOn(globalThis, "fetch").mockRejectedValue(new Error("offline"));
    setup();
    expect(
      screen.getByRole("heading", { level: 1, name: /多材质卡片/ }),
    ).toBeTruthy();
    expect(
      screen.getByRole("link", { name: "开始在线报价" }).getAttribute("href"),
    ).toBe("/quote");
    await waitFor(() => expect(globalThis.fetch).toHaveBeenCalled());
    expect(
      screen.queryByRole("heading", { name: "暂时无法加载报价配置" }),
    ).toBeNull();
  });
  it("opens the working quote from the homepage and returns through the brand", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue(
      new Response(
        serializePricingCsv({
          ...structuredClone(defaultConfig),
          published: true,
          markup: 0.3,
        }),
      ),
    );
    setup();
    fireEvent.click(screen.getByRole("link", { name: "开始在线报价" }));
    await waitFor(() =>
      expect(screen.getByRole("heading", { name: "产品信息" })).toBeTruthy(),
    );
    fireEvent.click(screen.getByRole("button", { name: "算价" }));
    expect(screen.getByText("10.36")).toBeTruthy();
    expect(
      screen.queryByRole("heading", { level: 1, name: /多材质卡片/ }),
    ).toBeNull();
    fireEvent.click(screen.getByRole("link", { name: "卡库云印首页" }));
    expect(
      screen.getByRole("heading", { level: 1, name: /多材质卡片/ }),
    ).toBeTruthy();
  });
  it("retains pricing guide deep links and quote return links on member pages", async () => {
    vi.spyOn(globalThis, "fetch").mockResolvedValue(
      new Response(serializePricingCsv(structuredClone(defaultConfig))),
    );
    const view = setup("/#guide");
    await waitFor(() =>
      expect(
        screen.getByRole("heading", { name: "好的印品，从文件开始" }),
      ).toBeTruthy(),
    );
    view.unmount();
    setup("/login");
    expect(
      screen.getByRole("link", { name: "返回报价页" }).getAttribute("href"),
    ).toBe("/quote");
    expect(
      within(screen.getByRole("navigation", { name: "主导航" }))
        .getByRole("link", { name: "首页" })
        .getAttribute("href"),
    ).toBe("/");
  });
});
