// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  cleanup,
  fireEvent,
  render,
  screen,
  waitFor,
} from "@testing-library/react";
import type { ApiOrder } from "../src/shared/api";
import { defaultInput } from "../src/shared/contracts";
import { calculateQuote } from "../src/lib/pricing";
import { defaultConfig } from "../src/lib/config";
import { fileChecks, initialFileReview } from "../src/shared/file-review";
import FileReviewPanel from "../src/client/order/FileReviewPanel";
const mocks = vi.hoisted(() => ({ request: vi.fn(), upload: vi.fn() }));
vi.mock("../src/client/api/client", () => ({
  apiRequest: mocks.request,
  apiFileUrl: (id: string) => `/api/files/${id}`,
}));
vi.mock("../src/client/order/apiGateway", () => ({
  apiOrderGateway: { upload: mocks.upload },
}));
function order(): ApiOrder {
  return {
    id: "order1",
    memberId: "member1",
    createdAt: "2026-10-01T00:00:00Z",
    status: "submitted",
    quote: {
      ...calculateQuote(defaultInput, {
        ...defaultConfig,
        published: true,
        markup: 0.3,
      }),
      quoteId: "quote1",
      expiresAt: "2099-01-01",
    },
    recipient: { name: "会员", phone: "13800138000", region: "", address: "" },
    contact: "13800138000",
    orderName: "卡片",
    notes: "",
    files: [{ id: "file1", name: "旧稿.pdf", kind: "print", size: 30 }],
    fileReview: initialFileReview(),
  };
}
afterEach(() => {
  cleanup();
  mocks.request.mockReset();
  mocks.upload.mockReset();
});
describe("manual file review", () => {
  it("requires every check before approval and a reason before rejection", async () => {
    render(<FileReviewPanel order={order()} admin onUpdated={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: "审核文件" }));
    fireEvent.click(screen.getByRole("button", { name: "确认审核通过" }));
    expect(screen.getByRole("alert").textContent).toContain("全部文件检查");
    fireEvent.click(screen.getByRole("button", { name: "退回修改" }));
    expect(screen.getByRole("alert").textContent).toContain("退回原因");
    expect(mocks.request).not.toHaveBeenCalled();
  });
  it("records the current revision and manual checks, rendering server-confirmed approval", async () => {
    const original = order(),
      onUpdated = vi.fn();
    mocks.request.mockResolvedValue({
      order: {
        ...original,
        fileReview: { ...initialFileReview(), revision: 2, status: "approved" },
      },
    });
    render(<FileReviewPanel order={original} admin onUpdated={onUpdated} />);
    fireEvent.click(screen.getByRole("button", { name: "审核文件" }));
    for (const check of fileChecks)
      fireEvent.click(
        screen.getByRole("checkbox", { name: new RegExp(check.label) }),
      );
    fireEvent.change(screen.getByLabelText("审核意见 / 退回原因"), {
      target: { value: "尺寸与刀线一致" },
    });
    fireEvent.click(screen.getByRole("button", { name: "确认审核通过" }));
    await waitFor(() => expect(onUpdated).toHaveBeenCalledOnce());
    expect(JSON.parse(mocks.request.mock.calls[0][1].body)).toEqual({
      revision: 1,
      decision: "approved",
      checks: fileChecks.map((check) => check.id),
      comment: "尺寸与刀线一致",
    });
    expect(onUpdated.mock.calls[0][0].fileReview.status).toBe("approved");
  });
  it("preserves rejection input and prompts refresh after an optimistic conflict", async () => {
    mocks.request.mockRejectedValue(
      Object.assign(new Error("审核版本已变化"), { status: 409 }),
    );
    render(<FileReviewPanel order={order()} admin onUpdated={vi.fn()} />);
    fireEvent.click(screen.getByRole("button", { name: "审核文件" }));
    fireEvent.change(screen.getByLabelText("审核意见 / 退回原因"), {
      target: { value: "第1页缺出血" },
    });
    fireEvent.click(screen.getByRole("button", { name: "退回修改" }));
    expect((await screen.findByRole("alert")).textContent).toContain(
      "刷新订单",
    );
    expect(
      (screen.getByLabelText("审核意见 / 退回原因") as HTMLTextAreaElement)
        .value,
    ).toBe("第1页缺出血");
  });
  it("lets the member replace rejected artwork without sending quote or price changes", async () => {
    const original = order();
    original.fileReview = {
      ...initialFileReview(),
      status: "rejected",
      revision: 2,
      comment: "缺出血",
    };
    mocks.upload.mockResolvedValue({ id: "file2", name: "新稿.pdf" });
    mocks.request.mockResolvedValue({
      order: {
        ...original,
        files: [{ id: "file2", name: "新稿.pdf", size: 3, kind: "print" }],
        fileReview: { ...initialFileReview(), revision: 3, fileVersion: 2 },
      },
    });
    const updated = vi.fn();
    render(
      <FileReviewPanel order={original} admin={false} onUpdated={updated} />,
    );
    fireEvent.click(screen.getByRole("button", { name: "修改文件并重新送审" }));
    fireEvent.click(screen.getByRole("checkbox", { name: "保留 旧稿.pdf" }));
    fireEvent.change(screen.getByLabelText("上传修改后的印品文件"), {
      target: { files: [new File(["pdf"], "新稿.pdf")] },
    });
    fireEvent.change(screen.getByLabelText("修改说明"), {
      target: { value: "已补出血" },
    });
    fireEvent.click(screen.getByRole("button", { name: "提交新版本送审" }));
    await waitFor(() => expect(updated).toHaveBeenCalledOnce());
    expect(mocks.upload).toHaveBeenCalledOnce();
    expect(JSON.parse(mocks.request.mock.calls[0][1].body)).toEqual({
      revision: 2,
      files: { print: ["file2"], proof: [], certificate: [] },
      comment: "已补出血",
    });
  });
  it("reuses already uploaded replacement files on retry and never permits member approval", async () => {
    const original = order();
    original.fileReview!.status = "rejected";
    mocks.upload.mockResolvedValue({ id: "new-file", name: "新稿.pdf" });
    mocks.request
      .mockRejectedValueOnce(new Error("连接中断"))
      .mockResolvedValueOnce({ order: original });
    render(
      <FileReviewPanel order={original} admin={false} onUpdated={vi.fn()} />,
    );
    expect(screen.queryByRole("button", { name: "审核文件" })).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "修改文件并重新送审" }));
    fireEvent.change(screen.getByLabelText("上传修改后的印品文件"), {
      target: { files: [new File(["pdf"], "新稿.pdf")] },
    });
    fireEvent.click(screen.getByRole("button", { name: "提交新版本送审" }));
    await screen.findByText("连接中断");
    fireEvent.click(screen.getByRole("button", { name: "提交新版本送审" }));
    await waitFor(() => expect(mocks.request).toHaveBeenCalledTimes(2));
    expect(mocks.upload).toHaveBeenCalledOnce();
  });
  it("locks both review and file replacement after production starts and preserves history download", () => {
    const original = order();
    original.status = "producing";
    original.fileReview!.history = [
      {
        id: "event1",
        action: "approved",
        fileVersion: 1,
        actor: { id: "sales1", name: "审稿员" },
        createdAt: "2026-10-01",
        comment: "核对无误",
        checks: fileChecks.map((check) => check.id),
        files: original.files,
      },
    ];
    render(<FileReviewPanel order={original} admin onUpdated={vi.fn()} />);
    expect(screen.queryByRole("button", { name: "审核文件" })).toBeNull();
    expect(
      screen.getByRole("link", { name: "旧稿.pdf" }).getAttribute("href"),
    ).toBe("/api/files/file1");
  });
});
