// @vitest-environment jsdom
import { afterEach, describe, expect, it, vi } from "vitest";
import {
  cleanup,
  fireEvent,
  render,
  screen,
  within,
  waitFor,
} from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import AuthPage from "../src/client/members/AuthPage";
import MemberAdmin from "../src/client/members/MemberAdmin";
import { MemberProvider } from "../src/client/members/MemberContext";
import App from "../src/client/App";

afterEach(() => {
  cleanup();
  localStorage.clear();
  vi.restoreAllMocks();
});
function admin() {
  return render(
    <MemoryRouter>
      <MemberProvider>
        <MemberAdmin />
      </MemberProvider>
    </MemoryRouter>,
  );
}
describe("membership page previews", () => {
  it("returns keyboard focus to search when an edited row leaves the filter", () => {
    admin();
    fireEvent.change(screen.getByLabelText("账号状态筛选"), {
      target: { value: "active" },
    });
    const trigger = screen.getByRole("button", { name: "查看 演示客户 01" });
    trigger.focus();
    fireEvent.click(trigger);
    fireEvent.click(
      within(screen.getByRole("dialog")).getByLabelText("启用账号"),
    );
    fireEvent.click(screen.getByRole("button", { name: "保存预览修改" }));
    expect(screen.queryByText("演示客户 01")).toBeNull();
    expect(document.activeElement).toBe(
      screen.getByRole("searchbox", { name: "搜索会员" }),
    );
  });
  it("validates registration without creating an account, storing passwords, or sending requests", () => {
    const fetch = vi.spyOn(globalThis, "fetch");
    const storage = vi.spyOn(Storage.prototype, "setItem");
    render(
      <MemoryRouter>
        <AuthPage mode="register" />
      </MemoryRouter>,
    );
    fireEvent.change(screen.getByLabelText("邮箱"), {
      target: { value: "member@example.com" },
    });
    fireEvent.change(screen.getByLabelText("联系人"), {
      target: { value: "演示客户" },
    });
    fireEvent.change(screen.getByLabelText("密码", { exact: true }), {
      target: { value: "123" },
    });
    fireEvent.change(screen.getByLabelText("确认密码"), {
      target: { value: "different" },
    });
    fireEvent.click(screen.getByRole("button", { name: "预览注册校验" }));
    expect(screen.getByRole("alert").textContent).toContain("至少 8 位");
    fireEvent.change(screen.getByLabelText("密码", { exact: true }), {
      target: { value: "Sample1234" },
    });
    fireEvent.click(screen.getByRole("button", { name: "预览注册校验" }));
    expect(screen.getByRole("alert").textContent).toContain("两次密码");
    fireEvent.change(screen.getByLabelText("确认密码"), {
      target: { value: "Sample1234" },
    });
    fireEvent.click(screen.getByRole("button", { name: "预览注册校验" }));
    expect(screen.getByRole("status").textContent).toContain("未创建账号");
    expect(fetch).not.toHaveBeenCalled();
    expect(storage).not.toHaveBeenCalled();
  });
  it("keeps login a validation preview and clears obsolete success on edit", () => {
    render(
      <MemoryRouter>
        <AuthPage mode="login" />
      </MemoryRouter>,
    );
    fireEvent.change(screen.getByLabelText("邮箱"), {
      target: { value: "a@example.com" },
    });
    fireEvent.change(screen.getByLabelText("密码", { exact: true }), {
      target: { value: "Example123" },
    });
    fireEvent.click(screen.getByRole("button", { name: "显示密码" }));
    expect(
      (screen.getByLabelText("密码", { exact: true }) as HTMLInputElement).type,
    ).toBe("text");
    fireEvent.click(screen.getByRole("button", { name: "预览登录校验" }));
    expect(screen.getByRole("status").textContent).toContain("未登录");
    fireEvent.change(screen.getByLabelText("邮箱"), {
      target: { value: "bad" },
    });
    expect(screen.queryByRole("status")).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "预览登录校验" }));
    expect(screen.getByRole("alert").textContent).toContain("邮箱");
  });
  it("filters demo members and updates their tier and status in preview only", () => {
    admin();
    fireEvent.change(screen.getByRole("searchbox", { name: "搜索会员" }), {
      target: { value: "member001@example.com" },
    });
    expect(screen.getByText("演示客户 01")).toBeTruthy();
    expect(screen.queryByText("演示客户 02")).toBeNull();
    fireEvent.click(screen.getByRole("button", { name: "查看 演示客户 01" }));
    const dialog = screen.getByRole("dialog");
    fireEvent.change(within(dialog).getByLabelText("会员等级"), {
      target: { value: "gold" },
    });
    fireEvent.click(within(dialog).getByLabelText("启用账号"));
    fireEvent.click(
      within(dialog).getByRole("button", { name: "保存预览修改" }),
    );
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByRole("status").textContent).toContain("未保存到服务器");
    const row = screen.getByText("演示客户 01").closest("tr")!;
    expect(within(row).getByText("金卡会员")).toBeTruthy();
    expect(within(row).getByText("已停用")).toBeTruthy();
    fireEvent.change(screen.getByLabelText("账号状态筛选"), {
      target: { value: "active" },
    });
    expect(screen.getByText("没有符合条件的会员")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "清除筛选" }));
    expect(screen.getByText("演示客户 02")).toBeTruthy();
  });
  it("rejects invalid tier discounts and propagates valid tier names to the member list", () => {
    admin();
    fireEvent.click(screen.getByRole("tab", { name: "会员等级" }));
    fireEvent.change(screen.getByLabelText("普通会员折扣"), {
      target: { value: "0" },
    });
    fireEvent.click(screen.getByRole("button", { name: "保存等级预览" }));
    expect(screen.getByRole("alert").textContent).toContain("大于 0");
    fireEvent.change(screen.getByLabelText("普通会员折扣"), {
      target: { value: "100" },
    });
    fireEvent.change(screen.getByLabelText("普通会员名称"), {
      target: { value: "基础会员" },
    });
    fireEvent.click(screen.getByRole("button", { name: "保存等级预览" }));
    fireEvent.click(screen.getByRole("tab", { name: "会员列表" }));
    expect(screen.getAllByText("基础会员").length).toBeGreaterThan(0);
  });
  it("keeps registration accessible when the pricing CSV request fails", async () => {
    vi.spyOn(globalThis, "fetch").mockRejectedValue(new Error("offline"));
    render(
      <MemoryRouter initialEntries={["/register"]}>
        <MemberProvider>
          <App />
        </MemberProvider>
      </MemoryRouter>,
    );
    await waitFor(() =>
      expect(screen.getByRole("heading", { name: "注册会员" })).toBeTruthy(),
    );
    expect(
      screen.queryByRole("heading", { name: "暂时无法加载报价配置" }),
    ).toBeNull();
  });
  it("resets pagination after filtering and rejects a duplicate email before changing the member", () => {
    admin();
    fireEvent.click(screen.getByRole("button", { name: "下一页" }));
    expect(screen.getByText("演示客户 07")).toBeTruthy();
    expect(screen.queryByText("演示客户 01")).toBeNull();
    fireEvent.change(screen.getByRole("searchbox", { name: "搜索会员" }), {
      target: { value: "member001" },
    });
    expect(screen.getByText("演示客户 01")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "查看 演示客户 01" }));
    const dialog = screen.getByRole("dialog");
    fireEvent.change(within(dialog).getByLabelText("邮箱"), {
      target: { value: "MEMBER002@example.com" },
    });
    fireEvent.click(
      within(dialog).getByRole("button", { name: "保存预览修改" }),
    );
    expect(within(dialog).getByRole("alert").textContent).toContain(
      "已被其他演示会员使用",
    );
    fireEvent.keyDown(document, { key: "Escape" });
    expect(screen.queryByRole("dialog")).toBeNull();
    expect(screen.getByText("member001@example.com")).toBeTruthy();
  });
  it("preserves preview edits across route remount but resets them with the explicit demo reset", () => {
    const view = admin();
    fireEvent.click(screen.getByRole("button", { name: "查看 演示客户 01" }));
    fireEvent.change(
      within(screen.getByRole("dialog")).getByLabelText("联系人"),
      { target: { value: "调整后的演示客户" } },
    );
    fireEvent.click(screen.getByRole("button", { name: "保存预览修改" }));
    view.rerender(
      <MemoryRouter>
        <MemberProvider>
          <p>其他页面</p>
        </MemberProvider>
      </MemoryRouter>,
    );
    view.rerender(
      <MemoryRouter>
        <MemberProvider>
          <MemberAdmin />
        </MemberProvider>
      </MemoryRouter>,
    );
    expect(screen.getByText("调整后的演示客户")).toBeTruthy();
    fireEvent.click(screen.getByRole("button", { name: "重置演示" }));
    expect(screen.queryByText("调整后的演示客户")).toBeNull();
    expect(screen.getByText("演示客户 01")).toBeTruthy();
  });
});
