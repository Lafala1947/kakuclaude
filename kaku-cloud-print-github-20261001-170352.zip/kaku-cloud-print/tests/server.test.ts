// @vitest-environment node
import { afterEach, describe, expect, it } from "vitest";
import {
  mkdtemp,
  rm,
  readFile,
  mkdir,
  writeFile,
  copyFile,
} from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import type { Server } from "node:http";
import { request as httpRequest } from "node:http";
import { createApiServer, provisionStaff } from "../src/server/server";
import { defaultInput } from "../src/shared/contracts";
import { defaultConfig } from "../src/lib/config";
import { serializePricingCsv } from "../src/lib/csv";

const origin = "http://localhost:5173";
let dir: string, server: Server, base: string;
async function start() {
  server = await createApiServer({
    dataDir: dir,
    seedDir: join(dir, "seed"),
    origin,
  });
  await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
  base = `http://127.0.0.1:${(server.address() as { port: number }).port}/api`;
}
async function stop() {
  if (server?.listening)
    await new Promise<void>((r, j) => server.close((e) => (e ? j(e) : r())));
}
async function setup() {
  dir = await mkdtemp(join(tmpdir(), "kaku-api-"));
  await mkdir(join(dir, "seed"));
  await writeFile(
    join(dir, "seed", "pricing.csv"),
    serializePricingCsv(defaultConfig),
  );
  for (const name of ["products.json", "homepage.json"])
    await copyFile(join(name === 'products.json' ? 'tests/fixtures' : 'public', name), join(dir, "seed", name));
  for (const group of ["sales", "pricing", "pages"] as const)
    await provisionStaff({
      dataDir: dir,
      seedDir: join(dir, "seed"),
      email: `${group}@test.cn`,
      name: group,
      group,
      password: "safe-test-password-123",
    });
  await start();
}
async function request(
  path: string,
  method = "GET",
  body?: unknown,
  cookie = "",
) {
  const response = await fetch(base + path, {
    method,
    headers: {
      Origin: origin,
      "X-Kaku-Request": "1",
      Cookie: cookie,
      ...(body === undefined ? {} : { "Content-Type": "application/json" }),
    },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  return {
    status: response.status,
    body: await response.json(),
    cookie: response.headers.get("set-cookie")?.split(";")[0] ?? "",
  };
}
async function login(group: string) {
  return (
    await request("/auth/login", "POST", {
      email: `${group}@test.cn`,
      password: "safe-test-password-123",
    })
  ).cookie;
}
async function member(email = "member@test.cn") {
  return request("/auth/register", "POST", {
    email,
    password: "safe-member-password",
    name: "会员",
  });
}
async function publish(cookie: string) {
  const config = await request("/config/pricing");
  return request(
    "/config/pricing",
    "PUT",
    {
      revision: config.body.revision,
      data: {
        ...config.body.data,
        published: true,
        markup: 0.3,
        design: { adjust: 100, custom: 200 },
      },
    },
    cookie,
  );
}
const orderBody = (quoteId: string, files: string[] = []) => ({
  quoteId,
  recipient: {
    name: "张三",
    phone: "13800138000",
    region: "广东广州",
    address: "测试路一号",
  },
  contact: "13800138000",
  orderName: "测试订单",
  notes: "",
  files: { print: files, proof: [], certificate: [] },
});
async function order(body: unknown, cookie: string, key = "retry-key") {
  const r = await fetch(base + "/orders", {
    method: "POST",
    headers: {
      Origin: origin,
      "X-Kaku-Request": "1",
      "Content-Type": "application/json",
      Cookie: cookie,
      "Idempotency-Key": key,
    },
    body: JSON.stringify(body),
  });
  return { status: r.status, body: await r.json() };
}
afterEach(async () => {
  await stop();
  if (dir) await rm(dir, { recursive: true, force: true });
});
describe("private HTTP API", () => {
  it("recovers only the signed-in member's pending files after restart and excludes order attachments", async () => {
    await setup();
    const pricing = await login("pricing"),
      sales = await login("sales");
    await publish(pricing);
    const m = await member(),
      other = await member("other@test.cn");
    const upload = async (name: string, cookie: string) => {
      const response = await fetch(base + "/files?kind=print&name=" + name, {
        method: "POST",
        headers: {
          Origin: origin,
          "X-Kaku-Request": "1",
          Cookie: cookie,
          "Content-Type": "application/octet-stream",
        },
        body: "file",
      });
      return response.json();
    };
    const pending = await upload("pending.pdf", m.cookie),
      bound = await upload("bound.pdf", m.cookie),
      privateOther = await upload("other.pdf", other.cookie);
    const q = await request(
      "/quotes",
      "POST",
      { input: defaultInput },
      m.cookie,
    );
    expect(
      (await order(orderBody(q.body.quoteId, [bound.id]), m.cookie)).status,
    ).toBe(201);
    expect((await request("/files", "GET", undefined, sales)).status).toBe(403);
    expect((await request("/files")).status).toBe(401);
    await stop();
    await start();
    const recovered = await request("/files", "GET", undefined, m.cookie);
    expect(recovered.status).toBe(200);
    expect(recovered.body.files).toEqual([
      {
        id: pending.id,
        name: "pending.pdf",
        kind: "print",
        size: 4,
        createdAt: expect.any(String),
      },
    ]);
    expect(
      (await request("/files", "GET", undefined, other.cookie)).body.files.map(
        (f: { id: string }) => f.id,
      ),
    ).toEqual([privateOther.id]);
  });
  it("keeps credentials private, enforces roles, persists sessions and revokes disabled members", async () => {
    await setup();
    const m = await member();
    expect(m.status).toBe(201);
    expect(m.cookie).toContain("kaku_session=");
    expect((await request("/members", "GET", undefined, m.cookie)).status).toBe(
      403,
    );
    const sales = await login("sales"),
      pricing = await login("pricing");
    expect((await request("/members", "GET", undefined, pricing)).status).toBe(
      403,
    );
    await stop();
    await start();
    expect(
      (await request("/session", "GET", undefined, m.cookie)).body.user.email,
    ).toBe("member@test.cn");
    const members = await request("/members", "GET", undefined, sales);
    expect(
      members.body.data.tiers.every(
        (t: { discount: number }) => t.discount === 100,
      ),
    ).toBe(true);
    const entry = members.body.data.members[0];
    expect(
      (
        await request(
          "/members/" + entry.id,
          "PUT",
          {
            revision: members.body.revision,
            member: { ...entry, active: false },
          },
          sales,
        )
      ).status,
    ).toBe(200);
    expect(
      (await request("/session", "GET", undefined, m.cookie)).body.user,
    ).toBeNull();
    expect(
      (
        await request("/auth/login", "POST", {
          email: "member@test.cn",
          password: "safe-member-password",
        })
      ).status,
    ).toBe(401);
    const persisted = await readFile(join(dir, "state.json"), "utf8");
    expect(persisted).not.toContain("safe-member-password");
    expect(persisted).not.toContain(m.cookie.split("=")[1]);
  });
  it("checks CSRF, publication, RBAC and rejects concurrent stale revisions", async () => {
    await setup();
    expect(
      (await request("/quotes", "POST", { input: defaultInput })).status,
    ).toBe(400);
    const pricing = await login("pricing"),
      sales = await login("sales");
    const config = await request("/config/pricing");
    expect(
      (await request("/config/pricing", "PUT", config.body, sales)).status,
    ).toBe(403);
    const csrf = await fetch(base + "/auth/logout", {
      method: "POST",
      headers: {
        Origin: "https://evil.test",
        "X-Kaku-Request": "1",
        Cookie: pricing,
      },
    });
    expect(csrf.status).toBe(403);
    const edits = await Promise.all(
      [1, 2].map(() => request("/config/pricing", "PUT", config.body, pricing)),
    );
    expect(edits.map((x) => x.status).sort()).toEqual([200, 409]);
    expect((await publish(pricing)).status).toBe(200);
    expect(
      (await request("/quotes", "POST", { input: defaultInput })).status,
    ).toBe(200);
  });
  it("calculates member discounts authoritatively, binds quotes to member and config revisions", async () => {
    await setup();
    const pricing = await login("pricing"),
      sales = await login("sales");
    await publish(pricing);
    const m = await member(),
      other = await member("other@test.cn");
    const members = await request("/members", "GET", undefined, sales);
    const tiers = members.body.data.tiers.map(
      (t: { id: string; discount: number }) => ({
        ...t,
        discount: t.id === "standard" ? 80 : 100,
      }),
    );
    expect(
      (
        await request(
          "/member-tiers",
          "PUT",
          { revision: members.body.revision, tiers },
          sales,
        )
      ).status,
    ).toBe(200);
    const q = await request(
      "/quotes",
      "POST",
      { input: { ...defaultInput, design: "adjust" } },
      m.cookie,
    );
    expect(q.status).toBe(200);
    expect(q.body.discount).toBe(0.8);
    expect(q.body.designTotal).toBe(130);
    expect(q.body.total).toBeCloseTo(q.body.productionTotal + 130, 2);
    expect(q.body.total).toBeLessThan(q.body.standardTotal);
    expect((await order(orderBody(q.body.quoteId), other.cookie)).status).toBe(
      409,
    );
    expect((await order(orderBody("forged"), m.cookie)).status).toBe(409);
    await publish(pricing);
    expect((await order(orderBody(q.body.quoteId), m.cookie)).status).toBe(409);
  });
  it("protects private files and creates a persistent idempotent order with authoritative amounts", async () => {
    await setup();
    const pricing = await login("pricing"),
      sales = await login("sales");
    await publish(pricing);
    const m = await member(),
      other = await member("other@test.cn");
    const upload = await fetch(
      base + "/files?kind=print&name=" + encodeURIComponent("设计.pdf"),
      {
        method: "POST",
        headers: {
          Origin: origin,
          "X-Kaku-Request": "1",
          Cookie: m.cookie,
          "Content-Type": "application/octet-stream",
        },
        body: "file-bytes",
      },
    );
    expect(upload.status).toBe(201);
    const file = await upload.json();
    expect(
      (await request("/files/" + file.id, "GET", undefined, other.cookie))
        .status,
    ).toBe(404);
    const download = await fetch(base + "/files/" + file.id, {
      headers: { Cookie: sales },
    });
    expect(await download.text()).toBe("file-bytes");
    expect(download.headers.get("content-disposition")).toContain("attachment");
    const q = await request(
        "/quotes",
        "POST",
        { input: defaultInput },
        m.cookie,
      ),
      oq = await request(
        "/quotes",
        "POST",
        { input: defaultInput },
        other.cookie,
      );
    expect(
      (await order(orderBody(oq.body.quoteId, [file.id]), other.cookie)).status,
    ).toBe(400);
    const body = orderBody(q.body.quoteId, [file.id]);
    const first = await order(body, m.cookie);
    expect(first.status).toBe(201);
    const repeat = await order(body, m.cookie);
    expect(repeat.body.orderId).toBe(first.body.orderId);
    expect((await order({ ...body, notes: "changed" }, m.cookie)).status).toBe(
      409,
    );
    expect(
      (await request("/orders", "GET", undefined, other.cookie)).body.orders,
    ).toEqual([]);
    expect(
      (
        await request(
          "/orders/" + first.body.orderId,
          "PATCH",
          { status: "confirmed" },
          m.cookie,
        )
      ).status,
    ).toBe(403);
    expect(
      (
        await request(
          "/orders/" + first.body.orderId,
          "PATCH",
          { status: "confirmed" },
          sales,
        )
      ).status,
    ).toBe(200);
    await stop();
    await start();
    expect((await order(body, m.cookie)).body.orderId).toBe(first.body.orderId);
    const orders = await request("/orders", "GET", undefined, m.cookie);
    expect(orders.body.orders[0]).toMatchObject({
      status: "confirmed",
      quote: { total: q.body.total },
      files: [{ id: file.id }],
    });
  });
  it("refuses two writers and refuses automatic stale-lock removal after a crashed process", async () => {
    await setup();
    await expect(createApiServer({ dataDir: dir, origin })).rejects.toThrow(
      "数据目录",
    );
    await expect(
      provisionStaff({
        dataDir: dir,
        email: "new@test.cn",
        name: "new",
        group: "sales",
        password: "safe-test-password",
      }),
    ).rejects.toThrow("数据目录");
    await stop();
    await writeFile(join(dir, "server.lock"), "999999999");
    await expect(createApiServer({ dataDir: dir, origin })).rejects.toThrow(
      "server.lock",
    );
  });
  it("limits pending file count, rejects executable and path filenames, and requires login", async () => {
    await setup();
    const m = await member();
    const upload = async (name: string, cookie = m.cookie) =>
      fetch(base + "/files?kind=print&name=" + encodeURIComponent(name), {
        method: "POST",
        headers: {
          Origin: origin,
          "X-Kaku-Request": "1",
          Cookie: cookie,
          "Content-Type": "application/octet-stream",
        },
        body: "x",
      });
    expect((await upload("a.pdf", "")).status).toBe(401);
    expect((await upload("a.exe")).status).toBe(400);
    expect((await upload("../a.pdf")).status).toBe(400);
    for (let i = 0; i < 20; i++)
      expect((await upload(`${i}.pdf`)).status).toBe(201);
    expect((await upload("last.pdf")).status).toBe(400);
  });
  it("enforces pages/products roles and invalidates quotations when their product is unpublished", async () => {
    await setup();
    const pages = await login("pages"),
      sales = await login("sales"),
      pricing = await login("pricing");
    const homepage = await request("/config/homepage"),
      products = await request("/config/products");
    expect(
      (await request("/config/homepage", "PUT", homepage.body, sales)).status,
    ).toBe(403);
    expect(
      (await request("/config/homepage", "PUT", homepage.body, pages)).status,
    ).toBe(200);
    expect(
      (await request("/config/products", "PUT", products.body, sales)).status,
    ).toBe(403);
    await publish(pricing);
    const m = await member();
    const product = products.body.data.products.find(
      (p: { active: boolean; quoteMode: string }) =>
        p.active && p.quoteMode === "paper",
    );
    const q = await request(
      "/quotes",
      "POST",
      { input: defaultInput, productId: product.id },
      m.cookie,
    );
    expect(q.status).toBe(200);
    expect(q.body.product.id).toBe(product.id);
    product.active = false;
    expect(
      (await request("/config/products", "PUT", products.body, pages)).status,
    ).toBe(200);
    expect((await order(orderBody(q.body.quoteId), m.cookie)).status).toBe(409);
    expect(
      (
        await request(
          "/quotes",
          "POST",
          { input: defaultInput, productId: product.id },
          m.cookie,
        )
      ).status,
    ).toBe(400);
  });
  it("allows successful sessions from a shared proxy while throttling repeated password failures by account", async () => {
    await setup();
    for (let i = 0; i < 31; i++)
      expect(
        (
          await request("/auth/login", "POST", {
            email: "sales@test.cn",
            password: "safe-test-password-123",
          })
        ).status,
      ).toBe(200);
    for (let i = 0; i < 10; i++)
      expect(
        (
          await request("/auth/login", "POST", {
            email: "sales@test.cn",
            password: "incorrect-password",
          })
        ).status,
      ).toBe(401);
    expect(
      (
        await request("/auth/login", "POST", {
          email: "sales@test.cn",
          password: "safe-test-password-123",
        })
      ).status,
    ).toBe(429);
    expect(
      (
        await request("/auth/login", "POST", {
          email: "pricing@test.cn",
          password: "safe-test-password-123",
        })
      ).status,
    ).toBe(200);
  }, 20000);
  it("keeps health and session reads responsive while a binary upload is still arriving", async () => {
    await setup();
    const m = await member();
    const pending = httpRequest(base + "/files?kind=print&name=slow.pdf", {
      method: "POST",
      headers: {
        Origin: origin,
        "X-Kaku-Request": "1",
        Cookie: m.cookie,
        "Content-Type": "application/octet-stream",
      },
    });
    pending.on("error", () => {});
    pending.write("first");
    await new Promise((r) => setTimeout(r, 30));
    try {
      const health = await fetch(base + "/health", {
        signal: AbortSignal.timeout(1000),
      });
      expect(health.status).toBe(200);
    } finally {
      pending.destroy();
    }
  });
  it("rejects uploads from stale browser identities before persisting any file", async () => {
    await setup();
    const m = await member();
    const response = await fetch(base + "/files?kind=print&name=identity.pdf", {
      method: "POST",
      headers: {
        Origin: origin,
        "X-Kaku-Request": "1",
        "X-Kaku-User-Id": "different-user",
        Cookie: m.cookie,
        "Content-Type": "application/octet-stream",
      },
      body: "private-file",
    });
    expect(response.status).toBe(401);
    expect(
      JSON.parse(await readFile(join(dir, "state.json"), "utf8")).files,
    ).toEqual([]);
  });
  it("accepts pickup without shipping address or order title, while requiring an artwork file", async () => {
    await setup();
    const pricing = await login("pricing");
    await publish(pricing);
    const m = await member();
    const q = await request(
      "/quotes",
      "POST",
      { input: defaultInput },
      m.cookie,
    );
    expect((await order(orderBody(q.body.quoteId), m.cookie)).status).toBe(400);
    const upload = await fetch(base + "/files?kind=print&name=a.pdf", {
      method: "POST",
      headers: {
        Origin: origin,
        "X-Kaku-Request": "1",
        Cookie: m.cookie,
        "Content-Type": "application/octet-stream",
      },
      body: "x",
    });
    const file = await upload.json(),
      body = orderBody(q.body.quoteId, [file.id]);
    body.orderName = "";
    body.recipient.region = "";
    body.recipient.address = "";
    expect((await order(body, m.cookie)).status).toBe(201);
  });
  it("allows owners to remove pending uploads but preserves files already bound to an order", async () => {
    await setup();
    const pricing = await login("pricing");
    await publish(pricing);
    const m = await member(),
      other = await member("other@test.cn");
    const upload = async () => {
      const r = await fetch(base + "/files?kind=print&name=a.pdf", {
        method: "POST",
        headers: {
          Origin: origin,
          "X-Kaku-Request": "1",
          Cookie: m.cookie,
          "Content-Type": "application/octet-stream",
        },
        body: "x",
      });
      return r.json();
    };
    const pending = await upload();
    expect(
      (await request("/files/" + pending.id, "DELETE", undefined, other.cookie))
        .status,
    ).toBe(404);
    expect(
      (await request("/files/" + pending.id, "DELETE", undefined, m.cookie))
        .status,
    ).toBe(200);
    expect(
      (await request("/files/" + pending.id, "GET", undefined, m.cookie))
        .status,
    ).toBe(404);
    const bound = await upload(),
      q = await request("/quotes", "POST", { input: defaultInput }, m.cookie);
    expect(
      (await order(orderBody(q.body.quoteId, [bound.id]), m.cookie)).status,
    ).toBe(201);
    expect(
      (await request("/files/" + bound.id, "DELETE", undefined, m.cookie))
        .status,
    ).toBe(409);
  });
  it("rejects duplicate tier names, fractional percentage precision and invalid member phones", async () => {
    await setup();
    const sales = await login("sales");
    await member();
    const members = await request("/members", "GET", undefined, sales),
      tiers = members.body.data.tiers;
    const duplicates = tiers.map((t: object) => ({ ...t, name: "重复" }));
    expect(
      (
        await request(
          "/member-tiers",
          "PUT",
          { revision: members.body.revision, tiers: duplicates },
          sales,
        )
      ).status,
    ).toBe(400);
    const precise = structuredClone(tiers);
    precise[0].discount = 99.123;
    expect(
      (
        await request(
          "/member-tiers",
          "PUT",
          { revision: members.body.revision, tiers: precise },
          sales,
        )
      ).status,
    ).toBe(400);
    const entry = members.body.data.members[0];
    expect(
      (
        await request(
          "/members/" + entry.id,
          "PUT",
          {
            revision: members.body.revision,
            member: { ...entry, phone: "bad-phone" },
          },
          sales,
        )
      ).status,
    ).toBe(400);
  });
});
