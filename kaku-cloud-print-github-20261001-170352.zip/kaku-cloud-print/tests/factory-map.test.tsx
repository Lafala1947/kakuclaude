// @vitest-environment jsdom
import { afterEach, expect, it } from 'vitest';
import { cleanup, fireEvent, render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import FactoryMap from '../src/client/factory/FactoryMap';
import { parseFactoryDirectory, type PrintFactory } from '../src/shared/factories';
const factory: PrintFactory = {
  id: 'map-factory', name: '<测试印厂>', kind: 'factory', operator: '测试主体', active: true,
  address: '测试地址', description: '测试资料', regions: [{ province: '广东省', city: '深圳市', district: '*' }],
  materials: ['paper'], crafts: [], equipment: [], location: { latitude: 22.54, longitude: 114.06, crs: 'WGS84' },
};
afterEach(cleanup);
function setup(factories: PrintFactory[]) {
  return render(<MemoryRouter><FactoryMap factories={factories} detailQuery="province=广东省" searched /></MemoryRouter>);
}
it('renders a real interactive map, attribution and a safe, keyboard accessible factory marker', () => {
  setup([factory]);
  expect(screen.getByRole('region', { name: '印厂位置地图' })).toBeTruthy();
  expect(screen.getByRole('link', { name: 'OpenStreetMap' })).toBeTruthy();
  fireEvent.click(screen.getByRole('button', { name: '在地图上查看：<测试印厂>' }));
  expect(screen.getByRole('heading', { name: '<测试印厂>' })).toBeTruthy();
  expect(screen.getByRole('link', { name: '选择此印厂' }).getAttribute('href')).toContain('/factories/map-factory?province=');
});
it('keeps factories without coordinates reachable without inventing a marker', () => {
  setup([{ ...factory, location: undefined }]);
  expect(screen.queryByRole('button', { name: '在地图上查看：<测试印厂>' })).toBeNull();
  expect(screen.getByText('位置待补充')).toBeTruthy();
  expect(screen.getByRole('link', { name: '选择此印厂' })).toBeTruthy();
});
it('offers a retry if external map tiles fail without hiding the factory detail link', () => {
  const view = setup([factory]);
  const tile = view.container.querySelector('img.leaflet-tile');
  expect(tile).toBeTruthy();
  fireEvent.error(tile!);
  expect(screen.getByRole('alert').textContent).toContain('地图底图加载失败');
  expect(screen.getByRole('link', { name: '选择此印厂' })).toBeTruthy();
  fireEvent.click(screen.getByRole('button', { name: '重试地图' }));
  expect(screen.queryByRole('alert')).toBeNull();
});
it('removes stale markers and selections when the filter results change', () => {
  const view = setup([factory]);
  view.rerender(<MemoryRouter><FactoryMap factories={[]} detailQuery="" searched /></MemoryRouter>);
  expect(screen.queryByRole('button', { name: '在地图上查看：<测试印厂>' })).toBeNull();
  expect(screen.queryByRole('link', { name: '选择此印厂' })).toBeNull();
});
it('allows missing coordinates but rejects invalid or incompatible coordinate systems', () => {
  const parse = (location: unknown) => parseFactoryDirectory(JSON.stringify({ version: 1, factories: [{ ...factory, location }] }));
  expect(parse(undefined).factories).toHaveLength(1);
  expect(parse(factory.location).factories[0].location).toEqual(factory.location);
  expect(() => parse({ latitude: 91, longitude: 114, crs: 'WGS84' })).toThrow();
  expect(() => parse({ latitude: 22, longitude: 181, crs: 'WGS84' })).toThrow();
  expect(() => parse({ latitude: '22', longitude: 114, crs: 'WGS84' })).toThrow();
  expect(() => parse({ latitude: 22, longitude: 114, crs: 'GCJ02' })).toThrow();
});
