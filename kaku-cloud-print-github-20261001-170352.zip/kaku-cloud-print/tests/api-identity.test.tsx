// @vitest-environment jsdom
import { afterEach, expect, it, vi } from 'vitest';
import { act, cleanup, render, screen } from '@testing-library/react';
import { MemoryRouter } from 'react-router-dom';
import AdminPortal from '../src/client/admin/AdminPortal';
import { AdminAccessProvider } from '../src/client/admin/AdminAccess';
vi.mock('../src/client/api/client', async (original) => ({ ...await original<object>(), apiEnabled: true }));
afterEach(() => { cleanup(); vi.restoreAllMocks(); });
it('API mode never offers self-selected administrator roles to unauthenticated visitors', () => {
  render(<MemoryRouter><AdminAccessProvider><AdminPortal /></AdminAccessProvider></MemoryRouter>);
  expect(screen.queryByRole('button', {name:'进入价格组'})).toBeNull();
  expect(screen.getByRole('link', {name:'员工登录'})).toBeTruthy();
});
import { fireEvent, waitFor, within } from '@testing-library/react';
import { SessionProvider, useSession } from '../src/client/api/SessionContext';
import AuthPage from '../src/client/members/AuthPage';
import { MemberProvider } from '../src/client/members/MemberContext';
import MemberAdmin from '../src/client/members/MemberAdmin';
const sales = {id:'staff-1',name:'销售员工',email:'sales@example.com',role:'staff',group:'sales'};
const document = {revision:'v1', data:{members:[{id:'member-1',name:'真实客户',email:'customer@example.com',company:'印品公司',phone:'',tierId:'standard',active:true,createdAt:'2026-10-01',notes:''}],tiers:[{id:'standard',name:'普通会员',discount:100}]}};
function response(value: unknown, status = 200) { return Promise.resolve(new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json'}})); }
function Identity() {const session = useSession(); return <><span data-testid="identity">{session.user?.name || '未登录'}</span><button onClick={() => void session.logout().catch(()=>{})}>登出</button></>;}
function app(children: React.ReactNode) {return render(<MemoryRouter><SessionProvider><AdminAccessProvider><MemberProvider>{children}<Identity /></MemberProvider></AdminAccessProvider></SessionProvider></MemoryRouter>);}
it('authenticates only on successful server login and shows rejected credentials', async () => {
  vi.spyOn(globalThis,'fetch').mockImplementation((url) => String(url).endsWith('/session') ? response({user:null}) : response({error:'账号或密码错误'},401));
  app(<AuthPage mode="login" />);
  await waitFor(()=>expect((screen.getByRole('button',{name:'登录'}) as HTMLButtonElement).disabled).toBe(false));
  fireEvent.change(screen.getByLabelText('邮箱'),{target:{value:'x@example.com'}});
  fireEvent.change(screen.getByLabelText('密码',{exact:true}),{target:{value:'Example123'}});
  fireEvent.click(screen.getByRole('button',{name:'登录'}));
  expect(await screen.findByRole('alert')).toHaveProperty('textContent','账号或密码错误');
  expect(screen.getByTestId('identity').textContent).toBe('未登录');
  expect(screen.queryByText(/格式校验通过/)).toBeNull();
});
it('registers through the API and uses the returned member session', async () => {
  vi.spyOn(globalThis,'fetch').mockImplementation((url) => String(url).endsWith('/session') ? response({user:null}) : response({user:{id:'member-1',name:'新客户',email:'new@example.com',role:'member',group:null}}));
  app(<AuthPage mode="register" />);
  await waitFor(()=>expect((screen.getByRole('button',{name:'注册并登录'}) as HTMLButtonElement).disabled).toBe(false));
  for (const [label,value] of [['邮箱','new@example.com'],['联系人','新客户'],['密码','Example12345'],['确认密码','Example12345']]) fireEvent.change(screen.getByLabelText(label,{exact:true}),{target:{value}});
  fireEvent.click(screen.getByRole('button',{name:'注册并登录'}));
  await waitFor(()=>expect(screen.getByTestId('identity').textContent).toBe('新客户'));
  expect(screen.getByRole('link',{name:'我的订单'})).toBeTruthy();
});
it('loads actual members and retains the draft after a version conflict', async () => {
  vi.spyOn(globalThis,'fetch').mockImplementation((url,options) => String(url).endsWith('/session') ? response({user:sales}) : options?.method === 'PUT' ? response({error:'数据已更新，请刷新后重试'},409) : response(document));
  app(<MemberAdmin />);
  expect(await screen.findByText('真实客户')).toBeTruthy();
  expect(screen.queryByText('演示客户 01')).toBeNull();
  fireEvent.click(screen.getByRole('button',{name:'查看 真实客户'}));
  fireEvent.change(within(screen.getByRole('dialog')).getByLabelText('联系人'),{target:{value:'保留的修改'}});
  fireEvent.click(screen.getByRole('button',{name:'保存修改'}));
  await waitFor(()=>expect(within(screen.getByRole('dialog')).getByRole('alert').textContent).toContain('数据已更新'));
  expect((within(screen.getByRole('dialog')).getByLabelText('联系人') as HTMLInputElement).value).toBe('保留的修改');
  fireEvent.click(screen.getByRole('button',{name:'登出'}));
  await waitFor(()=>expect(screen.queryByText('真实客户')).toBeNull());
  expect(screen.queryByRole('dialog')).toBeNull();
});
it('clears member records and refuses preview data when member loading fails', async () => {
  vi.spyOn(globalThis,'fetch').mockImplementation((url) => String(url).endsWith('/session') ? response({user:sales}) : response({error:'会员服务暂不可用'},503));
  app(<MemberAdmin />);
  expect((await screen.findByRole('alert')).textContent).toContain('会员服务暂不可用');
  expect(screen.queryByText('演示客户 01')).toBeNull();
  expect(screen.queryByRole('button',{name:'重置演示'})).toBeNull();
});
import { AdminGuard } from '../src/client/admin/AdminAccess';
it('grants only the server assigned role and revokes access on logout', async () => {
  vi.spyOn(globalThis,'fetch').mockImplementation((url) => String(url).endsWith('/session') ? response({user:sales}) : String(url).endsWith('/auth/logout') ? response({ok:true}) : response(document));
  app(<><AdminPortal /><AdminGuard group="sales"><p>销售专属内容</p></AdminGuard><AdminGuard group="pricing"><p>价格专属内容</p></AdminGuard></>);
  expect(await screen.findByText('销售专属内容')).toBeTruthy();
  expect(screen.queryByText('价格专属内容')).toBeNull();
  expect(screen.queryByRole('button',{name:'进入价格组'})).toBeNull();
  expect(screen.getByRole('link',{name:'管理订单'})).toBeTruthy();
  fireEvent.click(screen.getByRole('button',{name:'登出'}));
  await waitFor(()=>expect(screen.queryByText('销售专属内容')).toBeNull());
  expect(screen.getByTestId('identity').textContent).toBe('未登录');
});
it('shows a session failure without granting access or fetching member records', async () => {
  const fetch = vi.spyOn(globalThis,'fetch').mockImplementation(() => response({error:'会话已失效'},401));
  app(<AdminGuard group="sales"><MemberAdmin /></AdminGuard>);
  expect((await screen.findByRole('alert')).textContent).toContain('会话已失效');
  expect(screen.queryByText('真实客户')).toBeNull();
  expect(fetch.mock.calls.some(([url])=>String(url).endsWith('/members'))).toBe(false);
});
it('saves tiers with the current revision and prevents edits while pending', async () => {
  let finish: ((response: Response) => void) | undefined;
  const requests: Array<{url: string; options?: RequestInit}> = [];
  vi.spyOn(globalThis,'fetch').mockImplementation((url, options) => {
    requests.push({url:String(url),options});
    if (String(url).endsWith('/session')) return response({user:sales});
    if (options?.method === 'PUT') return new Promise(resolve=> {finish = resolve;});
    return response(document);
  });
  app(<MemberAdmin />);
  await screen.findByText('真实客户');
  fireEvent.click(screen.getByRole('tab',{name:'会员等级'}));
  const discount = screen.getByLabelText('普通会员折扣') as HTMLInputElement;
  expect(discount.value).toBe('100');
  fireEvent.change(discount,{target:{value:'95'}});
  fireEvent.click(screen.getByRole('button',{name:'保存等级设置'}));
  expect(discount.matches(':disabled')).toBe(true);
  const put = requests.find(request=>request.options?.method === 'PUT');
  expect(put?.url).toBe('/api/member-tiers');
  expect(JSON.parse(put?.options?.body as string)).toEqual({revision:'v1',tiers:[{id:'standard',name:'普通会员',discount:95}]});
  finish!(new Response(JSON.stringify({...document,revision:'v2',data:{...document.data,tiers:[{id:'standard',name:'普通会员',discount:95}]}})));
  await waitFor(()=>expect(discount.matches(':disabled')).toBe(false));
  expect(screen.getByRole('status').textContent).toContain('已保存到服务器');
});
it.each(['Abcdefgh123','Abcdefghijk', 'a'.repeat(129)+'1'])('rejects out-of-range API registration passwords before sending credentials: %s', async password => {
  const fetch = vi.spyOn(globalThis,'fetch').mockImplementation(()=>response({user:null}));
  app(<AuthPage mode="register" />);
  await waitFor(()=>expect(screen.getByLabelText('邮箱').matches(':disabled')).toBe(false));
  for (const [label,value] of [['邮箱','new@example.com'],['联系人','新客户'],['密码',password],['确认密码',password]]) fireEvent.change(screen.getByLabelText(label,{exact:true}),{target:{value}});
  fireEvent.click(screen.getByRole('button',{name:'注册并登录'}));
  expect(screen.getByRole('alert').textContent).toContain('12');
  expect(fetch.mock.calls.some(([url])=>String(url).endsWith('/auth/register'))).toBe(false);
});
it.each(['Abcdefghijk1', 'a'.repeat(127)+'1'])('accepts boundary API registration password lengths: %s', async password => {
  vi.spyOn(globalThis,'fetch').mockImplementation((url)=>String(url).endsWith('/session') ? response({user:null}) : response({user:{id:'member-1',name:'新客户',email:'new@example.com',role:'member',group:null}}));
  app(<AuthPage mode="register" />);
  await waitFor(()=>expect(screen.getByLabelText('邮箱').matches(':disabled')).toBe(false));
  for (const [label,value] of [['邮箱','new@example.com'],['联系人','新客户'],['密码',password],['确认密码',password]]) fireEvent.change(screen.getByLabelText(label,{exact:true}),{target:{value}});
  fireEvent.click(screen.getByRole('button',{name:'注册并登录'}));
  await waitFor(()=>expect(screen.getByTestId('identity').textContent).toBe('新客户'));
});

function SessionProbe() {const session = useSession(); return <><span data-testid="session-loading">{String(session.loading)}</span>{session.user && <input key={session.user.id} aria-label="私有草稿" defaultValue="" />}</>;}
it('quietly revalidates on focus without dropping an unchanged user draft', async () => {
  let complete: ((response: Response) => void) | undefined;
  let sessions = 0;
  vi.spyOn(globalThis,'fetch').mockImplementation((url) => {
    if (!String(url).endsWith('/session')) return response(document);
    if (++sessions === 1) return response({user:sales});
    return new Promise(resolve => { complete = resolve; });
  });
  app(<SessionProbe />);
  const draft = await screen.findByLabelText('私有草稿');
  fireEvent.change(draft,{target:{value:'未提交地址'}});
  fireEvent(window,new Event('focus'));
  expect(complete).toBeTypeOf('function');
  expect(screen.getByTestId('identity').textContent).toBe('销售员工');
  expect(screen.getByTestId('session-loading').textContent).toBe('false');
  complete!(new Response(JSON.stringify({user:sales})));
  await waitFor(()=>expect((screen.getByLabelText('私有草稿') as HTMLInputElement).value).toBe('未提交地址'));
});
it('invalidates cross-tab private state immediately and ignores an older pending session response', async () => {
  const pending: Array<(response: Response) => void> = [];
  let sessions = 0;
  vi.spyOn(globalThis,'fetch').mockImplementation((url) => {
    if (!String(url).endsWith('/session')) return response(document);
    if (++sessions === 1) return response({user:sales});
    return new Promise(resolve=>pending.push(resolve));
  });
  app(<SessionProbe />);
  await screen.findByLabelText('私有草稿');
  fireEvent(window,new Event('focus'));
  fireEvent(window,new StorageEvent('storage',{key:'kaku-session-invalidation',newValue:JSON.stringify({phase:'start',id:'external-1'})}));
  expect(screen.queryByLabelText('私有草稿')).toBeNull();
  expect(screen.getByTestId('identity').textContent).toBe('未登录');
  fireEvent(window,new StorageEvent('storage',{key:'kaku-session-invalidation',newValue:JSON.stringify({phase:'complete',id:'external-1'})}));
  expect(pending).toHaveLength(2);
  pending[1](new Response(JSON.stringify({user:{...sales,id:'staff-2',name:'其他员工'}})));
  await waitFor(()=>expect(screen.getByTestId('identity').textContent).toBe('其他员工'));
  await act(async () => { pending[0](new Response(JSON.stringify({user:sales}))); });
  await waitFor(()=>expect(screen.getByTestId('identity').textContent).toBe('其他员工'));
});

it('recovers after 35 seconds when another authentication tab closes without completion', async () => {
  let sessions = 0;
  vi.spyOn(globalThis,'fetch').mockImplementation((url) => {
    if (!String(url).endsWith('/session')) return response(document);
    sessions++;
    return response({user:sessions === 1 ? sales : {...sales,id:'staff-2',name:'恢复后的员工'}});
  });
  app(<SessionProbe />);
  await screen.findByLabelText('私有草稿');
  vi.useFakeTimers();
  try {
    fireEvent(window,new StorageEvent('storage',{key:'kaku-session-invalidation',newValue:JSON.stringify({phase:'start',id:'closed-tab'})}));
    await act(async () => { await vi.advanceTimersByTimeAsync(34999); });
    fireEvent(window,new Event('focus'));
    expect(screen.getByTestId('session-loading').textContent).toBe('true');
    expect(screen.queryByLabelText('私有草稿')).toBeNull();
    expect(sessions).toBe(1);
    await act(async () => { await vi.advanceTimersByTimeAsync(1); });
    expect(screen.getByTestId('identity').textContent).toBe('恢复后的员工');
    expect(screen.getByTestId('session-loading').textContent).toBe('false');
    expect(sessions).toBe(2);
  } finally { vi.useRealTimers(); }
});
it('cancels cross-tab recovery timers on completion and provider cleanup', async () => {
  let sessions = 0;
  vi.spyOn(globalThis,'fetch').mockImplementation((url) => {
    if (!String(url).endsWith('/session')) return response(document);
    sessions++;
    return response({user:sales});
  });
  const view = app(<SessionProbe />);
  await screen.findByLabelText('私有草稿');
  vi.useFakeTimers();
  try {
    fireEvent(window,new StorageEvent('storage',{key:'kaku-session-invalidation',newValue:JSON.stringify({phase:'start',id:'tab-1'})}));
    fireEvent(window,new StorageEvent('storage',{key:'kaku-session-invalidation',newValue:JSON.stringify({phase:'complete',id:'tab-1'})}));
    await act(async () => { await vi.advanceTimersByTimeAsync(35000); });
    expect(sessions).toBe(2);
    expect(screen.getByTestId('identity').textContent).toBe('销售员工');
    fireEvent(window,new StorageEvent('storage',{key:'kaku-session-invalidation',newValue:JSON.stringify({phase:'start',id:'tab-2'})}));
    view.unmount();
    await act(async () => { await vi.advanceTimersByTimeAsync(35000); });
    expect(sessions).toBe(2);
  } finally { vi.useRealTimers(); }
});
