// @vitest-environment node
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { build } from "esbuild";
import { execFile, fork } from "node:child_process";
import { createServer as createTcpServer } from "node:net";
import { promisify } from "node:util";
import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join, resolve } from "node:path";
import { createApiServer } from "../src/server/server";

const exec = promisify(execFile);
let directory: string;
beforeAll(async () => {
  directory = await mkdtemp(join(tmpdir(), "kaku-cli-"));
  await build({
    entryPoints: ["src/server/cli.ts", "src/server/entry.ts"],
    outdir: directory,
    outExtension: { ".js": ".mjs" },
    platform: "node",
    target: "node24",
    format: "esm",
    bundle: true,
  });
});
afterAll(async () => {
  if (directory) await rm(directory, { recursive: true, force: true });
});
describe("staff provisioning and production entry", () => {
  it("shuts down over IPC and releases the writer lock before process exit", async () => {
    const listener = createTcpServer();
    await new Promise<void>((r) => listener.listen(0, "127.0.0.1", r));
    const port = (listener.address() as { port: number }).port;
    await new Promise<void>((r) => listener.close(() => r()));
    const dataDir = join(directory, "ipc-data");
    const child = fork(join(directory, "entry.mjs"), [], {
      cwd: directory,
      silent: true,
      execArgv: [],
      env: {
        ...process.env,
        NODE_ENV: "development",
        APP_ORIGIN: "http://127.0.0.1:5173",
        PORT: String(port),
        DATA_DIR: dataDir,
        SEED_DIR: resolve("public"),
      },
    });
    try {
      await new Promise<void>((resolve, reject) => {
        const timeout = setTimeout(
          () => reject(new Error("entry readiness timeout")),
          3000,
        );
        child.stdout!.on("data", (data) => {
          if (String(data).includes("listening")) {
            clearTimeout(timeout);
            resolve();
          }
        });
        child.once("error", reject);
      });
      const exited = new Promise<number | null>((resolve, reject) => {
        const timeout = setTimeout(
          () => reject(new Error("IPC shutdown timeout")),
          2000,
        );
        child.once("exit", (code) => {
          clearTimeout(timeout);
          resolve(code);
        });
      });
      child.send("shutdown");
      expect(await exited).toBe(0);
      await expect(
        readFile(join(dataDir, "server.lock")),
      ).rejects.toMatchObject({ code: "ENOENT" });
    } finally {
      if (child.exitCode === null) child.kill();
    }
  });
  it("refuses public data directories before writing private account state", async () => {
    const dataDir = join(directory, "public", "private-data");
    await expect(
      exec(
        process.execPath,
        [
          join(directory, "cli.mjs"),
          "--email",
          "public@test.cn",
          "--name",
          "员工",
          "--group",
          "sales",
        ],
        {
          cwd: directory,
          env: {
            ...process.env,
            DATA_DIR: dataDir,
            SEED_DIR: resolve("public"),
            KAKU_STAFF_PASSWORD: "test-private-password-123",
          },
        },
      ),
    ).rejects.toMatchObject({ code: 1 });
    await expect(readFile(join(dataDir, "state.json"))).rejects.toMatchObject({
      code: "ENOENT",
    });
  });
  it("creates a loginable employee with a private generated credential file and no secret output", async () => {
    const dataDir = join(directory, "data"),
      credentials = join(directory, "employee.credentials.txt");
    const result = await exec(
      process.execPath,
      [
        join(directory, "cli.mjs"),
        "--email",
        "worker@test.cn",
        "--name",
        "费用",
        "--group",
        "pricing",
        "--credentials-file",
        credentials,
      ],
      {
        cwd: directory,
        env: {
          ...process.env,
          DATA_DIR: dataDir,
          SEED_DIR: resolve("public"),
          KAKU_STAFF_PASSWORD: undefined,
        },
      },
    );
    const credential = JSON.parse(await readFile(credentials, "utf8"));
    expect(credential.password.length).toBeGreaterThanOrEqual(12);
    expect(credential.password).toMatch(/[A-Za-z]/);
    expect(credential.password).toMatch(/[0-9]/);
    expect(result.stdout + result.stderr).not.toContain(credential.password);
    const server = await createApiServer({
      dataDir,
      origin: "http://localhost:5173",
    });
    await new Promise<void>((r) => server.listen(0, "127.0.0.1", r));
    try {
      const port = (server.address() as { port: number }).port;
      const response = await fetch(`http://127.0.0.1:${port}/api/auth/login`, {
        method: "POST",
        headers: {
          Origin: "http://localhost:5173",
          "X-Kaku-Request": "1",
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: credential.email,
          password: credential.password,
        }),
      });
      expect(response.status).toBe(200);
      expect((await response.json()).user).toMatchObject({
        role: "staff",
        group: "pricing",
      });
    } finally {
      await new Promise<void>((r, j) => server.close((e) => (e ? j(e) : r())));
    }
  });
  it("refuses implicit default passwords and refuses credential files in the public web root", async () => {
    await expect(
      exec(
        process.execPath,
        [
          join(directory, "cli.mjs"),
          "--email",
          "no@test.cn",
          "--name",
          "销售",
          "--group",
          "sales",
        ],
        {
          cwd: directory,
          env: { ...process.env, KAKU_STAFF_PASSWORD: undefined },
        },
      ),
    ).rejects.toMatchObject({ code: 1 });
    await expect(
      exec(
        process.execPath,
        [
          join(directory, "cli.mjs"),
          "--email",
          "no@test.cn",
          "--name",
          "销售",
          "--group",
          "sales",
          "--credentials-file",
          "public/leak.json",
        ],
        {
          cwd: directory,
          env: { ...process.env, KAKU_STAFF_PASSWORD: undefined },
        },
      ),
    ).rejects.toMatchObject({ code: 1 });
  });
  it("fails closed when production HTTPS origin or Secure cookies are not explicitly configured", async () => {
    await expect(
      exec(process.execPath, [join(directory, "entry.mjs")], {
        cwd: directory,
        env: {
          ...process.env,
          NODE_ENV: "production",
          APP_ORIGIN: undefined,
          COOKIE_SECURE: undefined,
        },
      }),
    ).rejects.toMatchObject({ code: 1 });
    await expect(
      exec(process.execPath, [join(directory, "entry.mjs")], {
        cwd: directory,
        env: {
          ...process.env,
          NODE_ENV: "production",
          APP_ORIGIN: "http://example.com",
          COOKIE_SECURE: "true",
        },
      }),
    ).rejects.toMatchObject({ code: 1 });
  });
});
