import { resolve } from "node:path";
import { createApiServer } from "./server";

try {
  if (Number(process.versions.node.split(".")[0]) < 24)
    throw new Error("API 需要 Node.js 24 或更高版本");
  const production = process.env.NODE_ENV === "production";
  const origin =
    process.env.APP_ORIGIN ?? (production ? "" : "http://127.0.0.1:5173");
  if (
    !origin ||
    (production &&
      (!origin.startsWith("https://") || process.env.COOKIE_SECURE !== "true"))
  )
    throw new Error("生产环境必须设置 HTTPS APP_ORIGIN 和 COOKIE_SECURE=true");
  const dataDir = resolve(process.env.DATA_DIR ?? "data");
  const port = Number(process.env.PORT ?? 8787);
  if (!Number.isInteger(port) || port < 1 || port > 65535)
    throw new Error("PORT 必须是有效端口");
  const server = await createApiServer({
    dataDir,
    seedDir: process.env.SEED_DIR,
    origin,
    secureCookie: process.env.COOKIE_SECURE === "true",
  });
  let closing = false;
  const shutdown = (exitCode = 0) => {
    if (closing) return;
    closing = true;
    server.close(() => {
      process.exitCode = exitCode;
      if (process.connected) process.disconnect();
    });
  };
  server.on("error", () => {
    console.error("API 无法启动监听，请检查 HOST、PORT 和端口占用");
    shutdown(1);
  });
  server.listen(port, process.env.HOST ?? "127.0.0.1", () =>
    console.log(`Kaku API listening on port ${port}`),
  );
  for (const signal of ["SIGINT", "SIGTERM"] as const)
    process.once(signal, () => shutdown());
  process.on("message", (message) => {
    if (message === "shutdown") shutdown();
  });
} catch (error) {
  console.error(error instanceof Error ? error.message : "API 启动失败");
  process.exitCode = 1;
}
