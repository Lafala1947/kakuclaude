import { mkdir, open, readFile, rename, unlink } from "node:fs/promises";
import { join, resolve, relative, isAbsolute } from "node:path";
import { randomUUID } from "node:crypto";
import { parsePricingCsv, serializePricingCsv } from "../lib/csv";
import { parseProducts, type ProductDocument } from "../shared/products";
import { parseHomepage, type HomepageDocument } from "../shared/homepage";
import type {
  ApiOrder,
  MembersDocument,
  ServerQuote,
  SessionUser,
  Versioned,
} from "../shared/api";
import type { PricingConfig } from "../shared/contracts";

export interface Account extends SessionUser {
  passwordHash: string;
}
export interface StoredQuote {
  quote: ServerQuote;
  userId: string | null;
  pricingRevision: string;
  productsRevision: string;
  memberFingerprint: string;
}
export interface StoredFile {
  id: string;
  ownerId: string;
  kind: "print" | "proof" | "certificate";
  name: string;
  size: number;
  createdAt: string;
}
export interface State {
  schema: 1;
  pricingRevision: string;
  products: Versioned<ProductDocument>;
  homepage: Versioned<HomepageDocument>;
  members: Versioned<MembersDocument>;
  accounts: Account[];
  sessions: Array<{ hash: string; userId: string; expiresAt: number }>;
  quotes: StoredQuote[];
  files: StoredFile[];
  orders: ApiOrder[];
  idempotency: Array<{
    userId: string;
    key: string;
    digest: string;
    orderId: string;
  }>;
}
export interface StoreOptions {
  dataDir: string;
  seedDir?: string;
}
export async function atomicWrite(path: string, data: string) {
  const temp = `${path}.${randomUUID()}.tmp`,
    handle = await open(temp, "wx", 0o600);
  try {
    await handle.writeFile(data, "utf8");
    await handle.sync();
  } finally {
    await handle.close();
  }
  try {
    await rename(temp, path);
  } catch (error) {
    await unlink(temp).catch(() => {});
    throw error;
  }
}
export class Store {
  state!: State;
  pricing!: PricingConfig;
  readonly dir: string;
  private queue: Promise<unknown> = Promise.resolve();
  private lockPath: string;
  private constructor(dir: string) {
    this.dir = resolve(dir);
    this.lockPath = join(this.dir, "server.lock");
  }
  static async open(options: StoreOptions) {
    const store = new Store(options.dataDir);
    for (const publicRoot of ["public", "dist"]) {
      const location = relative(resolve(publicRoot), store.dir);
      if (!location || (!location.startsWith("..") && !isAbsolute(location)))
        throw new Error("DATA_DIR 不得位于公开静态目录内");
    }
    await mkdir(store.dir, { recursive: true, mode: 0o700 });
    await mkdir(join(store.dir, "files"), { recursive: true, mode: 0o700 });
    await mkdir(join(store.dir, "pricing"), { recursive: true, mode: 0o700 });
    let lock;
    try {
      lock = await open(store.lockPath, "wx", 0o600);
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code !== "EEXIST") throw error;
      // Do not auto-remove stale locks: two recovering processes could otherwise
      // unlink each other's replacement lock and both become active writers.
      throw new Error(
        "数据目录已锁定；请停止 API 服务。如进程异常退出，确认没有写入进程后人工删除 server.lock",
      );
    }
    await lock.writeFile(String(process.pid));
    await lock.sync();
    await lock.close();
    try {
      let existing: string | undefined;
      try {
        existing = await readFile(join(store.dir, "state.json"), "utf8");
      } catch (e) {
        if ((e as NodeJS.ErrnoException).code !== "ENOENT") throw e;
      }
      if (existing !== undefined) {
        store.state = JSON.parse(existing);
        if (
          store.state.schema !== 1 ||
          !/^[a-f0-9-]{36}$/.test(store.state.pricingRevision)
        )
          throw new Error("持久化数据版本无效");
        store.pricing = parsePricingCsv(
          await readFile(
            join(store.dir, "pricing", store.state.pricingRevision + ".csv"),
            "utf8",
          ),
        );
        parseProducts(JSON.stringify(store.state.products.data));
        parseHomepage(JSON.stringify(store.state.homepage.data));
      } else {
        const seed = resolve(options.seedDir ?? "public");
        const [pricing, products, homepage] = await Promise.all(
          ["pricing.csv", "products.json", "homepage.json"].map((name) =>
            readFile(join(seed, name), "utf8"),
          ),
        );
        store.pricing = parsePricingCsv(pricing);
        store.state = {
          schema: 1,
          pricingRevision: randomUUID(),
          products: { revision: randomUUID(), data: parseProducts(products) },
          homepage: { revision: randomUUID(), data: parseHomepage(homepage) },
          members: {
            revision: randomUUID(),
            data: {
              members: [],
              tiers: [
                { id: "standard", name: "普通会员", discount: 100 },
                { id: "silver", name: "银卡会员", discount: 100 },
                { id: "gold", name: "金卡会员", discount: 100 },
                { id: "business", name: "企业会员", discount: 100 },
              ],
            },
          },
          accounts: [],
          sessions: [],
          quotes: [],
          files: [],
          orders: [],
          idempotency: [],
        };
        await atomicWrite(
          join(store.dir, "pricing", store.state.pricingRevision + ".csv"),
          serializePricingCsv(store.pricing),
        );
        await atomicWrite(
          join(store.dir, "state.json"),
          JSON.stringify(store.state),
        );
      }
      return store;
    } catch (error) {
      await store.close();
      throw error;
    }
  }
  run<T>(work: () => Promise<T>): Promise<T> {
    const next = this.queue.then(work);
    this.queue = next.catch(() => {});
    return next;
  }
  async save(next: State, pricing?: PricingConfig) {
    // Immutable CSV plus an atomic pointer prevents a half-published configuration.
    if (pricing)
      await atomicWrite(
        join(this.dir, "pricing", next.pricingRevision + ".csv"),
        serializePricingCsv(pricing),
      );
    await atomicWrite(join(this.dir, "state.json"), JSON.stringify(next));
    this.state = next;
    if (pricing) this.pricing = pricing;
  }
  async close() {
    await this.queue;
    await unlink(this.lockPath).catch((error) => {
      if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
    });
  }
}
