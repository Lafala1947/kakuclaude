import {
  createServer,
  type IncomingMessage,
  type ServerResponse,
} from "node:http";
import { createReadStream } from "node:fs";
import { open, rename, unlink } from "node:fs/promises";
import { join, extname } from "node:path";
import {
  randomBytes,
  randomUUID,
  scrypt as scryptCallback,
  timingSafeEqual,
  createHash,
} from "node:crypto";
import { promisify } from "node:util";
import { pipeline } from "node:stream/promises";
import Decimal from "decimal.js";
import { calculateQuote, validateInput } from "../lib/pricing";
import { validateConfig } from "../lib/config";
import { parseProducts } from "../shared/products";
import { parseHomepage } from "../shared/homepage";
import { fileChecks, getFileReview, initialFileReview, orderTransitions, reviewEditable } from "../shared/file-review";
import type {
  ApiMember,
  ApiOrder,
  ApiTier,
  ServerQuote,
  SessionUser,
  StaffGroup,
  FileCheckId,
} from "../shared/api";
import {
  Store,
  type Account,
  type State,
  type StoreOptions,
  type StoredFile,
} from "./store";

const scrypt = promisify(scryptCallback);
const groups: StaffGroup[] = ["pricing", "sales", "pages"];
const maxFileBytes = 100 * 1024 * 1024;
const extensions = new Set([
  ".pdf",
  ".ai",
  ".cdr",
  ".eps",
  ".psd",
  ".png",
  ".jpg",
  ".jpeg",
  ".tif",
  ".tiff",
  ".zip",
]);
const hash = (value: string) =>
  createHash("sha256").update(value).digest("hex");
class ApiError extends Error {
  constructor(
    readonly status: number,
    message: string,
  ) {
    super(message);
  }
}
function fail(status: number, message: string): never {
  throw new ApiError(status, message);
}
function record(value: unknown): Record<string, unknown> {
  if (!value || typeof value !== "object" || Array.isArray(value))
    fail(400, "请求格式无效");
  return value as Record<string, unknown>;
}
function text(
  value: unknown,
  label: string,
  max = 200,
  required = true,
): string {
  if (
    typeof value !== "string" ||
    value.length > max ||
    /[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value) ||
    (required && !value.trim())
  )
    fail(400, `${label}无效或过长`);
  return value.trim();
}
function email(value: unknown) {
  const v = text(value, "邮箱", 254).toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v)) fail(400, "邮箱格式无效");
  return v;
}
function phone(value: unknown) {
  const v = text(value, "联系电话", 20, false);
  if (v && !/^\+?[\d\s()-]{6,20}$/.test(v)) fail(400, "请填写有效联系电话");
  return v;
}
function password(value: unknown) {
  if (typeof value !== "string" || value.length < 12 || value.length > 128)
    fail(400, "密码需要 12–128 个字符");
  return value;
}
async function passwordHash(value: string) {
  const salt = randomBytes(16).toString("hex");
  const key = (await scrypt(value, salt, 64)) as Buffer;
  return `${salt}:${key.toString("hex")}`;
}
async function passwordMatches(value: string, stored: string) {
  const [salt, key] = stored.split(":");
  const actual = (await scrypt(value, salt, 64)) as Buffer;
  const expected = Buffer.from(key, "hex");
  return expected.length === actual.length && timingSafeEqual(actual, expected);
}
function sessionUser(account: Account, state: State): SessionUser {
  const member = state.members.data.members.find((m) => m.id === account.id);
  return {
    id: account.id,
    email: member?.email ?? account.email,
    name: member?.name ?? account.name,
    role: account.role,
    group: account.group,
  };
}
function currentUser(req: IncomingMessage, state: State): Account | null {
  const token = (req.headers.cookie ?? "")
    .split(";")
    .map((v) => v.trim())
    .find((v) => v.startsWith("kaku_session="))
    ?.slice(13);
  if (!token) return null;
  const session = state.sessions.find(
    (s) => s.hash === hash(token) && s.expiresAt > Date.now(),
  );
  const account =
    session && state.accounts.find((a) => a.id === session.userId);
  if (
    !account ||
    (account.role === "member" &&
      !state.members.data.members.find((m) => m.id === account.id)?.active)
  )
    return null;
  return account;
}
function requireUser(user: Account | null): Account {
  if (!user) fail(401, "请登录后继续");
  return user;
}
function requireMember(user: Account | null): Account {
  const u = requireUser(user);
  if (u.role !== "member") fail(403, "此操作仅限会员");
  return u;
}
function requireGroup(user: Account | null, group: StaffGroup) {
  const u = requireUser(user);
  if (u.role !== "staff" || u.group !== group) fail(403, "没有此操作权限");
}
function checkExpectedUser(
  req: IncomingMessage,
  user: Account | null,
  path: string,
) {
  if (
    path === "/api/session" ||
    path === "/api/health" ||
    path === "/api/auth/login" ||
    path === "/api/auth/register" ||
    (req.method === "GET" && path.startsWith("/api/config/"))
  )
    return;
  const expected = req.headers["x-kaku-user-id"];
  if (expected !== undefined && expected !== (user?.id ?? "anonymous"))
    fail(401, "登录身份已改变，请重新登录");
}
function checkRevision(actual: string, expected: unknown) {
  if (actual !== expected) fail(409, "数据已被更新，请刷新后重试");
}
function referencedFileIds(state: State) {
  return new Set(state.orders.flatMap(order => [
    ...order.files.map(file => file.id),
    ...getFileReview(order).history.flatMap(event => event.files.map(file => file.id)),
  ]));
}
function selectedOrderFiles(state: State, memberId: string, value: unknown): ApiOrder['files'] {
  const files = record(value), selected: ApiOrder['files'] = [], seen = new Set<string>();
  for (const kind of ['print', 'proof', 'certificate'] as const) {
    const ids = files[kind];
    if (!Array.isArray(ids) || ids.length > 20) fail(400, '订单文件列表无效');
    for (const id of ids) {
      if (typeof id !== 'string' || seen.has(id)) fail(400, '文件重复或无效');
      seen.add(id);
      const file = state.files.find(f => f.id === id && f.ownerId === memberId && f.kind === kind);
      if (!file) fail(400, '文件不存在、分类错误或不属于当前会员');
      selected.push({id: file.id, name: file.name, kind: file.kind, size: file.size});
    }
  }
  if (selected.length > 20 || selected.reduce((sum, f) => sum + f.size, 0) > maxFileBytes)
    fail(400, '订单最多 20 个文件且总计不超过 100 MB');
  if (!selected.some(f => f.kind === 'print')) fail(400, '请先上传印品文件');
  return selected;
}
function checkFileReviewRevision(order: ApiOrder, expected: unknown) {
  if (getFileReview(order).revision !== expected) fail(409, '文件审核已更新，请刷新后重试');
}
function memberFingerprint(state: State, user: Account | null) {
  if (!user || user.role !== "member") return "";
  const member = state.members.data.members.find((m) => m.id === user.id);
  const tier = state.members.data.tiers.find((t) => t.id === member?.tierId);
  return hash(JSON.stringify({ active: member?.active, tier }));
}
function applyQuote(
  state: State,
  user: Account | null,
  quote: ServerQuote,
): ServerQuote {
  if (user?.role !== "member") return quote;
  const member = state.members.data.members.find((m) => m.id === user.id)!;
  const tier = state.members.data.tiers.find((t) => t.id === member.tierId)!;
  const productionTotal = new Decimal(quote.productionTotal)
    .times(tier.discount)
    .div(100)
    .toDecimalPlaces(2, Decimal.ROUND_HALF_UP);
  const total = productionTotal
    .plus(quote.designTotal)
    .plus(quote.shippingTotal);
  return {
    ...quote,
    productionTotal: productionTotal.toNumber(),
    total: total.toNumber(),
    unitPrice: total.div(quote.totalQuantity).toNumber(),
    discount: tier.discount / 100,
    tier: tier.name,
  };
}
async function json(req: IncomingMessage) {
  if (!req.headers["content-type"]?.startsWith("application/json"))
    fail(415, "请使用 application/json");
  const chunks: Buffer[] = [];
  let size = 0;
  for await (const part of req) {
    size += part.length;
    if (size > 1_100_000) fail(413, "请求内容过大");
    chunks.push(part);
  }
  try {
    return record(JSON.parse(Buffer.concat(chunks).toString("utf8")));
  } catch (error) {
    if (error instanceof ApiError) throw error;
    fail(400, "JSON 格式无效");
  }
}
function send(res: ServerResponse, status: number, body: unknown) {
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
    "X-Content-Type-Options": "nosniff",
  });
  res.end(JSON.stringify(body));
}
function sessionCookie(token: string, secure: boolean, maxAge = 7 * 86400) {
  return `kaku_session=${token}; Path=/api; HttpOnly; SameSite=Lax; Max-Age=${maxAge}${secure ? "; Secure" : ""}`;
}
function addSession(state: State, userId: string) {
  const token = randomBytes(32).toString("base64url");
  state.sessions = state.sessions.filter((s) => s.expiresAt > Date.now());
  state.sessions.push({
    hash: hash(token),
    userId,
    expiresAt: Date.now() + 7 * 86400_000,
  });
  return token;
}
function validateTiers(value: unknown, state: State): ApiTier[] {
  if (!Array.isArray(value) || value.length < 1 || value.length > 20)
    fail(400, "会员等级数量无效");
  const ids = new Set<string>(),
    names = new Set<string>();
  const tiers = value.map((raw) => {
    const t = record(raw),
      id = text(t.id, "等级 ID", 50),
      name = text(t.name, "等级名称", 60);
    if (!/^[a-zA-Z0-9_-]+$/.test(id) || ids.has(id))
      fail(400, "等级 ID 无效或重复");
    ids.add(id);
    if (names.has(name.toLowerCase())) fail(400, "等级名称不能重复");
    names.add(name.toLowerCase());
    if (
      typeof t.discount !== "number" ||
      !Number.isFinite(t.discount) ||
      t.discount <= 0 ||
      t.discount > 100 ||
      new Decimal(t.discount).decimalPlaces() > 2
    )
      fail(400, "会员折扣必须大于 0、不超过 100，最多两位小数");
    return { id, name, discount: t.discount };
  });
  if (
    !ids.has("standard") ||
    state.members.data.members.some((m) => !ids.has(m.tierId))
  )
    fail(400, "不能删除普通等级或会员正在使用的等级");
  return tiers;
}
function validateMember(
  raw: unknown,
  existing: ApiMember,
  state: State,
): ApiMember {
  const m = record(raw);
  if (
    m.id !== existing.id ||
    m.createdAt !== existing.createdAt ||
    typeof m.active !== "boolean"
  )
    fail(400, "会员字段无效");
  const tierId = text(m.tierId, "会员等级", 50);
  if (!state.members.data.tiers.some((t) => t.id === tierId))
    fail(400, "会员等级不存在");
  const mail = email(m.email);
  if (state.accounts.some((a) => a.email === mail && a.id !== existing.id))
    fail(409, "邮箱已被使用");
  return {
    id: existing.id,
    createdAt: existing.createdAt,
    name: text(m.name, "姓名", 100),
    email: mail,
    company: text(m.company, "公司", 200, false),
    phone: phone(m.phone),
    notes: text(m.notes, "备注", 3000, false),
    tierId,
    active: m.active,
  };
}
export interface ApiServerOptions extends StoreOptions {
  origin: string;
  secureCookie?: boolean;
}
export async function createApiServer(options: ApiServerOptions) {
  const allowedOrigin = new URL(options.origin).origin;
  if (allowedOrigin !== options.origin)
    throw new Error("APP_ORIGIN 必须是协议、主机和端口，不含路径");
  const store = await Store.open(options);
  const attempts = new Map<string, { count: number; until: number }>();
  const server = createServer((req, res) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("Cache-Control", "no-store");
    let parsedBody: Record<string, unknown> | undefined;
    let upload: { id: string; temp: string; size: number } | undefined;
    const work = async () => {
      const url = new URL(req.url ?? "/", allowedOrigin),
        path = url.pathname,
        method = req.method ?? "GET";
      if (
        method !== "GET" &&
        method !== "HEAD" &&
        (req.headers["x-kaku-request"] !== "1" ||
          req.headers.origin !== allowedOrigin)
      )
        fail(403, "请求来源校验失败，请从本站操作");
      const state = store.state,
        user = currentUser(req, state);
      checkExpectedUser(req, user, path);
      if (path === "/api/health" && method === "GET")
        return send(res, 200, { ok: true });
      if (path === "/api/session" && method === "GET")
        return send(res, 200, { user: user ? sessionUser(user, state) : null });
      if (
        ["/api/auth/register", "/api/auth/login"].includes(path) &&
        method === "POST"
      ) {
        const body = parsedBody!,
          mail = email(body.email),
          pass = password(body.password);
        let account: Account;
        // Account-based failures avoid putting all clients behind a reverse proxy
        // in one quota. Forwarded headers are intentionally not trusted.
        const key = mail;
        const now = Date.now();
        for (const [k, v] of attempts) if (v.until <= now) attempts.delete(k);
        const attempt = attempts.get(key) ?? {
          count: 0,
          until: now + 15 * 60_000,
        };
        if (attempt.count >= 10) fail(429, "尝试次数过多，请稍后重试");
        attempt.count++;
        attempts.set(key, attempt);
        const next = structuredClone(state);
        if (path.endsWith("/register")) {
          if (next.accounts.some((a) => a.email === mail))
            fail(409, "邮箱已注册");
          const id = randomUUID(),
            name = text(body.name, "姓名", 100);
          const member: ApiMember = {
            id,
            name,
            email: mail,
            company: text(body.company ?? "", "公司", 200, false),
            phone: phone(body.phone ?? ""),
            tierId: "standard",
            active: true,
            createdAt: new Date().toISOString(),
            notes: "",
          };
          account = {
            id,
            name,
            email: mail,
            role: "member",
            group: null,
            passwordHash: await passwordHash(pass),
          };
          next.accounts.push(account);
          next.members.data.members.push(member);
          next.members.revision = randomUUID();
        } else {
          const found = next.accounts.find((a) => a.email === mail);
          const valid = await passwordMatches(
            pass,
            found?.passwordHash ?? `${"0".repeat(32)}:${"0".repeat(128)}`,
          );
          if (
            !found ||
            !valid ||
            (found.role === "member" &&
              !next.members.data.members.find((m) => m.id === found.id)?.active)
          )
            fail(401, "邮箱或密码错误，或账户已停用");
          account = found;
        }
        const token = addSession(next, account.id);
        await store.save(next);
        attempts.delete(key);
        res.setHeader(
          "Set-Cookie",
          sessionCookie(token, !!options.secureCookie),
        );
        return send(res, path.endsWith("/register") ? 201 : 200, {
          user: sessionUser(account, next),
        });
      }
      if (path === "/api/auth/logout" && method === "POST") {
        const next = structuredClone(state);
        const token = (req.headers.cookie ?? "")
          .split(";")
          .map((v) => v.trim())
          .find((v) => v.startsWith("kaku_session="))
          ?.slice(13);
        if (token) {
          next.sessions = next.sessions.filter((s) => s.hash !== hash(token));
          await store.save(next);
        }
        res.setHeader(
          "Set-Cookie",
          sessionCookie("", !!options.secureCookie, 0),
        );
        return send(res, 200, { ok: true });
      }
      const configMatch = /^\/api\/config\/(pricing|products|homepage)$/.exec(
        path,
      );
      if (configMatch) {
        const kind = configMatch[1] as "pricing" | "products" | "homepage";
        if (method === "GET")
          return send(
            res,
            200,
            kind === "pricing"
              ? { revision: state.pricingRevision, data: store.pricing }
              : state[kind],
          );
        if (method === "PUT") {
          requireGroup(user, kind === "pricing" ? "pricing" : "pages");
          const body = parsedBody!;
          checkRevision(
            kind === "pricing" ? state.pricingRevision : state[kind].revision,
            body.revision,
          );
          const next = structuredClone(state),
            revision = randomUUID();
          if (kind === "pricing") {
            const pricing = validateConfig(body.data);
            pricing.version = store.pricing.version + 1;
            next.pricingRevision = revision;
            await store.save(next, pricing);
            return send(res, 200, { revision, data: pricing });
          }
          if (kind === "products")
            next.products = {
              revision,
              data: parseProducts(JSON.stringify(body.data)),
            };
          else
            next.homepage = {
              revision,
              data: parseHomepage(JSON.stringify(body.data)),
            };
          await store.save(next);
          return send(res, 200, next[kind]);
        }
      }
      if (path === "/api/members" && method === "GET") {
        requireGroup(user, "sales");
        return send(res, 200, state.members);
      }
      if (
        (/^\/api\/members\/[^/]+$/.test(path) ||
          path === "/api/member-tiers") &&
        method === "PUT"
      ) {
        requireGroup(user, "sales");
        const body = parsedBody!;
        checkRevision(state.members.revision, body.revision);
        const next = structuredClone(state);
        if (path === "/api/member-tiers")
          next.members.data.tiers = validateTiers(body.tiers, state);
        else {
          const id = path.split("/").pop()!,
            index = next.members.data.members.findIndex((m) => m.id === id);
          if (index < 0) fail(404, "会员不存在");
          const member = validateMember(
            body.member,
            next.members.data.members[index],
            state,
          );
          next.members.data.members[index] = member;
          const account = next.accounts.find((a) => a.id === id)!;
          account.email = member.email;
          account.name = member.name;
          if (!member.active)
            next.sessions = next.sessions.filter((s) => s.userId !== id);
        }
        next.members.revision = randomUUID();
        await store.save(next);
        return send(res, 200, next.members);
      }
      if (path === "/api/quotes" && method === "POST") {
        const body = parsedBody!,
          input = validateInput(body.input);
        const quoteId = randomUUID(),
          expiresAt = new Date(Date.now() + 30 * 60_000).toISOString();
        let quote: ServerQuote = applyQuote(state, user, {
          ...calculateQuote(input, store.pricing),
          quoteId,
          expiresAt,
        });
        if (body.productId !== undefined) {
          const id = text(body.productId, "产品 ID", 100),
            product = state.products.data.products.find((p) => p.id === id);
          if (!product?.active || product.quoteMode !== "paper")
            fail(400, "产品已下架或需要人工报价");
          const category = state.products.data.categories.find(
            (c) => c.id === product.categoryId,
          )!;
          quote = {
            ...quote,
            product: {
              id: product.id,
              code: product.code,
              name: product.name,
              categoryId: category.id,
              categoryName: category.name,
            },
          };
        }
        const next = structuredClone(state);
        next.quotes = next.quotes.filter(
          (q) => Date.parse(q.quote.expiresAt) > Date.now(),
        );
        if (next.quotes.length >= 10000)
          fail(429, "当前报价请求过多，请稍后重试");
        next.quotes.push({
          quote,
          userId: user?.id ?? null,
          pricingRevision: state.pricingRevision,
          productsRevision: state.products.revision,
          memberFingerprint: memberFingerprint(state, user),
        });
        await store.save(next);
        return send(res, 200, quote);
      }
      if (path === "/api/files" && method === "GET") {
        const owner = requireMember(user);
        const attached = referencedFileIds(state);
        const files = state.files
          .filter((file) => file.ownerId === owner.id && !attached.has(file.id))
          .map(({ id, name, kind, size, createdAt }) => ({
            id,
            name,
            kind,
            size,
            createdAt,
          }));
        return send(res, 200, { files });
      }
      if (path === "/api/files" && method === "POST") {
        const owner = requireMember(user),
          kind = url.searchParams.get("kind"),
          name = text(url.searchParams.get("name"), "文件名", 200);
        if (
          !["print", "proof", "certificate"].includes(kind ?? "") ||
          /[\/\\\r\n]/.test(name) ||
          !extensions.has(extname(name).toLowerCase())
        )
          fail(400, "文件类型或名称不支持");
        if (req.headers["content-type"] !== "application/octet-stream")
          fail(415, "请上传原始文件内容");
        const assigned = referencedFileIds(state);
        const pending = state.files.filter(
          (f) => f.ownerId === owner.id && !assigned.has(f.id),
        );
        if (pending.length >= 20) fail(400, "待提交文件最多 20 个");
        const remaining =
          maxFileBytes - pending.reduce((sum, f) => sum + f.size, 0);
        const { id, temp, size } = upload!;
        if (size > remaining) fail(413, "文件总大小不能超过 100 MB");
        const target = join(store.dir, "files", id);
        await rename(temp, target);
        const next = structuredClone(state);
        next.files.push({
          id,
          ownerId: owner.id,
          kind: kind as StoredFile["kind"],
          name,
          size,
          createdAt: new Date().toISOString(),
        });
        try {
          await store.save(next);
        } catch (error) {
          await unlink(target).catch(() => {});
          throw error;
        }
        return send(res, 201, { id, name });
      }
      if (/^\/api\/files\/[^/]+$/.test(path) && method === "GET") {
        const requester = requireUser(user),
          id = path.split("/").pop()!,
          file = state.files.find((f) => f.id === id);
        if (
          !file ||
          (file.ownerId !== requester.id &&
            !(requester.role === "staff" && requester.group === "sales"))
        )
          fail(404, "文件不存在");
        res.writeHead(200, {
          "Content-Type": "application/octet-stream",
          "Content-Length": file.size,
          "Content-Disposition": `attachment; filename="download${extname(file.name)}"; filename*=UTF-8''${encodeURIComponent(file.name).replace(/['()*]/g, (c) => "%" + c.charCodeAt(0).toString(16))}`,
        });
        await pipeline(
          createReadStream(join(store.dir, "files", file.id)),
          res,
        );
        return;
      }
      if (/^\/api\/files\/[^/]+$/.test(path) && method === "DELETE") {
        const owner = requireMember(user),
          id = path.split("/").pop()!,
          file = state.files.find((f) => f.id === id && f.ownerId === owner.id);
        if (!file) fail(404, "文件不存在");
        if (referencedFileIds(state).has(id))
          fail(409, "订单已引用此文件，不能删除");
        const next = structuredClone(state);
        next.files = next.files.filter((f) => f.id !== id);
        await store.save(next);
        await unlink(join(store.dir, "files", id)).catch((error) => {
          if ((error as NodeJS.ErrnoException).code !== "ENOENT") throw error;
        });
        return send(res, 200, { ok: true });
      }
      if (path === "/api/orders" && method === "GET") {
        const requester = requireUser(user);
        if (requester.role === "staff") requireGroup(requester, "sales");
        return send(res, 200, {
          orders: state.orders
            .filter(
              (o) => requester.role === "staff" || o.memberId === requester.id,
            )
            .map(order => ({...order, fileReview: getFileReview(order)}))
            .reverse(),
        });
      }
      if (path === "/api/orders" && method === "POST") {
        const member = requireMember(user),
          body = parsedBody!,
          key = text(req.headers["idempotency-key"], "重试凭据", 128);
        const quoteId = text(body.quoteId, "报价凭据", 100),
          recipient = record(body.recipient),
          files = record(body.files);
        const submitted = {
          quoteId,
          recipient: {
            name: text(recipient.name, "收件人", 100),
            phone: text(recipient.phone, "收件电话", 50),
            region: text(recipient.region ?? "", "收件地区", 200, false),
            address: text(recipient.address ?? "", "收件地址", 500, false),
            company: text(recipient.company ?? "", "公司", 200, false),
          },
          contact: text(body.contact, "联系信息", 200),
          orderName: text(body.orderName ?? "", "订单名称", 200, false),
          notes: text(body.notes ?? "", "备注", 3000, false),
          files: {
            print: files.print,
            proof: files.proof,
            certificate: files.certificate,
          },
        };
        const digest = hash(JSON.stringify(submitted));
        const previous = state.idempotency.find(
          (i) => i.userId === member.id && i.key === key,
        );
        if (previous) {
          if (previous.digest !== digest)
            fail(409, "相同重试凭据不能提交不同订单");
          return send(res, 200, { orderId: previous.orderId });
        }
        const saved = state.quotes.find((q) => q.quote.quoteId === quoteId);
        if (
          !saved ||
          saved.userId !== member.id ||
          Date.parse(saved.quote.expiresAt) <= Date.now() ||
          saved.pricingRevision !== state.pricingRevision ||
          saved.productsRevision !== state.products.revision ||
          saved.memberFingerprint !== memberFingerprint(state, member)
        )
          fail(409, "报价已过期或身份、配置已改变，请重新算价");
        if (!store.pricing.published) fail(409, "报价尚未发布，请重新算价");
        if (!/^\+?[\d\s()-]{6,20}$/.test(submitted.recipient.phone))
          fail(400, "请填写有效联系电话");
        if (
          saved.quote.input.shipping === "express" &&
          (!submitted.recipient.region || !submitted.recipient.address)
        )
          fail(400, "请填写完整收件地区和地址");
        const selected = selectedOrderFiles(state, member.id, files);
        const order: ApiOrder = {
          id: randomUUID(),
          memberId: member.id,
          createdAt: new Date().toISOString(),
          status: "submitted",
          quote: saved.quote,
          recipient: submitted.recipient,
          contact: submitted.contact,
          orderName: submitted.orderName,
          notes: submitted.notes,
          files: selected,
          fileReview: initialFileReview(),
        };
        const next = structuredClone(state);
        next.orders.push(order);
        next.idempotency.push({
          userId: member.id,
          key,
          digest,
          orderId: order.id,
        });
        await store.save(next);
        return send(res, 201, { orderId: order.id });
      }
      const reviewMatch = /^\/api\/orders\/([^/]+)\/file-review$/.exec(path);
      if (reviewMatch && method === 'POST') {
        requireGroup(user, 'sales');
        const body = parsedBody!, next = structuredClone(state),
          order = next.orders.find(o => o.id === reviewMatch[1]);
        if (!order) fail(404, '订单不存在');
        checkFileReviewRevision(order, body.revision);
        if (!reviewEditable(order)) fail(409, '当前订单状态不允许文件审核');
        if (body.decision !== 'approved' && body.decision !== 'rejected') fail(400, '审核结论无效');
        if (!Array.isArray(body.checks) || body.checks.some(id => !fileChecks.some(check => check.id === id)) || new Set(body.checks).size !== body.checks.length)
          fail(400, '审核检查项无效或重复');
        const checks = body.checks as FileCheckId[],
          comment = text(body.comment ?? '', '审核说明', 3000, body.decision === 'rejected');
        if (body.decision === 'approved' && checks.length !== fileChecks.length) fail(400, '通过前请完成全部人工检查项');
        const current = getFileReview(order), actor = {id: user!.id, name: user!.name},
          createdAt = new Date().toISOString();
        order.fileReview = {
          ...current, revision: current.revision + 1, status: body.decision, checks: [...checks], comment,
          reviewer: actor, reviewedAt: createdAt,
          history: [...current.history, {id: randomUUID(), action: body.decision, fileVersion: current.fileVersion, actor, createdAt, comment, checks: [...checks], files: structuredClone(order.files)}],
        };
        await store.save(next);
        return send(res, 200, {order});
      }
      const orderFilesMatch = /^\/api\/orders\/([^/]+)\/files$/.exec(path);
      if (orderFilesMatch && method === 'PUT') {
        const member = requireMember(user), body = parsedBody!, next = structuredClone(state),
          order = next.orders.find(o => o.id === orderFilesMatch[1] && o.memberId === member.id);
        if (!order) fail(404, '订单不存在');
        checkFileReviewRevision(order, body.revision);
        const current = getFileReview(order);
        if (!reviewEditable(order) || current.status !== 'rejected') fail(409, '仅退回且尚未生产的订单可以补交文件');
        const selected = selectedOrderFiles(state, member.id, body.files),
          previousIds = new Set(order.files.map(f => f.id));
        if (selected.length === previousIds.size && selected.every(f => previousIds.has(f.id))) fail(400, '请更换或增减至少一个文件');
        const comment = text(body.comment ?? '', '补稿说明', 3000, false),
          actor = {id: member.id, name: sessionUser(member, state).name}, createdAt = new Date().toISOString();
        order.files = selected;
        order.fileReview = {
          ...initialFileReview(), revision: current.revision + 1, fileVersion: current.fileVersion + 1,
          history: [...current.history, {id: randomUUID(), action: 'resubmitted', fileVersion: current.fileVersion + 1, actor, createdAt, comment, checks: [], files: structuredClone(selected)}],
        };
        await store.save(next);
        return send(res, 200, {order});
      }
      if (/^\/api\/orders\/[^/]+$/.test(path) && method === "PATCH") {
        requireGroup(user, "sales");
        const body = parsedBody!;
        if (
          ![
            "submitted",
            "confirmed",
            "producing",
            "shipped",
            "cancelled",
          ].includes(String(body.status))
        )
          fail(400, "订单状态无效");
        const next = structuredClone(state),
          order = next.orders.find((o) => o.id === path.split("/").pop());
        if (!order) fail(404, "订单不存在");
        const requested = body.status as ApiOrder['status'];
        if (requested === order.status) return send(res, 200, {order: {...order, fileReview: getFileReview(order)}});
        if (!orderTransitions[order.status].includes(requested)) fail(409, '不允许此订单状态流转');
        if (requested === 'producing' && getFileReview(order).status !== 'approved') fail(409, '当前文件版本审核通过后才能开始生产');
        order.status = requested;
        await store.save(next);
        return send(res, 200, { order: {...order, fileReview: getFileReview(order)} });
      }
      fail(404, "接口不存在");
    };
    const prepare = async () => {
      const path = new URL(req.url ?? "/", allowedOrigin).pathname,
        method = req.method ?? "GET";
      const user = currentUser(req, store.state);
      checkExpectedUser(req, user, path);
      if (method === "GET" || method === "HEAD") return work();
      if (
        req.headers["x-kaku-request"] !== "1" ||
        req.headers.origin !== allowedOrigin
      )
        fail(403, "请求来源校验失败，请从本站操作");
      if (path === "/api/files" && method === "POST") {
        requireMember(user);
        const url = new URL(req.url!, allowedOrigin),
          name = text(url.searchParams.get("name"), "文件名", 200);
        if (
          !["print", "proof", "certificate"].includes(
            url.searchParams.get("kind") ?? "",
          ) ||
          /[\/\\\r\n]/.test(name) ||
          !extensions.has(extname(name).toLowerCase())
        )
          fail(400, "文件类型或名称不支持");
        if (req.headers["content-type"] !== "application/octet-stream")
          fail(415, "请上传原始文件内容");
        if (Number(req.headers["content-length"]) > maxFileBytes)
          fail(413, "文件总大小不能超过 100 MB");
        const id = randomUUID(),
          temp = join(store.dir, "files", id + ".tmp");
        upload = { id, temp, size: 0 };
        const handle = await open(temp, "wx", 0o600);
        try {
          for await (const chunk of req.iterator({ destroyOnReturn: false })) {
            upload.size += chunk.length;
            if (upload.size > maxFileBytes) {
              req.resume();
              fail(413, "文件总大小不能超过 100 MB");
            }
            await handle.writeFile(chunk);
          }
          await handle.sync();
        } finally {
          await handle.close();
        }
      } else if (path !== "/api/auth/logout" && method !== "DELETE")
        parsedBody = await json(req);
      return store.run(work);
    };
    prepare()
      .catch((error) => {
        if (res.headersSent) {
          res.destroy();
          return;
        }
        const status =
          error instanceof ApiError
            ? error.status
            : error instanceof Error && !("code" in error)
              ? 400
              : 500;
        send(res, status, {
          error:
            status === 500
              ? "服务器暂时无法完成请求"
              : error instanceof Error
                ? error.message
                : "请求无效",
        });
      })
      .finally(() => {
        if (upload) void unlink(upload.temp).catch(() => {});
      });
  });
  server.requestTimeout = 300_000;
  server.headersTimeout = 15_000;
  server.keepAliveTimeout = 5000;
  server.maxConnections = 100;
  const originalClose = server.close.bind(server);
  server.close = ((callback?: (error?: Error) => void) =>
    originalClose((error) => {
      void store.close().then(
        () => callback?.(error),
        (e) => callback?.(e),
      );
    })) as typeof server.close;
  return server;
}
export interface ProvisionStaffOptions extends StoreOptions {
  email: string;
  name: string;
  group: StaffGroup;
  password: string;
}
export async function provisionStaff(options: ProvisionStaffOptions) {
  const mail = email(options.email),
    name = text(options.name, "员工姓名", 100),
    pass = password(options.password);
  if (!groups.includes(options.group)) throw new Error("员工权限组无效");
  const store = await Store.open(options);
  try {
    const next = structuredClone(store.state);
    if (next.accounts.some((a) => a.email === mail))
      throw new Error("邮箱已存在，不会覆盖现有账户");
    next.accounts.push({
      id: randomUUID(),
      name,
      email: mail,
      role: "staff",
      group: options.group,
      passwordHash: await passwordHash(pass),
    });
    await store.save(next);
  } finally {
    await store.close();
  }
}
