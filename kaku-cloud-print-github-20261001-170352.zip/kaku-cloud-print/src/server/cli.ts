import { randomBytes } from "node:crypto";
import { mkdir, open, unlink } from "node:fs/promises";
import { dirname, resolve, relative, isAbsolute } from "node:path";
import { parseArgs } from "node:util";
import { provisionStaff } from "./server";
import type { StaffGroup } from "../shared/api";

try {
  const { values } = parseArgs({
    options: {
      email: { type: "string" },
      name: { type: "string" },
      group: { type: "string" },
      "credentials-file": { type: "string" },
    },
  });
  if (!values.email || !values.name || !values.group)
    throw new Error(
      "用法: --email 邮箱 --name 姓名 --group pricing|sales|pages [--credentials-file 私有路径]",
    );
  const explicit = process.env.KAKU_STAFF_PASSWORD;
  if (!explicit && !values["credentials-file"])
    throw new Error(
      "请设置 KAKU_STAFF_PASSWORD，或用 --credentials-file 指定私有凭据文件",
    );
  if (explicit && values["credentials-file"])
    throw new Error("KAKU_STAFF_PASSWORD 与 --credentials-file 只能选择一种");
  const password = explicit ?? `Kk9-${randomBytes(24).toString("base64url")}`;
  const credentialsPath = values["credentials-file"]
    ? resolve(values["credentials-file"])
    : undefined;
  if (credentialsPath) {
    for (const folder of ["public", "dist"]) {
      const rel = relative(resolve(folder), credentialsPath);
      if (!rel || (!rel.startsWith("..") && !isAbsolute(rel)))
        throw new Error("凭据不得保存到公开目录");
    }
    await mkdir(dirname(credentialsPath), { recursive: true, mode: 0o700 });
    const handle = await open(credentialsPath, "wx", 0o600);
    try {
      await handle.writeFile(
        JSON.stringify(
          { email: values.email, password, group: values.group },
          null,
          2,
        ) + "\n",
      );
      await handle.sync();
    } finally {
      await handle.close();
    }
  }
  try {
    await provisionStaff({
      dataDir: process.env.DATA_DIR ?? "data",
      seedDir: process.env.SEED_DIR,
      email: values.email,
      name: values.name,
      group: values.group as StaffGroup,
      password,
    });
  } catch (error) {
    if (credentialsPath) await unlink(credentialsPath).catch(() => {});
    throw error;
  }
  console.log(
    credentialsPath
      ? "员工账户已创建，凭据已写入指定私有文件。"
      : "员工账户已创建。",
  );
} catch (error) {
  console.error(error instanceof Error ? error.message : "员工账户创建失败");
  process.exitCode = 1;
}
