export const factoryMaterials = { paper: '纸质卡片', pvc: 'PVC 卡片', pet: 'PET 卡片', metal: '金属卡片', wood: '木质卡片', other: '其他材质' } as const;
export const factoryCrafts = { lamination: '覆膜', diecut: '模切', foil: '烫金', uv: '局部 UV', emboss: '压纹 / 击凸', punch: '打孔' } as const;
export type PrintFactory = {
  id: string; name: string; kind: 'factory' | 'equipment'; operator: string; active: boolean;
  address: string; description: string;
  location?: { latitude: number; longitude: number; crs: 'WGS84' };
  regions: { province: string; city: string; district: string }[];
  materials: (keyof typeof factoryMaterials)[]; crafts: (keyof typeof factoryCrafts)[]; equipment: string[];
};
export type FactoryDirectoryDocument = { version: 1; factories: PrintFactory[] };
export type FactorySearch = { province: string; city: string; district: string; material: string; crafts: string[] };
const record = (v: unknown): v is Record<string, unknown> => !!v && typeof v === 'object' && !Array.isArray(v);
const string = (v: unknown, max = 120): v is string => typeof v === 'string' && !!v.trim() && v.length <= max;
const strings = (v: unknown, max = 30): v is string[] => Array.isArray(v) && v.length <= max && v.every(item => string(item));
export function parseFactoryDirectory(raw: string): FactoryDirectoryDocument {
  if (new TextEncoder().encode(raw).length > 500_000) throw new Error('印厂目录不能超过 500 KB。');
  let value: unknown;
  try { value = JSON.parse(raw.replace(/^\uFEFF/, '')); } catch { throw new Error('印厂目录格式无效。'); }
  if (!record(value) || value.version !== 1 || !Array.isArray(value.factories) || value.factories.length > 100) throw new Error('印厂目录版本或数量无效。');
  const ids = new Set<string>();
  for (const f of value.factories) {
    if (!record(f) || !string(f.id, 100) || !/^[a-zA-Z0-9_-]+$/.test(f.id) || ids.has(f.id) ||
      !string(f.name) || !['factory', 'equipment'].includes(String(f.kind)) || !string(f.operator) || typeof f.active !== 'boolean' ||
      !string(f.address, 300) || !string(f.description, 1000) || !strings(f.equipment) ||
      !strings(f.materials) || !f.materials.length || !f.materials.every(m => Object.hasOwn(factoryMaterials, m)) ||
      !strings(f.crafts) || !f.crafts.every(c => Object.hasOwn(factoryCrafts, c)) ||
      !Array.isArray(f.regions) || !f.regions.length || f.regions.length > 100 ||
      !f.regions.every(r => record(r) && string(r.province) && string(r.city) && string(r.district))) throw new Error('印厂资料无效：请检查编号、承接主体、服务区域与生产能力。');
    if (f.location !== undefined) {
      const point = f.location;
      if (!record(point) || point.crs !== 'WGS84' || typeof point.latitude !== 'number' || !Number.isFinite(point.latitude) || Math.abs(point.latitude) > 85.05112878 || typeof point.longitude !== 'number' || !Number.isFinite(point.longitude) || Math.abs(point.longitude) > 180) throw new Error('印厂坐标无效：请使用 WGS84 经纬度（纬度范围 ±85.05112878，经度范围 ±180）。');
    }
    ids.add(f.id);
  }
  return value as FactoryDirectoryDocument;
}
export function matchesFactory(factory: PrintFactory, query: FactorySearch) {
  return factory.active && !!query.province.trim() && !!query.city.trim() && !!query.district.trim() && !!query.material &&
    factory.regions.some(r => r.province.trim() === query.province.trim() && r.city.trim() === query.city.trim() && (r.district === '*' || r.district.trim() === query.district.trim())) &&
    factory.materials.some(m => m === query.material) && query.crafts.every(c => factory.crafts.some(supported => supported === c));
}
