import initial from "../../public/homepage.json";

export const moduleNames = {
  hero: "首页主视觉",
  services: "服务优势",
  products: "卡片应用",
  process: "定制流程",
  resources: "文件与会员引导",
  cta: "行动入口",
  text: "图文介绍",
  catalog: "产品目录（关联产品管理）",
} as const;
export type ModuleType = keyof typeof moduleNames;
export type HomeItem = {
  id: string;
  title: string;
  text: string;
  eyebrow: string;
  tags: string;
  kind: "insert" | "thanks" | "shape";
  actionLabel: string;
  actionHref: string;
};
export type HomeModule = {
  id: string;
  type: ModuleType;
  enabled: boolean;
  title: string;
  text: string;
  eyebrow: string;
  actionLabel: string;
  actionHref: string;
  secondaryLabel: string;
  secondaryHref: string;
  image: string;
  imageAlt: string;
  note: string;
  items: HomeItem[];
};
export type HomepageDocument = { version: 1; modules: HomeModule[] };
export const MAX_DOCUMENT_BYTES = 500_000;
export const defaultHomepage = initial as HomepageDocument;
// Content identifiers also work on plain HTTP static hosts (not credentials).
function contentId() {
  return (
    crypto.randomUUID?.() ??
    Array.from(crypto.getRandomValues(new Uint32Array(4)), (n) =>
      n.toString(16),
    ).join("-")
  );
}
export function newItem(): HomeItem {
  return {
    id: contentId(),
    title: "新内容",
    text: "填写内容说明。",
    eyebrow: "",
    tags: "",
    kind: "insert",
    actionLabel: "",
    actionHref: "",
  };
}
export function newModule(type: ModuleType): HomeModule {
  const template = defaultHomepage.modules.find((m) => m.type === type);
  if (template)
    return {
      ...structuredClone(template),
      id: contentId(),
      items: template.items.map((i) => ({ ...i, id: contentId() })),
    };
  return {
    id: contentId(),
    type,
    enabled: true,
    title: type === "catalog" ? "产品中心" : "新模块",
    text:
      type === "catalog"
        ? "按材质与用途，寻找适合你的卡片方案。"
        : "填写模块说明。",
    eyebrow: "",
    actionLabel: type === "catalog" ? "查看全部产品" : "",
    actionHref: type === "catalog" ? "/products" : "",
    secondaryLabel: "",
    secondaryHref: "",
    image: "",
    imageAlt: "",
    note: "",
    items: [],
  };
}
const record = (v: unknown): v is Record<string, unknown> =>
  !!v && typeof v === "object" && !Array.isArray(v);
export function safeLink(value: string): boolean {
  if (!value) return true;
  if (/[\s\\\u0000-\u001f]/.test(value)) return false;
  if (
    /^\/(?:quote|login|register|products(?:\/[a-zA-Z0-9_-]+)?)?(?:#[a-zA-Z0-9_-]+)?$/.test(
      value,
    )
  )
    return true;
  try {
    const url = new URL(value);
    return url.protocol === "https:" && !url.username && !url.password;
  } catch {
    return false;
  }
}
export function safeImage(value: string): boolean {
  if (!value) return true;
  return (
    (/^assets\/[a-zA-Z0-9_./-]+\.(?:svg|png|jpg|jpeg|webp|avif)$/i.test(
      value,
    ) &&
      !value.includes("..")) ||
    (/^https:\/\//.test(value) && safeLink(value))
  );
}
export function parseHomepage(text: string): HomepageDocument {
  if (new TextEncoder().encode(text).length > MAX_DOCUMENT_BYTES)
    throw new Error("首页配置不能超过 500 KB。");
  let raw: unknown;
  try {
    raw = JSON.parse(text.replace(/^\uFEFF/, ""));
  } catch {
    throw new Error("首页配置不是有效的 JSON 文件。");
  }
  if (
    !record(raw) ||
    raw.version !== 1 ||
    !Array.isArray(raw.modules) ||
    !raw.modules.length ||
    raw.modules.length > 30
  )
    throw new Error("首页配置版本或模块数量无效（1–30 个模块）。");
  const ids = new Set<string>();
  function str(obj: Record<string, unknown>, key: string, limit = 3000) {
    const v = obj[key];
    if (typeof v !== "string" || v.length > limit)
      throw new Error(`${key} 字段无效或过长。`);
    return v;
  }
  function id(obj: Record<string, unknown>) {
    const value = str(obj, "id", 100);
    if (!/^[a-zA-Z0-9_-]+$/.test(value) || ids.has(value))
      throw new Error("模块或条目 ID 无效或重复。");
    ids.add(value);
    return value;
  }
  function link(obj: Record<string, unknown>, key: string) {
    const v = str(obj, key, 1000);
    if (!safeLink(v))
      throw new Error("按钮链接仅支持站内前台页面或 HTTPS 地址。");
    return v;
  }
  function action(obj: Record<string, unknown>, label: string, href: string) {
    const l = str(obj, label, 100),
      h = link(obj, href);
    if (Boolean(l.trim()) !== Boolean(h))
      throw new Error("按钮文字和链接需要同时填写或同时留空。");
    return { [label]: l, [href]: h };
  }
  const modules = raw.modules.map((m): HomeModule => {
    if (
      !record(m) ||
      typeof m.type !== "string" ||
      !Object.hasOwn(moduleNames, m.type) ||
      typeof m.enabled !== "boolean" ||
      !Array.isArray(m.items) ||
      m.items.length > 20
    )
      throw new Error("模块类型、显示状态或内容条目无效。");
    const title = str(m, "title", 200);
    if (!title.trim()) throw new Error("模块标题不能为空。");
    const image = str(m, "image", 1000);
    if (!safeImage(image))
      throw new Error("图片仅支持 assets 下的图片路径或 HTTPS 地址。");
    const imageAlt = str(m, "imageAlt", 300);
    if (image && !imageAlt.trim()) throw new Error("请填写图片说明。");
    return {
      id: id(m),
      type: m.type as ModuleType,
      enabled: m.enabled,
      title,
      text: str(m, "text"),
      eyebrow: str(m, "eyebrow", 150),
      ...action(m, "actionLabel", "actionHref"),
      ...action(m, "secondaryLabel", "secondaryHref"),
      image,
      imageAlt,
      note: str(m, "note"),
      items: m.items.map((i) => {
        if (
          !record(i) ||
          !["insert", "thanks", "shape"].includes(String(i.kind))
        )
          throw new Error("内容条目格式无效。");
        const title = str(i, "title", 200);
        if (!title.trim()) throw new Error("条目标题不能为空。");
        return {
          id: id(i),
          title,
          text: str(i, "text"),
          eyebrow: str(i, "eyebrow", 150),
          tags: str(i, "tags", 300),
          kind: i.kind as HomeItem["kind"],
          ...action(i, "actionLabel", "actionHref"),
        } as HomeItem;
      }),
    } as HomeModule;
  });
  if (!modules.some((m) => m.enabled))
    throw new Error("首页至少需要一个显示的模块。");
  return { version: 1, modules };
}
export function serializeHomepage(document: HomepageDocument) {
  const serialized =
    JSON.stringify(parseHomepage(JSON.stringify(document)), null, 2) + "\n";
  if (new TextEncoder().encode(serialized).length > MAX_DOCUMENT_BYTES)
    throw new Error("首页配置不能超过 500 KB，请减少内容后再保存或下载。");
  return serialized;
}
