import type { AdminQuote } from "./contracts";

export type StaffGroup = "pricing" | "sales" | "pages";
export interface SessionUser {
  id: string;
  name: string;
  email: string;
  role: "member" | "staff";
  group: StaffGroup | null;
}
export interface SessionResponse {
  user: SessionUser | null;
}
export interface Versioned<T> {
  revision: string;
  data: T;
}
export interface ApiMember {
  id: string;
  name: string;
  email: string;
  company: string;
  phone: string;
  tierId: string;
  active: boolean;
  createdAt: string;
  notes: string;
}
export interface ApiTier {
  id: string;
  name: string;
  discount: number;
}
export interface MembersDocument {
  members: ApiMember[];
  tiers: ApiTier[];
}
export interface PendingFile {
  id: string;
  name: string;
  kind: "print" | "proof" | "certificate";
  size: number;
  createdAt: string;
}
export interface ServerQuote extends AdminQuote {
  quoteId: string;
  expiresAt: string;
}
export type OrderStatus =
  | "submitted"
  | "confirmed"
  | "producing"
  | "shipped"
  | "cancelled";
export interface ApiOrder {
  fileReview?: OrderFileReview;
  id: string;
  memberId: string;
  createdAt: string;
  status: OrderStatus;
  quote: ServerQuote;
  orderName: string;
  contact: string;
  notes: string;
  recipient: {
    name: string;
    phone: string;
    region: string;
    address: string;
    company?: string;
  };
  files: Array<{
    id: string;
    name: string;
    kind: "print" | "proof" | "certificate";
    size: number;
  }>;
}

export type FileReviewStatus = "pending" | "approved" | "rejected";
export type FileCheckId =
  | "artwork"
  | "size"
  | "bleed"
  | "color"
  | "fonts"
  | "crafts";
export interface FileReviewEvent {
  id: string;
  action: "approved" | "rejected" | "resubmitted";
  fileVersion: number;
  actor: { id: string; name: string };
  createdAt: string;
  comment: string;
  checks: FileCheckId[];
  files: ApiOrder["files"];
}
export interface OrderFileReview {
  revision: number;
  fileVersion: number;
  status: FileReviewStatus;
  checks: FileCheckId[];
  comment: string;
  reviewedAt: string | null;
  reviewer: { id: string; name: string } | null;
  history: FileReviewEvent[];
}
