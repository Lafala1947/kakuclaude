import initial from "../../public/products.json";
import { safeImage } from "./homepage";
export type ProductCategory = {
  id: string;
  name: string;
  material: "paper" | "other";
};
export type Product = {
  id: string;
  code: string;
  name: string;
  categoryId: string;
  summary: string;
  description: string;
  image: string;
  imageAlt: string;
  artwork: "insert" | "thanks" | "shape";
  tags: string;
  active: boolean;
  featured: boolean;
  quoteMode: "paper" | "inquiry";
};
export type ProductDocument = {
  version: 1;
  categories: ProductCategory[];
  products: Product[];
};
export const PRODUCT_MAX_BYTES = 1_000_000;
export const defaultProducts = initial as ProductDocument;
export function productId() {
  return (
    crypto.randomUUID?.() ??
    Array.from(crypto.getRandomValues(new Uint32Array(4)), (n) =>
      n.toString(16),
    ).join("-")
  );
}
export function emptyProduct(categoryId: string): Product {
  return {
    id: productId(),
    code: "",
    name: "",
    categoryId,
    summary: "",
    description: "",
    image: "",
    imageAlt: "",
    artwork: "insert",
    tags: "",
    active: false,
    featured: false,
    quoteMode: "inquiry",
  };
}
const record = (v: unknown): v is Record<string, unknown> =>
  !!v && typeof v === "object" && !Array.isArray(v);
export function parseProducts(text: string): ProductDocument {
  if (new TextEncoder().encode(text).length > PRODUCT_MAX_BYTES)
    throw new Error("产品配置不能超过 1 MB。");
  let data: unknown;
  try {
    data = JSON.parse(text.replace(/^\uFEFF/, ""));
  } catch {
    throw new Error("产品配置不是有效的 JSON 文件。");
  }
  if (
    !record(data) ||
    data.version !== 1 ||
    !Array.isArray(data.categories) ||
    !data.categories.length ||
    data.categories.length > 50 ||
    !Array.isArray(data.products) ||
    data.products.length > 500
  )
    throw new Error("产品配置版本或数量无效（1–50 个分类，最多 500 个产品）。");
  const ids = new Set<string>();
  function str(
    o: Record<string, unknown>,
    key: string,
    max: number,
    required = false,
  ) {
    const v = o[key];
    if (typeof v !== "string" || v.length > max || (required && !v.trim()))
      throw new Error(`产品字段 ${key} 无效、为空或过长。`);
    return v.trim();
  }
  function id(o: Record<string, unknown>) {
    const value = str(o, "id", 100, true);
    if (!/^[a-zA-Z0-9_-]+$/.test(value) || ids.has(value))
      throw new Error("产品或分类 ID 重复或无效。");
    ids.add(value);
    return value;
  }
  const categoryNames = new Set<string>();
  const categories = data.categories.map((c): ProductCategory => {
    if (
      !record(c) ||
      typeof c.material !== "string" ||
      !["paper", "other"].includes(c.material)
    )
      throw new Error("分类材质类型无效。");
    const name = str(c, "name", 60, true);
    if (categoryNames.has(name.toLowerCase()))
      throw new Error("分类名称重复。");
    categoryNames.add(name.toLowerCase());
    return {
      id: id(c),
      name,
      material: c.material as ProductCategory["material"],
    };
  });
  const codes = new Set<string>();
  const products = data.products.map((p): Product => {
    if (
      !record(p) ||
      typeof p.active !== "boolean" ||
      typeof p.featured !== "boolean" ||
      typeof p.artwork !== "string" ||
      !["insert", "thanks", "shape"].includes(p.artwork) ||
      typeof p.quoteMode !== "string" ||
      !["paper", "inquiry"].includes(p.quoteMode)
    )
      throw new Error("产品状态或展示设置无效。");
    const code = str(p, "code", 50, true);
    if (!/^[a-zA-Z0-9_-]+$/.test(code) || codes.has(code.toLowerCase()))
      throw new Error("产品编号重复或无效，请使用字母、数字、横线或下划线。");
    codes.add(code.toLowerCase());
    const categoryId = str(p, "categoryId", 100, true),
      category = categories.find((c) => c.id === categoryId);
    if (!category) throw new Error("产品引用的分类不存在。");
    if (p.quoteMode === "paper" && category.material !== "paper")
      throw new Error("只有纸质卡片分类可以使用纸卡通用报价。");
    const image = str(p, "image", 1000),
      imageAlt = str(p, "imageAlt", 300);
    if (!safeImage(image) || (image && !imageAlt))
      throw new Error("图片地址无效或缺少图片说明。");
    return {
      id: id(p),
      code,
      name: str(p, "name", 100, true),
      categoryId,
      summary: str(p, "summary", 300, true),
      description: str(p, "description", 5000),
      image,
      imageAlt,
      artwork: p.artwork as Product["artwork"],
      tags: str(p, "tags", 300),
      active: p.active,
      featured: p.featured,
      quoteMode: p.quoteMode as Product["quoteMode"],
    };
  });
  return { version: 1, categories, products };
}
export function serializeProducts(document: ProductDocument) {
  const text =
    JSON.stringify(parseProducts(JSON.stringify(document)), null, 2) + "\n";
  if (new TextEncoder().encode(text).length > PRODUCT_MAX_BYTES)
    throw new Error("产品配置不能超过 1 MB，请减少内容后再保存或下载。");
  return text;
}
