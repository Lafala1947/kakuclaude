import type { MaterialId, MaterialFee, ExtraFee, ExtraId } from "./catalog";
export type CraftId = "foil" | "texture" | "emboss" | "deboss";
export interface QuoteInput {
  width: number;
  height: number;
  quantity: number;
  variants: number;
  sides: 1 | 2;
  lamination: 0 | 1 | 2;
  cutting: "straight" | "die";
  crafts: CraftId[];
  foilArea: number;
  design: "provided" | "adjust" | "custom";
  shipping: "pickup" | "express";
  region: "local" | "national" | "remote";
  material: MaterialId;
  ink: "cmyk" | "spot";
  extras: ExtraId[];
  circleDiameter: number;
}
export interface PricingConfig {
  version: number;
  published: boolean;
  markup: number | null;
  materials: Record<Exclude<MaterialId, "market300">, MaterialFee>;
  spotInk: ExtraFee;
  extras: Record<ExtraId, ExtraFee>;
  design: { adjust: number; custom: number };
  printing: {
    baseQuantity: number;
    basePrice: number;
    stepQuantity: number;
    stepPrice: number;
    roundSteps: boolean;
  };
  paper: {
    name: string;
    gsm: number;
    tonPrice: number;
    sheetWidth: number;
    sheetHeight: number;
    left: number;
    right: number;
    gripper: number;
    tail: number;
    gap: number;
    waste: number;
    shareCount: number;
  };
  finishing: {
    lamination: number;
    dieRate: number;
    diePlate: number;
    cutting: number;
    foil: number;
    texture: number;
    emboss: number;
    deboss: number;
  };
  logistics: {
    enabled: boolean;
    firstWeight: number;
    firstPrice: number;
    additionalPrice: number;
    packagingWeight: number;
    localMultiplier: number;
    nationalMultiplier: number;
    remoteMultiplier: number;
  };
}
export interface PublicOptions {
  paperName: string;
  gsm: number;
  published: boolean;
  version: number;
  logisticsEnabled: boolean;
}
export interface User {
  id: number;
  email: string;
  name: string;
  role: "admin" | "member";
  tier: string;
  discount: number;
  active: boolean;
}
export interface QuoteResult {
  materialSnapshot?: { id: MaterialId; name: string; gsm: number };
  quoteId?: string;
  expiresAt?: string;
  product?: ProductReference;
  version: number;
  input: QuoteInput;
  standardTotal: number;
  total: number;
  unitPrice: number;
  discount: number;
  tier: string;
  totalQuantity: number;
  createdAt: string;
  productionTotal: number;
  designTotal: number;
  shippingTotal: number;
  weight: number;
}
export interface ProductReference {
  id: string;
  code: string;
  name: string;
  categoryId: string;
  categoryName: string;
}
export interface CostDetails {
  paper: number;
  printing: number;
  finishing: number;
  design: number;
  logistics: number;
  total: number;
  sheetTotal: number;
  imposition: number;
  shareCount: number;
  processingQuantity: number;
  crafts: Record<string, number>;
}
export interface AdminQuote extends QuoteResult {
  cost: CostDetails;
}
export interface SavedQuote {
  id: number;
  createdAt: string;
  note: string;
  quote: QuoteResult;
}
export const defaultInput: QuoteInput = {
  width: 90,
  height: 54,
  quantity: 500,
  variants: 1,
  sides: 2,
  lamination: 0,
  cutting: "straight",
  crafts: [],
  foilArea: 10,
  design: "provided",
  shipping: "pickup",
  region: "local",
  material: "market300",
  ink: "cmyk",
  extras: [],
  circleDiameter: 40,
};
