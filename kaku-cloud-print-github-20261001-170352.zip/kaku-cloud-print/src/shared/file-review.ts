import type {
  ApiOrder,
  FileCheckId,
  OrderFileReview,
  OrderStatus,
} from "./api";

export const fileChecks: { id: FileCheckId; label: string; hint: string }[] = [
  {
    id: "artwork",
    label: "文件完整与可打开",
    hint: "确认印品、对稿及所需授权文件齐全，内容与订单一致。",
  },
  {
    id: "size",
    label: "成品尺寸与正反面",
    hint: "核对订单尺寸、版面方向、正反面及款数。",
  },
  {
    id: "bleed",
    label: "出血与安全边距",
    hint: "核对裁切边界、出血和文字安全边距，按本厂工艺要求确认。",
  },
  {
    id: "color",
    label: "色彩与图片质量",
    hint: "核对 CMYK / 专色、图片清晰度及黑色设置。",
  },
  {
    id: "fonts",
    label: "字体与内容",
    hint: "确认字体转曲或嵌入、无缺字及链接丢失。",
  },
  {
    id: "crafts",
    label: "工艺与刀线",
    hint: "核对刀线、烫金、压凸、UV 等工艺图层；无特殊工艺时确认不适用。",
  },
];
export const reviewLabels = {
  pending: "待审核",
  approved: "审核通过",
  rejected: "退回修改",
} as const;
export function initialFileReview(): OrderFileReview {
  return {
    revision: 1,
    fileVersion: 1,
    status: "pending",
    checks: [],
    comment: "",
    reviewedAt: null,
    reviewer: null,
    history: [],
  };
}
export function getFileReview(order: ApiOrder): OrderFileReview {
  return order.fileReview ?? initialFileReview();
}
export function reviewEditable(order: ApiOrder) {
  return order.status === "submitted" || order.status === "confirmed";
}
export const orderTransitions: Record<OrderStatus, OrderStatus[]> = {
  submitted: ["confirmed", "cancelled"],
  confirmed: ["producing", "cancelled"],
  producing: ["shipped", "cancelled"],
  shipped: [],
  cancelled: [],
};
