export type MaterialId = "market300" | "industry300" | "white300" | "market350";
export type FeeUnit =
  "piece" | "sheet" | "area" | "sheetAreaSide" | "order" | "variant";
export interface ExtraFee {
  enabled: boolean;
  rate: number | null;
  setup: number;
  unit: FeeUnit;
}
export interface MaterialFee {
  name: string;
  gsm: number;
  tonPrice: number | null;
  enabled: boolean;
}
export const feeUnits: Record<FeeUnit, string> = {
  piece: "元 / 成品张",
  sheet: "元 / 大纸张",
  area: "元 / 成品㎡",
  sheetAreaSide: "元 / 大纸㎡ / 面",
  order: "元 / 单",
  variant: "元 / 款",
};
export const extraGroups = [
  {
    id: "coating",
    label: "覆膜/过油工艺",
    items: [
      ["matte", "哑膜"],
      ["gloss", "亮膜"],
      ["scratchMatte", "防刮伤哑膜"],
      ["starFilm", "星光膜"],
      ["touchFilm", "触感膜"],
      ["snowLaser", "雪花镭射膜"],
      ["starLaser", "星星镭射膜"],
      ["varnish", "光油"],
    ],
  },
  {
    id: "common",
    label: "常见工艺",
    items: [
      ["premiumDie", "高品质模切"],
      ["sameKnife", "多款刀版一样"],
      ["crease", "压痕"],
      ["dottedLine", "压点线"],
      ["punch", "打孔"],
      ["rope", "绳子"],
    ],
  },
  {
    id: "shape",
    label: "模切工艺",
    items: [
      ["circle", "圆形"],
      ["roundCorners", "圆角"],
    ],
  },
  {
    id: "special",
    label: "特殊工艺",
    items: [
      ["uv", "局部UV"],
      ["doubleTape", "贴双面胶"],
      ["eyelet", "打气眼"],
      ["spring", "粘跳跳卡弹片"],
    ],
  },
  {
    id: "sample",
    label: "参样工艺",
    items: [
      ["followSample", "翻单跟样"],
      ["workshopSample", "需车间留样"],
      ["providedSample", "自带样"],
    ],
  },
  {
    id: "packaging",
    label: "包装工艺",
    items: [
      ["requestedPack", "按要求打包"],
      ["bundle", "按要求扎捆"],
      ["shrink", "塑封"],
      ["sets", "配套"],
      ["setsOpp", "配套装OPP袋"],
      ["eachOpp", "每款单装OPP袋"],
    ],
  },
  { id: "other", label: "其它工艺", items: [["fullBackground", "满版底色"]] },
] as const;
export type ExtraId = (typeof extraGroups)[number]["items"][number][0];
export const extraNames = Object.fromEntries(
  extraGroups.flatMap((group) => group.items.map(([id, name]) => [id, name])),
) as Record<ExtraId, string>;
export const coatingIds = extraGroups[0].items.map(([id]) => id) as ExtraId[];
export const extraIds = Object.keys(extraNames) as ExtraId[];
