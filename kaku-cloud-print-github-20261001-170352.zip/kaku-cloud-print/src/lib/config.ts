import type { PricingConfig } from "../shared/contracts";
import { coatingIds, extraIds, extraNames, feeUnits } from "../shared/catalog";

const baseExtra = (unit: keyof typeof feeUnits) => ({
  enabled: false,
  rate: null,
  setup: 0,
  unit,
});
const defaultExtras = Object.fromEntries(
  extraIds.map((id) => [
    id,
    baseExtra(
      coatingIds.includes(id)
        ? "sheetAreaSide"
        : ["followSample", "workshopSample", "providedSample"].includes(id)
          ? "order"
          : "piece",
    ),
  ]),
) as PricingConfig["extras"];

export const defaultConfig: PricingConfig = {
  version: 1,
  published: false,
  markup: null,
  materials: {
    industry300: {
      name: "行标300克铜版纸",
      gsm: 300,
      tonPrice: null,
      enabled: false,
    },
    white300: { name: "白卡纸300克", gsm: 300, tonPrice: null, enabled: false },
    market350: {
      name: "市场350克铜版纸",
      gsm: 350,
      tonPrice: null,
      enabled: false,
    },
  },
  spotInk: baseExtra("sheet"),
  extras: defaultExtras,
  design: { adjust: 0, custom: 0 },
  printing: {
    baseQuantity: 500,
    basePrice: 200,
    stepQuantity: 1000,
    stepPrice: 50,
    roundSteps: true,
  },
  paper: {
    name: "铜版纸",
    gsm: 300,
    tonPrice: 4500,
    sheetWidth: 1010,
    sheetHeight: 715,
    left: 10,
    right: 10,
    gripper: 10,
    tail: 10,
    gap: 3,
    waste: 0.05,
    shareCount: 0,
  },
  finishing: {
    lamination: 0.3,
    dieRate: 0.05,
    diePlate: 150,
    cutting: 0,
    foil: 4,
    texture: 20,
    emboss: 20,
    deboss: 20,
  },
  logistics: {
    enabled: false,
    firstWeight: 1,
    firstPrice: 0,
    additionalPrice: 0,
    packagingWeight: 0.2,
    localMultiplier: 1,
    nationalMultiplier: 1,
    remoteMultiplier: 1,
  },
};

type RecordValue = Record<string, unknown>;
const plain = (v: unknown, label: string): RecordValue => {
  if (
    v === null ||
    typeof v !== "object" ||
    Array.isArray(v) ||
    Object.getPrototypeOf(v) !== Object.prototype
  )
    throw new Error(`${label}必须是对象`);
  return v as RecordValue;
};
const exact = (v: RecordValue, keys: readonly string[], label: string) => {
  for (const key of keys)
    if (!Object.hasOwn(v, key)) throw new Error(`${label}缺少${key}`);
  for (const key of Object.keys(v))
    if (!keys.includes(key)) throw new Error(`${label}包含未知字段${key}`);
};
const number = (
  v: unknown,
  label: string,
  min = 0,
  max = 1e9,
  integer = false,
): number => {
  if (
    typeof v !== "number" ||
    !Number.isFinite(v) ||
    v < min ||
    v > max ||
    (integer && !Number.isSafeInteger(v))
  )
    throw new Error(
      `${label}必须是${min}到${max}之间的有效${integer ? "整数" : "数字"}`,
    );
  return v;
};
const boolean = (v: unknown, label: string): boolean => {
  if (typeof v !== "boolean") throw new Error(`${label}必须是真或假`);
  return v;
};
const safeName = (v: unknown, label: string): string => {
  if (
    typeof v !== "string" ||
    !v.trim() ||
    v.length > 80 ||
    /^[\s\t\r\n=+@-]/.test(v)
  )
    throw new Error(`${label}无效或存在表格公式风险`);
  return v;
};
const fee = (
  value: unknown,
  label: string,
  coating = false,
): PricingConfig["spotInk"] => {
  const v = plain(value, label);
  exact(v, ["enabled", "rate", "setup", "unit"], label);
  if (typeof v.unit !== "string" || !Object.hasOwn(feeUnits, v.unit))
    throw new Error(`${label}计费单位无效`);
  if (v.unit === "sheetAreaSide" && !coating)
    throw new Error(`${label}计费单位仅适用于覆膜/过油工艺`);
  return {
    enabled: boolean(v.enabled, `${label}启用状态`),
    rate: v.rate === null ? null : number(v.rate, `${label}单价`),
    setup: number(v.setup, `${label}开版费`),
    unit: v.unit as PricingConfig["spotInk"]["unit"],
  };
};

export function validateConfig(value: unknown): PricingConfig {
  const v = plain(value, "费用配置");
  const extensionKeys = ["materials", "spotInk", "extras"] as const;
  const present = extensionKeys.filter((key) => Object.hasOwn(v, key));
  if (present.length > 0 && present.length < extensionKeys.length)
    throw new Error("费用配置新增费用组不完整");
  const legacy = present.length === 0;
  exact(
    v,
    [
      "version",
      "published",
      "markup",
      "design",
      "printing",
      "paper",
      "finishing",
      "logistics",
      ...(legacy ? [] : extensionKeys),
    ],
    "费用配置",
  );
  const design = plain(v.design, "设计费");
  exact(design, ["adjust", "custom"], "设计费");
  const printing = plain(v.printing, "印刷费");
  exact(
    printing,
    ["baseQuantity", "basePrice", "stepQuantity", "stepPrice", "roundSteps"],
    "印刷费",
  );
  const paper = plain(v.paper, "纸张费");
  exact(
    paper,
    [
      "name",
      "gsm",
      "tonPrice",
      "sheetWidth",
      "sheetHeight",
      "left",
      "right",
      "gripper",
      "tail",
      "gap",
      "waste",
      "shareCount",
    ],
    "纸张费",
  );
  const finishing = plain(v.finishing, "后道工艺费");
  exact(
    finishing,
    [
      "lamination",
      "dieRate",
      "diePlate",
      "cutting",
      "foil",
      "texture",
      "emboss",
      "deboss",
    ],
    "后道工艺费",
  );
  const logistics = plain(v.logistics, "物流费");
  exact(
    logistics,
    [
      "enabled",
      "firstWeight",
      "firstPrice",
      "additionalPrice",
      "packagingWeight",
      "localMultiplier",
      "nationalMultiplier",
      "remoteMultiplier",
    ],
    "物流费",
  );
  const materials = legacy
    ? defaultConfig.materials
    : plain(v.materials, "备选纸张");
  exact(materials, ["industry300", "white300", "market350"], "备选纸张");
  const materialResult = {} as PricingConfig["materials"];
  for (const id of ["industry300", "white300", "market350"] as const) {
    const item = plain(materials[id], `${id}纸张`);
    exact(item, ["name", "gsm", "tonPrice", "enabled"], `${id}纸张`);
    materialResult[id] = {
      name: safeName(item.name, `${id}纸张名称`),
      gsm: number(item.gsm, `${id}克重`, 0.01, 10000),
      tonPrice:
        item.tonPrice === null ? null : number(item.tonPrice, `${id}吨价`),
      enabled: boolean(item.enabled, `${id}启用状态`),
    };
  }
  const extras = legacy ? defaultConfig.extras : plain(v.extras, "附加工艺");
  exact(extras, extraIds, "附加工艺");
  const extraResult = {} as PricingConfig["extras"];
  for (const id of extraIds)
    extraResult[id] = fee(extras[id], extraNames[id], coatingIds.includes(id));
  const result: PricingConfig = {
    version: number(v.version, "版本", 1, 1e9, true),
    published: boolean(v.published, "发布状态"),
    markup: v.markup === null ? null : number(v.markup, "加价率", 0, 100),
    materials: materialResult,
    spotInk: fee(legacy ? defaultConfig.spotInk : v.spotInk, "专色印刷"),
    extras: extraResult,
    design: {
      adjust: number(design.adjust, "文件调整费"),
      custom: number(design.custom, "定制设计费"),
    },
    printing: {
      baseQuantity: number(printing.baseQuantity, "起印数量", 1, 1e9, true),
      basePrice: number(printing.basePrice, "起印费"),
      stepQuantity: number(printing.stepQuantity, "加印步长", 1, 1e9, true),
      stepPrice: number(printing.stepPrice, "加印费"),
      roundSteps: boolean(printing.roundSteps, "加印整档"),
    },
    paper: {
      name: safeName(paper.name, "纸张名称"),
      gsm: number(paper.gsm, "克重", 0.01, 10000),
      tonPrice: number(paper.tonPrice, "吨价"),
      sheetWidth: number(paper.sheetWidth, "整纸宽", 1, 100000),
      sheetHeight: number(paper.sheetHeight, "整纸高", 1, 100000),
      left: number(paper.left, "左预留"),
      right: number(paper.right, "右预留"),
      gripper: number(paper.gripper, "咬口", 8),
      tail: number(paper.tail, "尾边"),
      gap: number(paper.gap, "间距", 0, 100000),
      waste: number(paper.waste, "损耗率", 0, 10),
      shareCount: number(paper.shareCount, "分摊款数", 0, 1e9, true),
    },
    finishing: {
      lamination: number(finishing.lamination, "覆膜费"),
      dieRate: number(finishing.dieRate, "模切加工费"),
      diePlate: number(finishing.diePlate, "刀模费"),
      cutting: number(finishing.cutting, "普通裁切费"),
      foil: number(finishing.foil, "烫金费"),
      texture: number(finishing.texture, "压纹附加费"),
      emboss: number(finishing.emboss, "击凸附加费"),
      deboss: number(finishing.deboss, "压凹附加费"),
    },
    logistics: {
      enabled: boolean(logistics.enabled, "物流启用"),
      firstWeight: number(logistics.firstWeight, "首重", 0.001, 1e9),
      firstPrice: number(logistics.firstPrice, "首重费"),
      additionalPrice: number(logistics.additionalPrice, "续重费"),
      packagingWeight: number(logistics.packagingWeight, "包装重量"),
      localMultiplier: number(logistics.localMultiplier, "本地系数"),
      nationalMultiplier: number(logistics.nationalMultiplier, "全国系数"),
      remoteMultiplier: number(logistics.remoteMultiplier, "偏远系数"),
    },
  };
  if (result.published && result.markup === null)
    throw new Error("发布配置前必须填写加价率");
  if (
    result.paper.sheetWidth <= result.paper.left + result.paper.right ||
    result.paper.sheetHeight <= result.paper.gripper + result.paper.tail
  )
    throw new Error("纸张预留超出整纸尺寸");
  return result;
}
