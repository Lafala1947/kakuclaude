import Decimal from "decimal.js";
import type { PricingConfig } from "../shared/contracts";
import { defaultConfig, validateConfig } from "./config";
import { extraIds, extraNames, feeUnits } from "../shared/catalog";

type ValueKind = "number" | "boolean" | "text" | "nullableNumber" | "feeUnit";
type Column = {
  category: string;
  key: string;
  name: string;
  unit: string;
  description: string;
  kind: ValueKind;
};
const field = (
  category: string,
  key: string,
  name: string,
  unit: string,
  description: string,
  kind: ValueKind = "number",
): Column => ({ category, key, name, unit, description, kind });
const fields: Column[] = [
  field("settings", "version", "配置版本", "", "修改费率后递增", "number"),
  field(
    "settings",
    "published",
    "正式发布",
    "",
    "true 或 false；未发布时只可预览成本",
    "boolean",
  ),
  field(
    "settings",
    "markup",
    "成本加价率",
    "比例",
    "留空表示尚未决定，发布前必须填写",
    "nullableNumber",
  ),
  field("design", "adjust", "文件调整费", "元/款", "每款设计成本"),
  field("design", "custom", "定制设计费", "元/款", "每款设计成本"),
  field(
    "printing",
    "baseQuantity",
    "单面起印数量",
    "张",
    "含损耗的大纸张数门槛",
  ),
  field("printing", "basePrice", "单面起印费", "元", "每印刷面"),
  field(
    "printing",
    "stepQuantity",
    "加印步长",
    "张",
    "超出起印数量后的每档张数",
  ),
  field("printing", "stepPrice", "单面加印费", "元/档", "每印刷面"),
  field(
    "printing",
    "roundSteps",
    "加印整档计费",
    "",
    "true 为向上整档，false 为按比例",
    "boolean",
  ),
  field("paper", "name", "纸张名称", "", "供页面展示", "text"),
  field("paper", "gsm", "纸张克重", "g/㎡", "成品重量与原纸成本"),
  field("paper", "tonPrice", "纸张吨价", "元/吨", "原纸成本"),
  field("paper", "sheetWidth", "整纸长边", "mm", "拼版尺寸"),
  field("paper", "sheetHeight", "整纸短边", "mm", "拼版尺寸"),
  field("paper", "left", "左侧预留", "mm", "可排尺寸"),
  field("paper", "right", "右侧预留", "mm", "可排尺寸"),
  field("paper", "gripper", "咬口", "mm", "至少 8mm"),
  field("paper", "tail", "尾边预留", "mm", "可排尺寸"),
  field("paper", "gap", "相邻净尺寸间距", "mm", "两张之间总间距"),
  field("paper", "waste", "数量加放率", "比例", "例：0.05 为 5%"),
  field(
    "paper",
    "shareCount",
    "整版分摊款数",
    "款",
    "0 表示按自动拼数满版分摊",
  ),
  field("finishing", "lamination", "覆膜费率", "元/㎡/面", "按整张大纸面积"),
  field("finishing", "dieRate", "模切加工费率", "元/大张", "仅收一次"),
  field("finishing", "diePlate", "基础刀模费", "元/整版", "仅收一次"),
  field("finishing", "cutting", "普通裁切费", "元/整版", "未使用刀模时"),
  field("finishing", "foil", "烫金费率", "元/㎡", "按成品图案面积和加工数量"),
  field("finishing", "texture", "压纹版附加费", "元/整版", "与基础刀模费叠加"),
  field("finishing", "emboss", "击凸版附加费", "元/整版", "与基础刀模费叠加"),
  field("finishing", "deboss", "压凹版附加费", "元/整版", "与基础刀模费叠加"),
  field("logistics", "enabled", "启用快递", "", "true 或 false", "boolean"),
  field("logistics", "firstWeight", "首重", "kg", "按成品加包装总重量"),
  field("logistics", "firstPrice", "首重运费", "元", "未超过首重时收取"),
  field(
    "logistics",
    "additionalPrice",
    "续重运费",
    "元/kg",
    "超出首重部分向上取整 kg",
  ),
  field("logistics", "packagingWeight", "包装重量", "kg", "每单一次"),
  field("logistics", "localMultiplier", "本地区域系数", "倍", "运费乘数"),
  field("logistics", "nationalMultiplier", "全国区域系数", "倍", "运费乘数"),
  field("logistics", "remoteMultiplier", "偏远区域系数", "倍", "运费乘数"),
  ...(["industry300", "white300", "market350"] as const).flatMap((id) => [
    field(
      "materials",
      `${id}.name`,
      `${id}纸张名称`,
      "",
      "备选材料名称",
      "text",
    ),
    field(
      "materials",
      `${id}.gsm`,
      `${id}纸张克重`,
      "g/㎡",
      "成品重量与原纸成本",
    ),
    field(
      "materials",
      `${id}.tonPrice`,
      `${id}纸张吨价`,
      "元/吨",
      "留空表示尚未决定",
      "nullableNumber",
    ),
    field(
      "materials",
      `${id}.enabled`,
      `${id}启用`,
      "",
      "true 或 false",
      "boolean",
    ),
  ]),
  ...["enabled", "rate", "setup", "unit"].map((key) =>
    field(
      "spotInk",
      key,
      `专色印刷${{ enabled: "启用", rate: "费率", setup: "开版费", unit: "单位" }[key as "enabled" | "rate" | "setup" | "unit"]}`,
      key === "unit"
        ? "计费单位"
        : key === "rate"
          ? "元/单位"
          : key === "setup"
            ? "元/单"
            : "",
      "专色印刷配置",
      key === "enabled"
        ? "boolean"
        : key === "rate"
          ? "nullableNumber"
          : key === "unit"
            ? "feeUnit"
            : "number",
    ),
  ),
  ...extraIds.flatMap((id) => [
    field(
      "extras",
      `${id}.enabled`,
      `${extraNames[id]}启用`,
      "",
      "true 或 false",
      "boolean",
    ),
    field(
      "extras",
      `${id}.rate`,
      `${extraNames[id]}费率`,
      "元/单位",
      "留空表示尚未决定",
      "nullableNumber",
    ),
    field(
      "extras",
      `${id}.setup`,
      `${extraNames[id]}开版费`,
      "元/单",
      "所选工艺每单一次",
    ),
    field(
      "extras",
      `${id}.unit`,
      `${extraNames[id]}单位`,
      "计费单位",
      "piece sheet area sheetAreaSide order variant",
      "feeUnit",
    ),
  ]),
];
const header = ["category", "key", "name", "value", "unit", "description"];
const identifiers = new Map(fields.map((f) => [`${f.category}.${f.key}`, f]));

function csvCell(value: string): string {
  return /[",\r\n]/.test(value) ? `"${value.replace(/"/g, '""')}"` : value;
}

function readRows(text: string): string[][] {
  const source = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
  const rows: string[][] = [];
  let row: string[] = [],
    cell = "",
    quoted = false,
    closed = false;
  for (let index = 0; index < source.length; index++) {
    const char = source[index];
    if (quoted) {
      if (char === '"' && source[index + 1] === '"') {
        cell += '"';
        index++;
      } else if (char === '"') {
        quoted = false;
        closed = true;
      } else cell += char;
    } else if (char === '"') {
      if (cell !== "" || closed) throw new Error("CSV 引号格式错误");
      quoted = true;
    } else if (char === ",") {
      row.push(cell);
      cell = "";
      closed = false;
    } else if (char === "\n" || char === "\r") {
      if (char === "\r" && source[index + 1] === "\n") index++;
      row.push(cell);
      rows.push(row);
      row = [];
      cell = "";
      closed = false;
    } else {
      if (closed) throw new Error("CSV 引号后存在多余字符");
      cell += char;
    }
  }
  if (quoted) throw new Error("CSV 引号没有闭合");
  if (row.length || cell !== "" || closed) {
    row.push(cell);
    rows.push(row);
  }
  return rows;
}

function parseValue(
  raw: string,
  kind: ValueKind,
  label: string,
): string | number | boolean | null {
  if (kind === "text") return raw;
  if (kind === "feeUnit") {
    if (Object.hasOwn(feeUnits, raw)) return raw;
    throw new Error(`${label}计费单位无效`);
  }
  if (kind === "boolean") {
    if (/^(true|false)$/i.test(raw)) return raw.toLowerCase() === "true";
    throw new Error(`${label}必须填写 true 或 false`);
  }
  if (kind === "nullableNumber" && raw === "") return null;
  if (!/^(?:0|[1-9]\d*)(?:\.\d+)?$/.test(raw))
    throw new Error(`${label}必须填写有效数字`);
  const value = Number(raw);
  if (!Number.isFinite(value)) throw new Error(`${label}数字超出范围`);
  return value;
}

export function parsePricingCsv(text: string): PricingConfig {
  if (typeof text !== "string") throw new Error("CSV 内容必须是文本");
  const rows = readRows(text);
  if (
    !rows.length ||
    rows[0].length !== header.length ||
    rows[0].some((value, i) => value !== header[i])
  )
    throw new Error("CSV 表头格式错误");
  const result = structuredClone(defaultConfig) as unknown as Record<
    string,
    unknown
  >;
  const seen = new Set<string>();
  for (const row of rows.slice(1)) {
    if (row.length !== header.length) throw new Error("CSV 行列格式错误");
    const [category, key, name, raw, unit, description] = row;
    const id = `${category}.${key}`;
    const definition = identifiers.get(id);
    if (!definition) throw new Error(`CSV 包含未知费用字段 ${id}`);
    if (seen.has(id)) throw new Error(`CSV 包含重复费用字段 ${id}`);
    if (
      name !== definition.name ||
      unit !== definition.unit ||
      description !== definition.description
    )
      throw new Error(`CSV 字段说明格式错误 ${id}`);
    seen.add(id);
    const value = parseValue(raw, definition.kind, definition.name);
    if (category === "settings") result[key] = value;
    else if (key.includes(".")) {
      const [id, property] = key.split(".");
      (
        (result[category] as Record<string, unknown>)[id] as Record<
          string,
          unknown
        >
      )[property] = value;
    } else (result[category] as Record<string, unknown>)[key] = value;
  }
  const legacy = ![...seen].some((id) =>
    /^(materials|spotInk|extras)\./.test(id),
  );
  const required = legacy
    ? fields.filter(
        (f) => !["materials", "spotInk", "extras"].includes(f.category),
      )
    : fields;
  if (seen.size !== required.length)
    throw new Error(
      `CSV 费用字段不完整，缺少 ${fields
        .filter(
          (f) => required.includes(f) && !seen.has(`${f.category}.${f.key}`),
        )
        .map((f) => f.key)
        .join("、")}`,
    );
  return validateConfig(result);
}

export function serializePricingCsv(config: PricingConfig): string {
  const valid = validateConfig(config);
  const data = valid as unknown as Record<string, unknown>;
  const rows = [header.join(",")];
  for (const definition of fields) {
    const { category, key, name, unit, description } = definition;
    const value =
      category === "settings"
        ? data[key]
        : key.includes(".")
          ? (
              (data[category] as Record<string, unknown>)[
                key.split(".")[0]
              ] as Record<string, unknown>
            )[key.split(".")[1]]
          : (data[category] as Record<string, unknown>)[key];
    const encoded =
      value === null
        ? ""
        : typeof value === "number"
          ? new Decimal(value).toFixed()
          : String(value);
    rows.push(
      [category, key, name, encoded, unit, description].map(csvCell).join(","),
    );
  }
  return "\ufeff" + rows.join("\r\n") + "\r\n";
}
