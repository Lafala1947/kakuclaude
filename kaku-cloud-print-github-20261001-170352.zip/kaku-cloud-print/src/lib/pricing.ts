import Decimal from "decimal.js";
import type {
  AdminQuote,
  CraftId,
  PricingConfig,
  QuoteInput,
} from "../shared/contracts";
import { validateConfig } from "./config";
import { coatingIds, extraIds, extraNames } from "../shared/catalog";

const D = (v: number) => new Decimal(v);
const money = (v: Decimal) => v.toDecimalPlaces(2, Decimal.ROUND_HALF_UP);
const toNumber = (v: Decimal) => v.toNumber();
const craftIds: CraftId[] = ["foil", "texture", "emboss", "deboss"];
const keys = [
  "width",
  "height",
  "quantity",
  "variants",
  "sides",
  "lamination",
  "cutting",
  "crafts",
  "foilArea",
  "design",
  "shipping",
  "region",
  "material",
  "ink",
  "extras",
  "circleDiameter",
];
const labels: Record<string, string> = {
  width: "成品宽度",
  height: "成品高度",
  quantity: "每款交付数量",
  variants: "购买款数",
  sides: "印刷面数",
  lamination: "覆膜面数",
  cutting: "裁切方式",
  crafts: "后道工艺",
  foilArea: "烫金面积",
  design: "设计方式",
  shipping: "物流方式",
  region: "配送区域",
  material: "纸张材料",
  ink: "印刷色彩",
  extras: "附加工艺",
  circleDiameter: "圆形直径",
};

export function validateInput(input: unknown): QuoteInput {
  if (
    input === null ||
    typeof input !== "object" ||
    Array.isArray(input) ||
    Object.getPrototypeOf(input) !== Object.prototype
  )
    throw new Error("报价参数必须是对象");
  const v = input as Record<string, unknown>;
  for (const key of keys)
    if (!Object.hasOwn(v, key)) throw new Error(`报价参数缺少${labels[key]}`);
  for (const key of Object.keys(v))
    if (!keys.includes(key)) throw new Error(`报价参数包含未知字段${key}`);
  const num = (
    key: string,
    min: number,
    max: number,
    integer = false,
  ): number => {
    const value = v[key];
    if (
      typeof value !== "number" ||
      !Number.isFinite(value) ||
      value < min ||
      value > max ||
      (integer && !Number.isSafeInteger(value))
    )
      throw new Error(
        `${labels[key]}必须是${min}到${max}之间的有效${integer ? "整数" : "数字"}`,
      );
    return value;
  };
  const choice = <T extends string | number>(
    key: string,
    allowed: readonly T[],
  ): T => {
    if (!allowed.includes(v[key] as T))
      throw new Error(`${labels[key]}选项无效`);
    return v[key] as T;
  };
  if (!Array.isArray(v.crafts) || v.crafts.some((id) => !craftIds.includes(id)))
    throw new Error("后道工艺选项无效");
  if (
    !Array.isArray(v.extras) ||
    v.extras.some((id) => !extraIds.includes(id)) ||
    new Set(v.extras).size !== v.extras.length
  )
    throw new Error("附加工艺选项无效或重复");
  const result: QuoteInput = {
    width: num("width", 0.001, 100000),
    height: num("height", 0.001, 100000),
    quantity: num("quantity", 1, 1e9, true),
    variants: num("variants", 1, 1e9, true),
    sides: choice("sides", [1, 2] as const),
    lamination: choice("lamination", [0, 1, 2] as const),
    cutting: choice("cutting", ["straight", "die"] as const),
    crafts: [...new Set(v.crafts as CraftId[])],
    foilArea: num("foilArea", 0, 1e9),
    design: choice("design", ["provided", "adjust", "custom"] as const),
    shipping: choice("shipping", ["pickup", "express"] as const),
    region: choice("region", ["local", "national", "remote"] as const),
    material: choice("material", [
      "market300",
      "industry300",
      "white300",
      "market350",
    ] as const),
    ink: choice("ink", ["cmyk", "spot"] as const),
    extras: [...v.extras],
    circleDiameter: num("circleDiameter", 0.001, 100000),
  };
  if (result.extras.filter((id) => coatingIds.includes(id)).length > 1)
    throw new Error("覆膜/过油工艺只能选一项");
  if (
    result.extras.some((id) => coatingIds.includes(id)) &&
    result.lamination === 0
  )
    throw new Error("选择覆膜/过油工艺时必须指定覆膜面数");
  if (
    result.extras.includes("circle") &&
    (result.width !== result.height || result.width !== result.circleDiameter)
  )
    throw new Error("圆形尺寸必须与直径一致");
  if (result.extras.includes("sameKnife") && result.variants < 2)
    throw new Error("多款刀版一样至少需要两款");
  if (
    result.crafts.includes("foil") &&
    (result.foilArea === 0 ||
      D(result.foilArea).gt(
        D(result.width).times(result.height).times(result.sides).div(100),
      ))
  )
    throw new Error("烫金面积必须大于0且不能超过成品印刷面总面积");
  return result;
}

export function resolveMaterial(
  input: QuoteInput,
  config: PricingConfig,
): { name: string; gsm: number; tonPrice: number } {
  if (input.material === "market300")
    return {
      name: config.paper.name,
      gsm: config.paper.gsm,
      tonPrice: config.paper.tonPrice,
    };
  const selected = config.materials[input.material];
  if (!selected || !selected.enabled || selected.tonPrice === null)
    throw new Error("所选纸张材料尚未配置价格或启用");
  return {
    name: selected.name,
    gsm: selected.gsm,
    tonPrice: selected.tonPrice,
  };
}

function selectedFee(
  input: QuoteInput,
  rate: number,
  unit: PricingConfig["spotInk"]["unit"],
  n: Decimal,
  V: Decimal,
  K: number,
  bigSheetArea: Decimal,
): Decimal {
  const r = D(rate);
  switch (unit) {
    case "piece":
      return r.times(n).times(V);
    case "sheet":
      return r.times(n).times(V).div(K);
    case "area":
      return r
        .times(input.width)
        .times(input.height)
        .div(1e6)
        .times(n)
        .times(V);
    case "sheetAreaSide":
      return r
        .times(bigSheetArea)
        .times(n)
        .times(V)
        .div(K)
        .times(input.lamination);
    case "order":
      return r;
    case "variant":
      return r.times(V);
  }
}

function imposition(input: QuoteInput, config: PricingConfig): number {
  const p = config.paper;
  const W = D(p.sheetWidth).minus(p.left).minus(p.right);
  const H = D(p.sheetHeight).minus(p.gripper).minus(p.tail);
  const w = D(input.width);
  const h = D(input.height);
  const g = D(p.gap);
  if (
    Decimal.max(
      W.plus(g).div(w.plus(g)).floor(),
      H.plus(g).div(h.plus(g)).floor(),
    ).gt(200)
  )
    throw new Error("尺寸超出自动枚举上限，需要人工确认拼版");
  let best = 0;
  for (let k = 0; k <= 200; k++) {
    const usedWidth = w.plus(g).times(k);
    if (usedWidth.lte(W.plus(g))) {
      const rotated = W.plus(g).minus(usedWidth).div(h.plus(g)).floor();
      const total = D(k)
        .times(H.plus(g).div(h.plus(g)).floor())
        .plus(rotated.times(H.plus(g).div(w.plus(g)).floor()));
      best = Math.max(best, total.toNumber());
    }
    const usedHeight = h.plus(g).times(k);
    if (usedHeight.lte(H.plus(g))) {
      const rotated = H.plus(g).minus(usedHeight).div(w.plus(g)).floor();
      const total = D(k)
        .times(W.plus(g).div(w.plus(g)).floor())
        .plus(rotated.times(W.plus(g).div(h.plus(g)).floor()));
      best = Math.max(best, total.toNumber());
    }
  }
  if (best < 1) throw new Error("成品尺寸无法排入当前纸张");
  return best;
}

export function calculateQuote(
  input: QuoteInput,
  config: PricingConfig,
  options: { preview?: boolean } = {},
): AdminQuote {
  const i = validateInput(input);
  const c = validateConfig(config);
  const material = resolveMaterial(i, c);
  for (const id of i.extras) {
    const extra = c.extras[id];
    if (!extra.enabled || extra.rate === null)
      throw new Error(`${extraNames[id]}工艺尚未配置价格或启用`);
  }
  if (i.ink === "spot" && (!c.spotInk.enabled || c.spotInk.rate === null))
    throw new Error("专色印刷尚未配置价格或启用");
  if (i.shipping === "express" && !c.logistics.enabled)
    throw new Error("当前未启用快递物流，请选择自取");
  if (!options.preview && (!c.published || c.markup === null))
    throw new Error("报价尚未发布或未填写加价率");
  const P = imposition(i, c);
  const K = c.paper.shareCount || P;
  if (K > P) throw new Error("分摊款数不能超过拼数");
  if (i.variants > K) throw new Error("购买款数不能超过分摊款数或拼数");
  const V = D(i.variants);
  const share = V.div(K);
  const n = D(i.quantity).times(D(1).plus(c.paper.waste)).ceil();
  const area = D(c.paper.sheetWidth).times(c.paper.sheetHeight).div(1e6);
  const paperSheet = area.times(material.gsm).times(material.tonPrice).div(1e6);
  const paper = n.times(paperSheet);
  const excess = Decimal.max(0, n.minus(c.printing.baseQuantity)).div(
    c.printing.stepQuantity,
  );
  const steps = c.printing.roundSteps ? excess.ceil() : excess;
  const printing = D(i.sides).times(
    D(c.printing.basePrice).plus(steps.times(c.printing.stepPrice)),
  );
  const genericLamination = n
    .times(area)
    .times(c.finishing.lamination)
    .times(i.lamination);
  const lamination = i.extras.some((id) => coatingIds.includes(id))
    ? D(0)
    : genericLamination;
  const selectedPlate = (["texture", "emboss", "deboss"] as const).filter(
    (id) => i.crafts.includes(id),
  );
  const die =
    i.cutting === "die" ||
    selectedPlate.length > 0 ||
    i.extras.some((id) =>
      ["premiumDie", "circle", "roundCorners"].includes(id),
    );
  const processing = die
    ? n.times(c.finishing.dieRate)
    : D(c.finishing.cutting);
  const plateAddons = selectedPlate.reduce(
    (sum, id) => sum.plus(c.finishing[id]),
    D(0),
  );
  const plate = die ? D(c.finishing.diePlate).plus(plateAddons) : D(0);
  const sheetTotal = paper
    .plus(printing)
    .plus(lamination)
    .plus(processing)
    .plus(plate);
  const foilPerVariant = i.crafts.includes("foil")
    ? D(i.foilArea).div(1e4).times(n).times(c.finishing.foil)
    : D(0);
  const foil = foilPerVariant.times(V);
  const extraCosts: Record<string, Decimal> = {};
  let finishingExtras = D(0);
  for (const id of i.extras) {
    const fee = c.extras[id];
    const cost = selectedFee(i, fee.rate!, fee.unit, n, V, K, area).plus(
      fee.setup,
    );
    extraCosts[id] = cost;
    finishingExtras = finishingExtras.plus(cost);
  }
  const spot =
    i.ink === "spot"
      ? selectedFee(i, c.spotInk.rate!, c.spotInk.unit, n, V, K, area).plus(
          c.spotInk.setup,
        )
      : D(0);
  const production = sheetTotal
    .times(share)
    .plus(foil)
    .plus(finishingExtras)
    .plus(spot);
  const designUnit = i.design === "provided" ? 0 : c.design[i.design];
  const design = D(designUnit).times(V);
  const weight = D(i.width)
    .times(i.height)
    .div(1e6)
    .times(material.gsm)
    .div(1000)
    .times(i.quantity)
    .times(V)
    .plus(c.logistics.packagingWeight);
  let freight = D(0);
  if (i.shipping === "express" && c.logistics.enabled) {
    const extra = Decimal.max(0, weight.minus(c.logistics.firstWeight)).ceil();
    const multiplier = c.logistics[`${i.region}Multiplier`];
    freight = money(
      D(c.logistics.firstPrice)
        .plus(extra.times(c.logistics.additionalPrice))
        .times(multiplier),
    );
  }
  const markup = D(1).plus(c.markup ?? 0);
  const markedCombined = money(production.plus(design).times(markup));
  const productionTotal = money(production.times(markup));
  const designTotal = markedCombined.minus(productionTotal);
  const total = markedCombined.plus(freight);
  const crafts: Record<string, number> = {};
  for (const id of i.crafts)
    crafts[id] = toNumber(
      id === "foil" ? foil : D(c.finishing[id]).times(share),
    );
  for (const id of i.extras) crafts[id] = toNumber(extraCosts[id]);
  if (i.ink === "spot") crafts.spotInk = toNumber(spot);
  const totalQuantity = i.quantity * i.variants;
  return {
    version: c.version,
    materialSnapshot: { id: i.material, name: material.name, gsm: material.gsm },
    input: i,
    standardTotal: toNumber(total),
    total: toNumber(total),
    unitPrice: toNumber(total.div(totalQuantity)),
    discount: 1,
    tier: "标准报价",
    totalQuantity,
    createdAt: new Date().toISOString(),
    productionTotal: toNumber(productionTotal),
    designTotal: toNumber(designTotal),
    shippingTotal: toNumber(freight),
    weight: toNumber(weight),
    cost: {
      paper: toNumber(paper.times(share)),
      printing: toNumber(printing.times(share).plus(spot)),
      finishing: toNumber(
        lamination
          .plus(processing)
          .plus(plate)
          .times(share)
          .plus(foil)
          .plus(finishingExtras),
      ),
      design: toNumber(design),
      logistics: toNumber(freight),
      total: toNumber(production.plus(design).plus(freight)),
      sheetTotal: toNumber(sheetTotal),
      imposition: P,
      shareCount: K,
      processingQuantity: n.toNumber(),
      crafts,
    },
  };
}
