import { lazy, Suspense, useCallback, useEffect, useState } from "react";
import {
  Link,
  Navigate,
  NavLink,
  Route,
  Routes,
  useLocation,
} from "react-router-dom";
import {
  ArrowUpRight,
  ChevronRight,
  FileSpreadsheet,
  RefreshCw,
  Settings2,
} from "lucide-react";
import type { PricingConfig } from "../shared/contracts";
import { parsePricingCsv } from "../lib/csv";
import { apiEnabled, apiRequest } from "./api/client";
import { useSession } from "./api/SessionContext";
import type { Versioned } from "../shared/api";
import OrdersPage from "./order/OrdersPage";
import AdminPage from "./AdminPage";
import AuthPage from "./members/AuthPage";
import MemberAdmin from "./members/MemberAdmin";
import HomePage from "./HomePage";
import { message } from "./utils";
import { AdminAccessProvider, AdminGuard } from "./admin/AdminAccess";
import AdminPortal from "./admin/AdminPortal";
const FactoryWorkspace = lazy(() => import('./factory/FactoryWorkspace'));
const FactoryDirectory = lazy(() => import('./factory/FactoryDirectory'));
const AboutPage = lazy(() => import('./AboutPage'));
import { HomeContentProvider } from "./content/HomeContentContext";
import PageAdmin from "./content/PageAdmin";
import { ProductsProvider } from "./products/ProductsContext";
import ProductAdmin from "./products/ProductAdmin";
import ProductCatalog from "./products/ProductCatalog";
import ProductQuoteRoute from "./products/ProductQuoteRoute";

export default function App() {
  return (
    <AdminAccessProvider>
      <HomeContentProvider>
        <ProductsProvider>
          <AppRoutes />
        </ProductsProvider>
      </HomeContentProvider>
    </AdminAccessProvider>
  );
}
function AppRoutes() {
  const session = useSession();
  const [sessionError, setSessionError] = useState("");
  const location = useLocation();
  const pathname = location.pathname.replace(/\/+$/, "") || "/";
  const independentPage =
    ["/", "/about", "/login", "/register", "/orders", "/admin/members"].includes(
      pathname,
    ) ||
    pathname.startsWith("/admin") ||
    pathname.startsWith("/products") || pathname.startsWith("/factories");
  const [config, setConfig] = useState<PricingConfig | null>(null);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const load = useCallback(async () => {
    setLoading(true);
    setError("");
    setConfig(null);
    try {
      if (apiEnabled) {
        const result =
          await apiRequest<Versioned<PricingConfig>>("/config/pricing");
        setConfig(result.data);
        return;
      }
      const res = await fetch(
        `${import.meta.env.BASE_URL}pricing.csv?t=${Date.now()}`,
        { cache: "no-store" },
      );
      if (!res.ok)
        throw new Error(
          `费用表读取失败（${res.status}），请确认 pricing.csv 已上传到网页同一目录。`,
        );
      const parsed = parsePricingCsv(await res.text());
      setConfig(parsed);
    } catch (e) {
      setError(message(e));
    } finally {
      setLoading(false);
    }
  }, []);
  useEffect(() => {
    void load();
  }, [load]);
  useEffect(() => {
    if (!location.hash && window.scrollY > 0) window.scrollTo(0, 0);
  }, [location.pathname, location.hash]);
  useEffect(() => {
    if (!location.hash) return;
    const id = location.hash.slice(1);
    const timer = setTimeout(
      () =>
        document.getElementById(id)?.scrollIntoView?.({
          behavior: window.matchMedia?.("(prefers-reduced-motion: reduce)")
            .matches
            ? "auto"
            : "smooth",
          block: "start",
        }),
      0,
    );
    return () => clearTimeout(timer);
  }, [location.pathname, location.hash, loading]);
  return (
    <div className="kaku-site">
      <div className="utility-bar">
        <div className="site-width">
          <span>卡库云印 · 多材质卡片定制</span>
          <div>
            <span className="utility-detail">定制印刷 · 在线报价</span>
            {apiEnabled && session.user ? (
              <div className="session-account">
                <span>{session.user.name}</span>
                <Link to={session.user.role === "staff" ? "/admin" : "/orders"}>
                  {session.user.role === "staff" ? "管理工作台" : "我的订单"}
                </Link>
                <button
                  onClick={() => {
                    setSessionError("");
                    void session
                      .logout()
                      .catch((e) => setSessionError(message(e)));
                  }}
                >
                  退出
                </button>
              </div>
            ) : (
              <>
                <Link to="/login">会员登录</Link>
                <Link to="/register">注册会员</Link>
              </>
            )}
            <Link to="/admin">
              <Settings2 size={12} />
              后台入口
            </Link>
          </div>
        </div>
      </div>
      <header className="site-header">
        <div className="site-width header-inner">
          <Link to="/" className="brand" aria-label="卡库云印首页">
            <span className="brand-icon">
              <span className="cmyk-brand-mark" aria-hidden="true">
                <i />
                <i />
                <i />
                <i />
              </span>
            </span>
            <span>
              卡库云印<span className="brand-en">KAKU CLOUD PRINT</span>
            </span>
          </Link>
          <nav aria-label="主导航">
            <NavLink end to="/">
              首页
            </NavLink>
            <NavLink to="/quote">在线报价</NavLink>
            <NavLink to="/products">产品中心</NavLink>
            <NavLink to="/factories">线上工厂</NavLink>
            <NavLink to="/login" className="nav-member">
              会员服务
            </NavLink>
            <NavLink to="/about" className="nav-about">
              关于我们
            </NavLink>
          </nav>
          <Link to="/admin" className="header-manage">
            <FileSpreadsheet size={17} />
            <span>后台管理</span>
            <ArrowUpRight size={14} />
          </Link>
        </div>
      </header>
      {pathname !== "/" &&
        !pathname.startsWith("/admin") &&
        !pathname.startsWith("/products") && !pathname.startsWith("/factories") && pathname !== "/about" && (
          <div className="category-bar">
            <div className="site-width">
              <span className="category-label">卡库云印 · 卡片定制</span>
              <span className="category-current">名片 / 卡片</span>
              <ChevronRight size={14} />
              <span>定制插卡</span>
              <span className="category-end">选规格 · 算价格 · 存报价</span>
            </div>
          </div>
        )}
      <main
        className={`site-width main-content ${pathname === "/" || pathname === "/admin/home-preview" ? "home-main" : ""}`}
      >
        {sessionError && (
          <p role="alert" className="reference-error">
            {sessionError}
          </p>
        )}
        {!independentPage &&
          (loading ? (
            <div className="loading-state">
              <RefreshCw className="spin" size={24} />
              <h2>正在读取费用表</h2>
              <p>马上为你准备报价选项…</p>
            </div>
          ) : error ? (
            <div className="load-error" role="alert">
              <h2>暂时无法加载报价配置</h2>
              <p>{error}</p>
              <button className="button primary" onClick={() => void load()}>
                <RefreshCw size={16} />
                重新加载
              </button>
              <Link to="/admin" className="button secondary">
                打开费用表管理
              </Link>
            </div>
          ) : null)}
        {(!loading || independentPage) && (
          <Routes>
            <Route
              path="/admin/reviews"
              element={
                <AdminGuard group="sales">
                  <OrdersPage key="reviews" admin reviewsOnly />
                </AdminGuard>
              }
            />
            <Route path="/orders" element={<OrdersPage />} />
            <Route
              path="/admin/orders"
              element={
                <AdminGuard group="sales">
                  <OrdersPage admin />
                </AdminGuard>
              }
            />
            <Route
              path="/"
              element={
                ["#details", "#guide"].includes(location.hash) ? (
                  <Navigate replace to={`/quote${location.hash}`} />
                ) : (
                  <HomePage />
                )
              }
            />
            <Route
              path="/login"
              element={<AuthPage key="login" mode="login" />}
            />
            <Route
              path="/register"
              element={<AuthPage key="register" mode="register" />}
            />
            <Route
              path="/admin/members"
              element={
                <AdminGuard group="sales">
                  <MemberAdmin />
                </AdminGuard>
              }
            />
            <Route
              path="/admin/pages"
              element={
                <AdminGuard group="pages">
                  <PageAdmin />
                </AdminGuard>
              }
            />
            <Route
              path="/admin/home-preview"
              element={
                <AdminGuard group="pages">
                  <HomePage preview />
                </AdminGuard>
              }
            />
            <Route
              path="/quote"
              element={config ? <ProductQuoteRoute config={config} /> : null}
            />
            <Route path="/admin" element={<AdminPortal />} />
            <Route path="/about" element={<Suspense fallback={<p role="status">正在加载关于我们…</p>}><AboutPage /></Suspense>} />
            <Route path="/factories/:factoryId?" element={<Suspense fallback={<p role="status">正在加载选厂页面…</p>}><FactoryDirectory /></Suspense>} />
            <Route path="/admin/factory/:moduleId?" element={<AdminGuard><Suspense fallback={<p role="status">正在加载工厂总览…</p>}><FactoryWorkspace /></Suspense></AdminGuard>} />
            <Route path="/products" element={<ProductCatalog />} />
            <Route
              path="/products/:productId"
              element={<ProductCatalog detail />}
            />
            <Route
              path="/admin/products"
              element={
                <AdminGuard group="pages">
                  <ProductAdmin />
                </AdminGuard>
              }
            />
            <Route
              path="/admin/products/preview"
              element={
                <AdminGuard group="pages">
                  <ProductCatalog preview />
                </AdminGuard>
              }
            />
            <Route
              path="/admin/pricing"
              element={
                <AdminGuard group="pricing">
                  {loading ? (
                    <p role="status">正在读取费用表…</p>
                  ) : (
                    <>
                      <div>
                        {error && (
                          <p className="admin-demo-banner" role="alert">
                            {error}
                          </p>
                        )}
                      </div>
                      <AdminPage deployed={config} onReload={load} />
                    </>
                  )}
                </AdminGuard>
              }
            />
            <Route
              path="*"
              element={
                <div className="empty-state">
                  <h2>页面不存在</h2>
                  <Link to="/">返回首页</Link>
                </div>
              }
            />
          </Routes>
        )}
      </main>
      <footer className="site-footer">
        <div className="site-width">
          <Link to="/" className="footer-brand">
            卡库云印 <span>KAKU</span>
          </Link>
          <p>从材质、印刷到工艺，为卡片项目提供清晰方案。</p>
          <span>多材质卡片定制平台</span>
        </div>
      </footer>
    </div>
  );
}
