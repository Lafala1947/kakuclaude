import type { AdminQuote } from "../../shared/contracts";

export type OrderFileKind = "print" | "proof" | "certificate";

export interface OrderRecipient {
  name: string;
  phone: string;
  region: string;
  address: string;
  company?: string;
}

/** Browser-side order shape. Map this to the real API only after its contract is known. */
export interface OrderDraft {
  quote: AdminQuote;
  recipient: OrderRecipient;
  contact: string;
  orderName: string;
  notes: string;
  files: Record<OrderFileKind, string[]>;
}

export interface OrderGateway {
  remove?(id: string, signal: AbortSignal): Promise<{ ok: boolean }>;
  upload(
    file: File,
    kind: OrderFileKind,
    signal: AbortSignal,
  ): Promise<{ id: string; name: string }>;
  submit(
    payload: OrderDraft,
    idempotencyKey: string,
    signal: AbortSignal,
  ): Promise<{ orderId: string }>;
}
