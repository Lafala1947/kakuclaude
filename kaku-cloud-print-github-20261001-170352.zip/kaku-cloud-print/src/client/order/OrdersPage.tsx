import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { apiEnabled, apiFileUrl, apiRequest } from "../api/client";
import { useSession } from "../api/SessionContext";
import type { ApiOrder, OrderStatus, PendingFile } from "../../shared/api";
import { money, message } from "../utils";
import AdminSectionNav from "../AdminSectionNav";
import "./orders.css";
import FileReviewPanel from "./FileReviewPanel";
import OrderSpecifications from "./OrderSpecifications";
import {
  getFileReview,
  orderTransitions,
  reviewEditable,
  reviewLabels,
} from "../../shared/file-review";

const statuses: Record<OrderStatus, string> = {
  submitted: "已提交",
  confirmed: "已确认",
  producing: "生产中",
  shipped: "已发货",
  cancelled: "已取消",
};
export default function OrdersPage({
  admin = false,
  reviewsOnly = false,
}: {
  admin?: boolean;
  reviewsOnly?: boolean;
}) {
  const { user, loading: sessionLoading } = useSession();
  const [orders, setOrders] = useState<ApiOrder[]>([]);
  const [pendingFiles, setPendingFiles] = useState<PendingFile[]>([]);
  const [deleteFile, setDeleteFile] = useState<PendingFile | null>(null);
  const [loading, setLoading] = useState(false),
    [error, setError] = useState("");
  const [refresh, setRefresh] = useState(0),
    [pending, setPending] = useState("");
  const [search, setSearch] = useState("");
  const [reviewFilter, setReviewFilter] = useState(
    reviewsOnly ? "pending" : "all",
  );
  const [notice, setNotice] = useState("");
  const updated = (order: ApiOrder) => {
    setOrders((current) =>
      current.map((item) => (item.id === order.id ? order : item)),
    );
    const assigned = new Set(order.files.map((file) => file.id));
    setPendingFiles((current) =>
      current.filter((file) => !assigned.has(file.id)),
    );
  };
  useEffect(() => {
    setOrders([]);
    setPendingFiles([]);
    setDeleteFile(null);
    setError("");
    setNotice("");
    if (
      !apiEnabled ||
      !user ||
      (admin ? user.group !== "sales" : user.role !== "member")
    )
      return;
    const controller = new AbortController();
    setLoading(true);
    apiRequest<{ orders: ApiOrder[] }>("/orders", { signal: controller.signal })
      .then((result) => {
        if (!controller.signal.aborted) setOrders(result.orders);
      })
      .catch((e) => {
        if (!controller.signal.aborted) setError(message(e));
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    if (!admin)
      apiRequest<{ files: PendingFile[] }>("/files", {
        signal: controller.signal,
      })
        .then((result) => {
          if (!controller.signal.aborted) setPendingFiles(result.files ?? []);
        })
        .catch((e) => {
          if (!controller.signal.aborted) setError(message(e));
        });
    return () => controller.abort();
  }, [user?.id, user?.role, user?.group, admin, refresh]);
  async function changeStatus(order: ApiOrder, status: OrderStatus) {
    setPending(order.id);
    setError("");
    try {
      const result = await apiRequest<{ order: ApiOrder }>(
        `/orders/${encodeURIComponent(order.id)}`,
        {
          method: "PATCH",
          body: JSON.stringify({ status }),
        },
      );
      updated(result.order);
      setNotice(`订单状态已更新为${statuses[result.order.status]}。`);
    } catch (e) {
      setError(message(e));
    } finally {
      setPending("");
    }
  }
  async function removePendingFile(file: PendingFile) {
    setPending(file.id);
    setError("");
    try {
      await apiRequest(`/files/${encodeURIComponent(file.id)}`, {
        method: "DELETE",
      });
      setPendingFiles((current) =>
        current.filter((item) => item.id !== file.id),
      );
      setDeleteFile(null);
    } catch (e) {
      setError(message(e));
    } finally {
      setPending("");
    }
  }
  if (!apiEnabled)
    return (
      <section className="admin-access-message">
        <h1>订单查询</h1>
        <p>静态预览版不提交或保存订单，请使用接口版。</p>
        <Link to="/quote">返回报价</Link>
      </section>
    );
  if (sessionLoading) return <p role="status">正在核对登录状态…</p>;
  if (!user)
    return (
      <section className="admin-access-message">
        <h1>请先登录</h1>
        <p>登录后可查看你的订单、报价及文件。</p>
        <Link className="button primary" to="/login">
          会员登录
        </Link>
      </section>
    );
  if (admin ? user.group !== "sales" : user.role !== "member")
    return (
      <section className="admin-access-message">
        <h1>当前账号无权访问此页面</h1>
        <Link to="/admin">返回后台</Link>
      </section>
    );
  const filtered = orders.filter(
    (order) =>
      (reviewFilter === "all" ||
        (getFileReview(order).status === reviewFilter &&
          (!reviewsOnly ||
            reviewFilter !== "pending" ||
            reviewEditable(order)))) &&
      `${order.id} ${order.orderName} ${order.recipient.name} ${order.contact}`
        .toLowerCase()
        .includes(search.toLowerCase()),
  );
  return (
    <section className="orders-page">
      {admin && <AdminSectionNav />}
      <div className="orders-heading">
        <div>
          <span className="admin-kicker">
            卡库云印 / {admin ? "销售组" : "会员中心"}
          </span>
          <h1>
            {reviewsOnly ? "文件审核工作台" : admin ? "订单管理" : "我的订单"}
          </h1>
          <p>
            查看已提交的印刷需求、报价和文件。订单提交后由销售确认生产安排。
          </p>
        </div>
        <button
          className="button secondary"
          disabled={loading || !!pending}
          onClick={() => setRefresh((value) => value + 1)}
        >
          刷新订单
        </button>
      </div>
      {reviewsOnly && (
        <p className="review-workflow-note">
          接单 → 人工核对文件 → 通过或退回补稿 → 订单确认 →
          进入生产。请使用印前软件核对当前文件；通过审核前必须完成全部检查项。
        </p>
      )}
      <label className="orders-search">
        查找订单
        <input
          type="search"
          disabled={!!pending}
          placeholder="订单编号、名称、联系人"
          value={search}
          onChange={(e) => setSearch(e.target.value)}
        />
      </label>
      <label className="review-filters">
        文件审核状态
        <select
          disabled={!!pending}
          aria-label="文件审核状态筛选"
          value={reviewFilter}
          onChange={(e) => setReviewFilter(e.target.value)}
        >
          <option value="all">全部审核状态</option>
          {Object.entries(reviewLabels).map(([value, label]) => (
            <option key={value} value={value}>
              {label}
            </option>
          ))}
        </select>
      </label>
      {error && (
        <p className="reference-error" role="alert">
          {error}
        </p>
      )}
      {notice && (
        <p className="review-workflow-note" role="status">
          {notice}
        </p>
      )}
      {!admin && pendingFiles.length > 0 && (
        <section className="order-record pending-upload-record">
          <h2>未提交的文件（{pendingFiles.length}）</h2>
          <p>
            这些文件已上传，但尚未关联订单。可以下载留存或删除，释放待提交文件额度。
          </p>
          <ul>
            {pendingFiles.map((file) => (
              <li key={file.id}>
                <a href={apiFileUrl(file.id)}>{file.name}</a>
                <span>{(file.size / 1024 / 1024).toFixed(2)} MB</span>
                <button
                  className="button secondary"
                  disabled={!!pending}
                  onClick={() => setDeleteFile(file)}
                >
                  删除 {file.name}
                </button>
              </li>
            ))}
          </ul>
          {deleteFile && (
            <div role="alert">
              <p>确认删除未提交文件“{deleteFile.name}”？如需保留，请先下载。</p>
              <button
                className="button danger"
                disabled={!!pending}
                onClick={() => void removePendingFile(deleteFile)}
              >
                确认删除文件
              </button>
              <button
                className="button secondary"
                disabled={!!pending}
                onClick={() => setDeleteFile(null)}
              >
                取消
              </button>
            </div>
          )}
        </section>
      )}
      {loading ? (
        <p role="status">正在读取订单…</p>
      ) : !filtered.length ? (
        <div className="orders-empty">
          {search ? "没有匹配的订单" : "暂无订单"}
          {!admin && <Link to="/quote">开始定制报价 →</Link>}
        </div>
      ) : (
        <div className="orders-list">
          {filtered.map((order) => (
            <article className="order-record" key={order.id}>
              <header>
                <div>
                  <small>
                    {order.id} ·{" "}
                    {new Date(order.createdAt).toLocaleString("zh-CN")}
                  </small>
                  <h2>
                    {order.orderName || order.quote.product?.name || "定制卡片"}
                  </h2>
                </div>
                <div className="order-record-total">
                  ¥{money(order.quote.total)}
                  <span>{statuses[order.status]}</span>
                </div>
              </header>
              <dl>
                <div>
                  <dt>印刷规格</dt>
                  <dd>
                    {order.quote.input.width} × {order.quote.input.height} mm ·{" "}
                    {order.quote.totalQuantity} 张
                  </dd>
                </div>
                <div>
                  <dt>收货信息</dt>
                  <dd>
                    {order.recipient.name}　{order.recipient.phone}
                    <br />
                    {order.recipient.region} {order.recipient.address}
                  </dd>
                </div>
                <div>
                  <dt>联系方式</dt>
                  <dd>{order.contact}</dd>
                </div>
                <div>
                  <dt>订单备注</dt>
                  <dd>{order.notes || "无"}</dd>
                </div>
              </dl>
              <div className="order-record-files">
                <strong>订单文件</strong>
                {order.files.map((file) => (
                  <a key={file.id} href={apiFileUrl(file.id)}>
                    {
                      { print: "印品", proof: "对稿", certificate: "证书" }[
                        file.kind
                      ]
                    }{" "}
                    · {file.name}
                  </a>
                ))}
              </div>
              <OrderSpecifications quote={order.quote} />
              <FileReviewPanel
                key={`${order.id}-${getFileReview(order).revision}`}
                order={order}
                admin={admin}
                onUpdated={(next) => {
                  updated(next);
                  setNotice(
                    getFileReview(next).status === "pending"
                      ? "新版本已提交，等待文件审核。"
                      : "文件审核结果已保存。",
                  );
                }}
                disabled={!!pending}
                onBusyChange={(busy) => {
                  setPending(busy ? order.id : "");
                  if (busy) setNotice("");
                }}
              />
              {admin && (
                <label className="order-record-status">
                  订单状态
                  <select
                    aria-label={`订单 ${order.id} 状态`}
                    value={order.status}
                    disabled={!!pending}
                    onChange={(e) =>
                      void changeStatus(order, e.target.value as OrderStatus)
                    }
                  >
                    {Object.entries(statuses).map(([value, label]) => (
                      <option
                        value={value}
                        key={value}
                        disabled={
                          value !== order.status &&
                          (!orderTransitions[order.status].includes(
                            value as OrderStatus,
                          ) ||
                            (value === "producing" &&
                              getFileReview(order).status !== "approved"))
                        }
                      >
                        {label}
                      </option>
                    ))}
                  </select>
                  {pending === order.id && <span role="status">正在保存…</span>}
                </label>
              )}
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
