import { useEffect, useRef, useState } from "react";
import { apiFileUrl, apiRequest } from "../api/client";
import { apiOrderGateway } from "./apiGateway";
import {
  addFiles,
  FILE_ACCEPT,
  MAX_FILE_COUNT,
  MAX_TOTAL_BYTES,
  type SelectedOrderFile,
} from "./fileValidation";
import type { ApiOrder, FileCheckId } from "../../shared/api";
import type { OrderFileKind } from "./types";
import {
  fileChecks,
  getFileReview,
  reviewEditable,
  reviewLabels,
} from "../../shared/file-review";
import { message } from "../utils";
import "./file-review.css";

export default function FileReviewPanel({
  order,
  admin,
  onUpdated,
  disabled = false,
  onBusyChange,
}: {
  order: ApiOrder;
  admin: boolean;
  onUpdated: (order: ApiOrder) => void;
  disabled?: boolean;
  onBusyChange?: (busy: boolean) => void;
}) {
  const review = getFileReview(order);
  const [open, setOpen] = useState(false);
  const [checks, setChecks] = useState<FileCheckId[]>([]);
  const [comment, setComment] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState("");
  const [selected, setSelected] = useState<SelectedOrderFile[]>([]);
  const [retained, setRetained] = useState(() =>
    order.files.map((file) => file.id),
  );
  const uploaded = useRef(new Map<string, string>());
  const request = useRef<AbortController | null>(null);
  const pending = useRef(false);
  useEffect(
    () => () => {
      request.current?.abort();
    },
    [],
  );
  const canEdit = reviewEditable(order);
  const failMessage = (e: unknown) =>
    `${message(e)}${(e as { status?: number })?.status === 409 ? "。请刷新订单，核对最新审核状态后再操作。" : ""}`;

  async function decide(decision: "approved" | "rejected") {
    if (pending.current || disabled) return;
    if (
      decision === "approved" &&
      fileChecks.some((check) => !checks.includes(check.id))
    ) {
      setError("通过前请逐项完成全部文件检查。");
      return;
    }
    if (decision === "rejected" && !comment.trim()) {
      setError("请填写明确的退回原因，便于会员修改文件。");
      return;
    }
    const controller = new AbortController();
    request.current = controller;
    pending.current = true;
    setBusy(true);
    onBusyChange?.(true);
    setError("");
    try {
      const result = await apiRequest<{ order: ApiOrder }>(
        `/orders/${encodeURIComponent(order.id)}/file-review`,
        {
          method: "POST",
          signal: controller.signal,
          body: JSON.stringify({
            revision: review.revision,
            decision,
            checks,
            comment: comment.trim(),
          }),
        },
      );
      if (!controller.signal.aborted) {
        onUpdated(result.order);
        setOpen(false);
        setComment("");
        setChecks([]);
      }
    } catch (e) {
      if (!controller.signal.aborted) setError(failMessage(e));
    } finally {
      pending.current = false;
      onBusyChange?.(false);
      if (!controller.signal.aborted) setBusy(false);
    }
  }
  function choose(files: File[], kind: OrderFileKind) {
    const next = addFiles(selected, files, kind);
    setSelected(next.files);
    setError(next.errors.join("；"));
  }
  async function resubmit() {
    if (pending.current || disabled) return;
    const kept = order.files.filter((file) => retained.includes(file.id));
    if (!selected.length && kept.length === order.files.length) {
      setError("请上传修改稿或调整文件清单后再重新送审。");
      return;
    }
    if (
      !kept.some((file) => file.kind === "print") &&
      !selected.some((file) => file.kind === "print")
    ) {
      setError("至少保留或上传一个印品文件。");
      return;
    }
    if (
      kept.length + selected.length > MAX_FILE_COUNT ||
      kept.reduce((sum, file) => sum + file.size, 0) +
        selected.reduce((sum, entry) => sum + entry.file.size, 0) >
        MAX_TOTAL_BYTES
    ) {
      setError("本版文件合计最多 20 个、100 MB，请取消不再使用的旧文件。");
      return;
    }
    const controller = new AbortController();
    request.current = controller;
    pending.current = true;
    setBusy(true);
    onBusyChange?.(true);
    setError("");
    try {
      const files: Record<OrderFileKind, string[]> = {
        print: [],
        proof: [],
        certificate: [],
      };
      kept.forEach((file) => files[file.kind].push(file.id));
      for (const [index, entry] of selected.entries()) {
        setProgress(
          `上传修改稿 ${index + 1}/${selected.length}：${entry.file.name}`,
        );
        let id = uploaded.current.get(entry.key);
        if (!id) {
          const result = await apiOrderGateway.upload(
            entry.file,
            entry.kind,
            controller.signal,
          );
          id = result.id;
          uploaded.current.set(entry.key, id);
        }
        if (controller.signal.aborted) return;
        files[entry.kind].push(id);
      }
      setProgress("正在提交新版本…");
      const result = await apiRequest<{ order: ApiOrder }>(
        `/orders/${encodeURIComponent(order.id)}/files`,
        {
          method: "PUT",
          signal: controller.signal,
          body: JSON.stringify({
            revision: review.revision,
            files,
            comment: comment.trim(),
          }),
        },
      );
      if (!controller.signal.aborted) {
        onUpdated(result.order);
        setOpen(false);
        setSelected([]);
        setComment("");
        uploaded.current.clear();
      }
    } catch (e) {
      if (!controller.signal.aborted) setError(failMessage(e));
    } finally {
      pending.current = false;
      onBusyChange?.(false);
      if (!controller.signal.aborted) {
        setBusy(false);
        setProgress("");
      }
    }
  }
  return (
    <section
      className="file-review-panel"
      aria-label={`订单 ${order.id} 文件审核`}
    >
      <div className="file-review-heading">
        <div>
          <strong>印前文件审核</strong>
          <span className={`file-review-badge ${review.status}`}>
            {reviewLabels[review.status]}
          </span>
          <span className="file-version">文件 V{review.fileVersion}</span>
        </div>
        {canEdit && (admin || review.status === "rejected") && (
          <button
            className="button secondary"
            disabled={busy || disabled}
            onClick={() => {
              setOpen(!open);
              setError("");
            }}
          >
            {open ? "收起" : admin ? "审核文件" : "修改文件并重新送审"}
          </button>
        )}
      </div>
      {review.comment && (
        <p
          className={
            review.status === "rejected"
              ? "file-review-reason"
              : "file-review-comment"
          }
        >
          <strong>
            {review.status === "rejected" ? "退回原因：" : "审核备注："}
          </strong>
          {review.comment}
        </p>
      )}
      {review.reviewedAt && (
        <p className="file-review-meta">
          {review.reviewer?.name} ·{" "}
          {new Date(review.reviewedAt).toLocaleString("zh-CN")}
        </p>
      )}
      {review.status === "pending" && (
        <p className="file-review-meta">
          文件等待人工核对。审核通过并确认订单后，才能开始生产。
        </p>
      )}
      {!canEdit && (
        <p className="file-review-meta">当前订单状态已锁定文件与审核记录。</p>
      )}
      {open && canEdit && (
        <fieldset className="file-review-form" disabled={busy || disabled}>
          {admin ? (
            <>
              <p className="file-review-note">
                请先下载当前版本文件，在印前软件中核对。这里记录人工审核结果，不会自动检测尺寸、出血、色彩或字体。
              </p>
              <div className="file-checklist">
                {fileChecks.map((check) => (
                  <label key={check.id}>
                    <input
                      type="checkbox"
                      checked={checks.includes(check.id)}
                      onChange={(e) =>
                        setChecks((current) =>
                          e.target.checked
                            ? [...current, check.id]
                            : current.filter((id) => id !== check.id),
                        )
                      }
                    />
                    <span>
                      <strong>{check.label}</strong>
                      <small>{check.hint}</small>
                    </span>
                  </label>
                ))}
              </div>
            </>
          ) : (
            <>
              <p className="file-review-note">
                取消勾选要替换的旧文件，再上传修改稿。历史版本会保留；订单规格和报价保持不变。如需改变尺寸或工艺，请联系销售重新报价。
              </p>
              <div className="retained-files">
                {order.files.map((file) => (
                  <label key={file.id}>
                    <input
                      type="checkbox"
                      checked={retained.includes(file.id)}
                      onChange={(e) =>
                        setRetained((current) =>
                          e.target.checked
                            ? [...current, file.id]
                            : current.filter((id) => id !== file.id),
                        )
                      }
                    />
                    保留 {file.name}
                  </label>
                ))}
              </div>
              <div className="replacement-files">
                {(["print", "proof", "certificate"] as const).map((kind) => (
                  <label key={kind}>
                    {
                      {
                        print: "上传修改后的印品文件",
                        proof: "上传修改后的工艺对稿图",
                        certificate: "补充授权证书",
                      }[kind]
                    }
                    <input
                      type="file"
                      multiple
                      accept={FILE_ACCEPT}
                      onChange={(e) => {
                        choose(Array.from(e.target.files ?? []), kind);
                        e.target.value = "";
                      }}
                    />
                  </label>
                ))}
              </div>
              {selected.length > 0 && (
                <ul className="replacement-list">
                  {selected.map((entry) => (
                    <li key={entry.key}>
                      <span>
                        {entry.file.name} ·{" "}
                        {(entry.file.size / 1024 / 1024).toFixed(2)} MB
                      </span>
                      <button
                        type="button"
                        onClick={() =>
                          setSelected((current) =>
                            current.filter((file) => file.key !== entry.key),
                          )
                        }
                      >
                        移除
                      </button>
                    </li>
                  ))}
                </ul>
              )}
            </>
          )}
          <label className="file-review-comment-label">
            {admin ? "审核意见 / 退回原因" : "修改说明"}
            <textarea
              maxLength={3000}
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              placeholder={
                admin
                  ? "意见对会员可见；请说明需要修改的文件、页面和问题，退回时必填。"
                  : "说明修改了哪些内容，便于重新核对。"
              }
            />
          </label>
          <div className="file-review-actions">
            {admin ? (
              <>
                <button
                  type="button"
                  className="button primary"
                  onClick={() => void decide("approved")}
                >
                  确认审核通过
                </button>
                <button
                  type="button"
                  className="button danger"
                  onClick={() => void decide("rejected")}
                >
                  退回修改
                </button>
              </>
            ) : (
              <button
                type="button"
                className="button primary"
                onClick={() => void resubmit()}
              >
                提交新版本送审
              </button>
            )}
            {busy && <span role="status">{progress || "正在保存审核…"}</span>}
          </div>
        </fieldset>
      )}
      {error && (
        <p role="alert" className="reference-error">
          {error}
        </p>
      )}
      {review.history.length > 0 && (
        <details className="file-review-history">
          <summary>审核与文件版本记录（{review.history.length}）</summary>
          <ol>
            {[...review.history].reverse().map((event) => (
              <li key={event.id}>
                <strong>
                  V{event.fileVersion} ·{" "}
                  {event.action === "resubmitted"
                    ? "重新送审"
                    : reviewLabels[event.action]}
                </strong>
                <span>
                  {event.actor.name} ·{" "}
                  {new Date(event.createdAt).toLocaleString("zh-CN")}
                </span>
                {event.comment && <p>{event.comment}</p>}
                {event.checks.length > 0 && (
                  <p>
                    已核对：
                    {fileChecks
                      .filter((check) => event.checks.includes(check.id))
                      .map((check) => check.label)
                      .join("、")}
                  </p>
                )}
                <div>
                  {event.files.map((file) => (
                    <a key={file.id} href={apiFileUrl(file.id)}>
                      {file.name}
                    </a>
                  ))}
                </div>
              </li>
            ))}
          </ol>
        </details>
      )}
    </section>
  );
}
