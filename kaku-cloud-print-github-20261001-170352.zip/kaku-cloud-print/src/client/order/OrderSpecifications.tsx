import type { ServerQuote } from "../../shared/api";
import type { AdminQuote } from "../../shared/contracts";
import { extraNames } from "../../shared/catalog";

const craftNames = {
  foil: "热烫",
  texture: "压纹",
  emboss: "击凸",
  deboss: "压凹",
};
export default function OrderSpecifications({
  quote,
}: {
  quote: ServerQuote | AdminQuote;
}) {
  const input = quote.input;
  const crafts = [
    ...(input.crafts ?? []).map((id) => craftNames[id]),
    ...(input.extras ?? []).map((id) => extraNames[id]),
  ];
  const details = [
    input.extras?.includes("circle")
      ? `圆形直径 ${input.circleDiameter} mm`
      : "",
    input.crafts?.includes("foil") ? `每张烫金面积 ${input.foilArea} cm²` : "",
  ].filter(Boolean);
  return (
    <details className="order-specifications" open>
      <summary>下单规格与工艺 · 费用表版本 {quote.version ?? "未记录"}</summary>
      <dl>
        <div>
          <dt>纸张材料</dt>
          <dd>
            {quote.materialSnapshot
              ? `${quote.materialSnapshot.name} · ${quote.materialSnapshot.gsm} g/㎡`
              : `材料编码 ${input.material ?? "未记录"}：历史订单未记录纸张名称和克重，请按原费用表版本核对。`}
          </dd>
        </div>
        <div>
          <dt>数量与款数</dt>
          <dd>
            {input.quantity ?? "未记录"} 张 / 款 × {input.variants ?? "未记录"}{" "}
            款
          </dd>
        </div>
        <div>
          <dt>印刷要求</dt>
          <dd>
            {input.sides === 2
              ? "双面"
              : input.sides === 1
                ? "单面"
                : "面数未记录"}{" "}
            ·{" "}
            {input.ink === "spot"
              ? "四色加 1 专色"
              : input.ink === "cmyk"
                ? "CMYK 彩色"
                : "印色未记录"}
          </dd>
        </div>
        <div>
          <dt>裁切与覆膜</dt>
          <dd>
            {input.cutting === "die"
              ? "模切"
              : input.cutting === "straight"
                ? "直切"
                : "裁切未记录"}{" "}
            ·{" "}
            {input.lamination === 2
              ? "双面覆膜"
              : input.lamination === 1
                ? "单面覆膜"
                : input.lamination === 0
                  ? "无覆膜"
                  : "覆膜未记录"}
          </dd>
        </div>
        <div>
          <dt>后道工艺</dt>
          <dd>
            {crafts.join("、") || "无附加工艺"}
            {details.length > 0 && <p>{details.join(" · ")}</p>}
          </dd>
        </div>
        <div>
          <dt>设计服务</dt>
          <dd>
            {{
              provided: "自备设计文件",
              adjust: "文件调整",
              custom: "定制设计",
            }[input.design] ?? "未记录"}
          </dd>
        </div>
      </dl>
    </details>
  );
}
