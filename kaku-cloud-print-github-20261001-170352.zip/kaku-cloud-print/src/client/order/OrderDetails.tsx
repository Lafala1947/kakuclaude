import { useEffect, useRef, useState } from "react";
import type { ChangeEvent, DragEvent, ReactNode } from "react";
import type { AdminQuote } from "../../shared/contracts";
import {
  addFiles,
  FILE_ACCEPT,
  type SelectedOrderFile,
} from "./fileValidation";
import type {
  OrderDraft,
  OrderFileKind,
  OrderGateway,
  OrderRecipient,
} from "./types";
import "./order.css";

export type {
  OrderGateway,
  OrderDraft,
  OrderFileKind,
  OrderRecipient,
} from "./types";

type DeliveryPatch = {
  shipping?: "pickup" | "express";
  region?: "local" | "national" | "remote";
};

interface Props {
  quote: AdminQuote | null;
  shipping: "pickup" | "express";
  region: "local" | "national" | "remote";
  logisticsEnabled: boolean;
  onDeliveryChange: (patch: DeliveryPatch) => void;
  onPendingChange?: (pending: boolean) => void;
  gateway?: OrderGateway;
  unavailableMessage?: string;
  addressStorageKey?: string | null;
}

const STORAGE_KEY = "insert-card-common-addresses-v1";
const emptyRecipient: OrderRecipient = {
  name: "",
  phone: "",
  region: "",
  address: "",
  company: "",
};

function savedAddresses(
  storageKey: string | null = STORAGE_KEY,
): OrderRecipient[] {
  if (!storageKey) return [];
  try {
    const value: unknown = JSON.parse(localStorage.getItem(storageKey) ?? "[]");
    if (!Array.isArray(value)) return [];
    return value.filter(
      (address): address is OrderRecipient =>
        typeof address === "object" &&
        address !== null &&
        typeof address.name === "string" &&
        typeof address.phone === "string" &&
        typeof address.region === "string" &&
        typeof address.address === "string",
    );
  } catch {
    return [];
  }
}

function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="order-row">
      <div className="order-row-label">{label}</div>
      <div className="order-row-body">{children}</div>
    </div>
  );
}

function Section({ title, children }: { title: string; children: ReactNode }) {
  return (
    <section className="order-section">
      <h2 className="order-section-title">
        <span aria-hidden="true" />
        {title}
      </h2>
      <div className="order-section-rows">{children}</div>
    </section>
  );
}

function newIdempotencyKey(): string {
  if (typeof crypto !== "undefined" && "randomUUID" in crypto)
    return crypto.randomUUID();
  return `${Date.now()}-${Math.random().toString(36).slice(2)}`;
}

function errorText(error: unknown): string {
  return error instanceof Error ? error.message : "请求失败，请稍后重试";
}

function semanticQuote(quote: AdminQuote | null) {
  return quote ? { ...quote, createdAt: null } : null;
}

export default function OrderDetails({
  quote,
  shipping,
  region,
  logisticsEnabled,
  onDeliveryChange,
  onPendingChange,
  gateway,
  unavailableMessage,
  addressStorageKey = STORAGE_KEY,
}: Props) {
  const [recipient, setRecipient] = useState<OrderRecipient>(emptyRecipient);
  const [editingRecipient, setEditingRecipient] =
    useState<OrderRecipient | null>(null);
  const [addressPickerOpen, setAddressPickerOpen] = useState(false);
  const [addresses, setAddresses] = useState(() =>
    savedAddresses(addressStorageKey),
  );
  const [contact, setContact] = useState("");
  const [orderName, setOrderName] = useState("");
  const [notes, setNotes] = useState("");
  const [files, setFiles] = useState<SelectedOrderFile[]>([]);
  const [fileError, setFileError] = useState("");
  const [orderError, setOrderError] = useState("");
  const [progress, setProgress] = useState("");
  const [orderId, setOrderId] = useState("");
  const [pending, setPending] = useState(false);
  const requestRef = useRef<AbortController | null>(null);
  const submittingRef = useRef(false);
  const retryRef = useRef<{
    signature: string;
    key: string;
    draftBase: Omit<OrderDraft, "files">;
    uploaded: Map<string, string>;
  } | null>(null);
  const deliveryQuoteSignature = JSON.stringify({
    quote: semanticQuote(quote),
    shipping,
    region,
  });
  const previousQuoteRef = useRef(deliveryQuoteSignature);

  useEffect(() => () => requestRef.current?.abort(), []);
  useEffect(() => {
    if (previousQuoteRef.current !== deliveryQuoteSignature) {
      setOrderId("");
      setOrderError("");
    }
    previousQuoteRef.current = deliveryQuoteSignature;
  }, [deliveryQuoteSignature]);

  const invalidateResult = () => {
    setOrderError("");
    setOrderId("");
  };

  async function removeFiles(selected: SelectedOrderFile[]) {
    if (pending || submittingRef.current) return;
    const controller = new AbortController();
    requestRef.current = controller;
    submittingRef.current = true;
    setPending(true);
    onPendingChange?.(true);
    setFileError("");
    try {
      if (gateway?.remove && !orderId) {
        for (const item of selected) {
          const id = retryRef.current?.uploaded.get(item.key);
          if (id) {
            await gateway.remove(id, controller.signal);
            if (controller.signal.aborted) return;
            retryRef.current?.uploaded.delete(item.key);
          }
        }
      }
      const keys = new Set(selected.map((item) => item.key));
      setFiles((current) => current.filter((item) => !keys.has(item.key)));
      invalidateResult();
    } catch (error) {
      if (!controller.signal.aborted)
        setFileError(
          `文件未移除：${errorText(error)}。如订单可能已提交，请先查看我的订单。`,
        );
    } finally {
      requestRef.current = null;
      submittingRef.current = false;
      setPending(false);
      onPendingChange?.(false);
    }
  }

  const addSelected = (incoming: File[], kind: OrderFileKind) => {
    if (pending) return;
    const result = addFiles(files, incoming, kind);
    setFiles(result.files);
    setFileError(result.errors.join("；"));
    if (result.files.length !== files.length) invalidateResult();
  };

  const chooseFiles = (
    event: ChangeEvent<HTMLInputElement>,
    kind: OrderFileKind,
  ) => {
    addSelected(Array.from(event.target.files ?? []), kind);
    event.target.value = "";
  };

  const dropFiles = (
    event: DragEvent<HTMLLabelElement>,
    kind: OrderFileKind,
  ) => {
    event.preventDefault();
    addSelected(Array.from(event.dataTransfer.files), kind);
  };

  const validateRecipient = (value: OrderRecipient): string => {
    if (!value.name.trim()) return "请填写收货人姓名";
    if (!/^\+?[\d\s()-]{6,20}$/.test(value.phone.trim()))
      return "请填写有效联系电话";
    if (shipping === "express" && !value.region.trim()) return "请填写收货地区";
    if (shipping === "express" && !value.address.trim())
      return "请填写详细地址";
    return "";
  };

  const useAddress = (save: boolean) => {
    if (!editingRecipient) return;
    const error = validateRecipient(editingRecipient);
    if (error) {
      setOrderError(error);
      return;
    }
    const clean: OrderRecipient = {
      name: editingRecipient.name.trim(),
      phone: editingRecipient.phone.trim(),
      region: editingRecipient.region.trim(),
      address: editingRecipient.address.trim(),
      company: editingRecipient.company?.trim() ?? "",
    };
    let saveError = "";
    if (save) {
      const next = [
        ...addresses.filter(
          (item) => JSON.stringify(item) !== JSON.stringify(clean),
        ),
        clean,
      ];
      try {
        if (addressStorageKey)
          localStorage.setItem(addressStorageKey, JSON.stringify(next));
        setAddresses(next);
      } catch {
        saveError = "浏览器未能保存常用地址；本次地址仍可使用";
      }
    }
    setRecipient(clean);
    setEditingRecipient(null);
    invalidateResult();
    if (saveError) setOrderError(saveError);
  };

  const filePicker = (kind: OrderFileKind, multiple = true) => {
    const selected = files.filter((item) => item.kind === kind);
    return (
      <div className="order-file-group">
        <label
          className="order-dropzone"
          onDragOver={(event) => event.preventDefault()}
          onDrop={(event) => dropFiles(event, kind)}
        >
          <input
            aria-label={
              kind === "print"
                ? "选择印品文件"
                : kind === "proof"
                  ? "选择工艺对稿图"
                  : "选择授权证书"
            }
            type="file"
            accept={FILE_ACCEPT}
            multiple={multiple}
            disabled={pending}
            onChange={(event) => chooseFiles(event, kind)}
          />
          <span className="order-upload-icon" aria-hidden="true">
            ↑
          </span>
          <span>点击选择或拖放文件至此</span>
          <small>PDF、AI、CDR、EPS、PSD、PNG、JPG、TIFF、ZIP</small>
        </label>
        {selected.length > 0 && (
          <ul className="order-files">
            {selected.map((item) => (
              <li key={item.key}>
                <span title={item.file.name}>{item.file.name}</span>
                <small>
                  {(item.file.size / 1024 / 1024).toFixed(2)} MB ·{" "}
                  {retryRef.current?.uploaded.has(item.key)
                    ? "已上传"
                    : "已选择，尚未上传"}
                </small>
                <button
                  type="button"
                  aria-label={`移除 ${item.file.name}`}
                  disabled={pending}
                  onClick={() => void removeFiles([item])}
                >
                  移除
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    );
  };

  const submitOrder = async () => {
    if (!gateway || pending || submittingRef.current || orderId) return;
    setOrderError("");
    if (
      !quote ||
      quote.input.shipping !== shipping ||
      quote.input.region !== region
    ) {
      setOrderError("报价已变化，请确认当前规格与价格后重试");
      return;
    }
    if (shipping === "express" && !logisticsEnabled) {
      setOrderError("当前报价未开放快递配送");
      return;
    }
    const recipientError = validateRecipient(recipient);
    if (recipientError) {
      setOrderError(recipientError);
      return;
    }
    if (!contact.trim()) {
      setOrderError("请填写联系方式");
      return;
    }
    if (!files.some((item) => item.kind === "print")) {
      setOrderError("请先选择印品文件");
      return;
    }

    const draftBase: Omit<OrderDraft, "files"> = {
      quote,
      recipient: { ...recipient },
      contact: contact.trim(),
      orderName: orderName.trim(),
      notes: notes.trim(),
    };
    const signature = JSON.stringify({
      ...draftBase,
      quote: semanticQuote(quote),
      files: files.map((item) => item.key),
    });
    const retry =
      retryRef.current?.signature === signature
        ? retryRef.current
        : {
            signature,
            key: newIdempotencyKey(),
            draftBase,
            uploaded: retryRef.current?.uploaded ?? new Map<string, string>(),
          };
    retryRef.current = retry;
    const controller = new AbortController();
    requestRef.current = controller;
    submittingRef.current = true;
    setPending(true);
    onPendingChange?.(true);
    try {
      const ids: OrderDraft["files"] = {
        print: [],
        proof: [],
        certificate: [],
      };
      for (const [index, item] of files.entries()) {
        setProgress(
          `正在上传文件 ${index + 1}/${files.length}：${item.file.name}`,
        );
        let id = retry.uploaded.get(item.key);
        if (!id) {
          const uploaded = await gateway.upload(
            item.file,
            item.kind,
            controller.signal,
          );
          if (controller.signal.aborted) return;
          if (!uploaded.id)
            throw new Error(`${item.file.name} 上传后未返回文件编号`);
          id = uploaded.id;
          retry.uploaded.set(item.key, id);
        }
        ids[item.kind].push(id);
      }
      if (controller.signal.aborted) return;
      setProgress("正在提交订单…");
      const result = await gateway.submit(
        {
          ...retry.draftBase,
          files: ids,
        },
        retry.key,
        controller.signal,
      );
      if (controller.signal.aborted) return;
      if (!result.orderId) throw new Error("订单接口未返回订单编号");
      setOrderId(result.orderId);
      setProgress("");
    } catch (error) {
      if (!controller.signal.aborted) {
        setProgress("");
        setOrderError(`提交失败：${errorText(error)}`);
      }
    } finally {
      requestRef.current = null;
      submittingRef.current = false;
      setPending(false);
      onPendingChange?.(false);
    }
  };

  return (
    <div className="order-details" aria-busy={pending}>
      <Section title="交货信息">
        <Row label="收货方式">
          <div className="order-choice-row">
            <button
              type="button"
              className={
                shipping === "pickup" ? "order-choice active" : "order-choice"
              }
              aria-pressed={shipping === "pickup"}
              disabled={pending}
              onClick={() => {
                onDeliveryChange({ shipping: "pickup" });
                invalidateResult();
              }}
            >
              到店自提
            </button>
            <button
              type="button"
              className={
                shipping === "express" ? "order-choice active" : "order-choice"
              }
              aria-pressed={shipping === "express"}
              disabled={pending || !logisticsEnabled}
              onClick={() => {
                onDeliveryChange({ shipping: "express" });
                invalidateResult();
              }}
            >
              快递配送
            </button>
            {!logisticsEnabled && (
              <small className="order-muted">当前未开放快递报价</small>
            )}
          </div>
          {shipping === "express" && (
            <label className="order-inline-field">
              配送区域
              <select
                aria-label="配送区域"
                value={region}
                disabled={pending}
                onChange={(event) => {
                  onDeliveryChange({
                    region: event.target.value as Props["region"],
                  });
                  invalidateResult();
                }}
              >
                <option value="local">同城</option>
                <option value="national">全国</option>
                <option value="remote">偏远地区</option>
              </select>
            </label>
          )}
        </Row>
        <Row label="收货人信息">
          <div className="order-recipient-actions">
            <button
              type="button"
              className="order-primary-outline"
              disabled={pending}
              onClick={() => {
                setEditingRecipient({ ...emptyRecipient });
                setOrderError("");
              }}
            >
              ＋ 新增地址
            </button>
            <button
              type="button"
              className="order-link"
              disabled={pending}
              onClick={() => setAddressPickerOpen(true)}
            >
              常用地址
            </button>
          </div>
          {recipient.name ? (
            <div className="order-address-card">
              <strong>{recipient.name}</strong>
              <span>{recipient.phone}</span>
              <span>
                {[recipient.region, recipient.address]
                  .filter(Boolean)
                  .join(" ") || "到店自提"}
              </span>
              {recipient.company && <small>{recipient.company}</small>}
              <button
                type="button"
                disabled={pending}
                onClick={() => {
                  setEditingRecipient({ ...recipient });
                  setOrderError("");
                }}
              >
                编辑
              </button>
            </div>
          ) : (
            <p className="order-muted">尚未填写收货人信息</p>
          )}
        </Row>
      </Section>

      <Section title="上传文件">
        <Row label="联系方式">
          <input
            className="order-text-input"
            aria-label="联系方式"
            value={contact}
            disabled={pending}
            onChange={(event) => {
              setContact(event.target.value);
              invalidateResult();
            }}
            placeholder="请填写便于联系的电话或邮箱"
          />
        </Row>
        <Row label="订单名称">
          <input
            className="order-text-input"
            aria-label="订单名称"
            value={orderName}
            disabled={pending}
            onChange={(event) => {
              setOrderName(event.target.value);
              invalidateResult();
            }}
            placeholder="选填，方便查找此订单"
          />
        </Row>
        <Row label="授权证书">{filePicker("certificate", false)}</Row>
        <Row label="印品文件">{filePicker("print")}</Row>
        <Row label="工艺对稿图">{filePicker("proof")}</Row>
        <Row label="订单备注">
          <textarea
            className="order-text-input order-notes"
            aria-label="订单备注"
            value={notes}
            disabled={pending}
            onChange={(event) => {
              setNotes(event.target.value);
              invalidateResult();
            }}
            placeholder="选填，说明需要注意的制作要求"
          />
        </Row>
      </Section>

      <div className="order-submit-bar">
        <div>
          <p className="order-muted">
            最多 20 个文件，总计不超过 100 MB。文件仅在提交订单时上传。
          </p>
          {files.length > 0 && (
            <button
              className="order-link"
              type="button"
              disabled={pending}
              onClick={() => void removeFiles(files)}
            >
              清空已选文件（{files.length}）
            </button>
          )}
          {fileError && (
            <p role="alert" className="order-error">
              {fileError}
            </p>
          )}
          {orderError && (
            <p role="alert" className="order-error">
              {orderError}
            </p>
          )}
          {progress && (
            <p role="status" className="order-progress">
              {progress}
            </p>
          )}
          {orderId && (
            <p role="status" className="order-success">
              订单已提交，编号：{orderId}
            </p>
          )}
          {!gateway && (
            <p className="order-muted">
              {unavailableMessage ??
                "上传与订单接口尚未配置，当前仅选择文件，不会提交订单"}
            </p>
          )}
        </div>
        <button
          className="order-submit-button"
          type="button"
          disabled={!gateway || pending || Boolean(orderId)}
          onClick={submitOrder}
        >
          {pending ? "提交中…" : "立即下单"}
        </button>
      </div>

      {editingRecipient && (
        <div
          className="order-modal-backdrop"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) setEditingRecipient(null);
          }}
        >
          <div
            className="order-modal"
            role="dialog"
            aria-modal="true"
            aria-label="编辑收货人信息"
          >
            <h3>收货人信息</h3>
            <div className="order-modal-fields">
              <label>
                收货人
                <input
                  aria-label="收货人"
                  autoFocus
                  value={editingRecipient.name}
                  onChange={(event) =>
                    setEditingRecipient({
                      ...editingRecipient,
                      name: event.target.value,
                    })
                  }
                />
              </label>
              <label>
                联系电话
                <input
                  aria-label="联系电话"
                  value={editingRecipient.phone}
                  onChange={(event) =>
                    setEditingRecipient({
                      ...editingRecipient,
                      phone: event.target.value,
                    })
                  }
                />
              </label>
              <label>
                地区
                <input
                  aria-label="收货地区"
                  value={editingRecipient.region}
                  onChange={(event) =>
                    setEditingRecipient({
                      ...editingRecipient,
                      region: event.target.value,
                    })
                  }
                  placeholder={
                    shipping === "pickup" ? "自提可留空" : "省 / 市 / 区"
                  }
                />
              </label>
              <label>
                详细地址
                <input
                  aria-label="详细地址"
                  value={editingRecipient.address}
                  onChange={(event) =>
                    setEditingRecipient({
                      ...editingRecipient,
                      address: event.target.value,
                    })
                  }
                  placeholder={
                    shipping === "pickup" ? "自提可留空" : "街道、门牌号"
                  }
                />
              </label>
              <label>
                公司（选填）
                <input
                  aria-label="公司"
                  value={editingRecipient.company ?? ""}
                  onChange={(event) =>
                    setEditingRecipient({
                      ...editingRecipient,
                      company: event.target.value,
                    })
                  }
                />
              </label>
            </div>
            {orderError && (
              <p role="alert" className="order-error">
                {orderError}
              </p>
            )}
            <p className="order-muted">
              “保存为常用地址”会将此地址保存在当前浏览器中。
            </p>
            <div className="order-modal-actions">
              <button type="button" onClick={() => setEditingRecipient(null)}>
                取消
              </button>
              <button type="button" onClick={() => useAddress(false)}>
                使用此地址
              </button>
              <button
                type="button"
                className="order-save-address"
                onClick={() => useAddress(true)}
              >
                保存为常用地址
              </button>
            </div>
          </div>
        </div>
      )}

      {addressPickerOpen && (
        <div
          className="order-modal-backdrop"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget)
              setAddressPickerOpen(false);
          }}
        >
          <div
            className="order-modal"
            role="dialog"
            aria-modal="true"
            aria-label="常用地址"
          >
            <h3>常用地址</h3>
            {addresses.length ? (
              addresses.map((address, index) => (
                <button
                  className="order-saved-address"
                  key={`${address.name}-${address.phone}-${index}`}
                  type="button"
                  onClick={() => {
                    setRecipient({ ...address });
                    setAddressPickerOpen(false);
                    invalidateResult();
                  }}
                >
                  <strong>
                    {address.name}　{address.phone}
                  </strong>
                  <span>
                    {address.region} {address.address}
                  </span>
                </button>
              ))
            ) : (
              <p className="order-muted">当前浏览器还没有保存的常用地址</p>
            )}
            <div className="order-modal-actions">
              <button type="button" onClick={() => setAddressPickerOpen(false)}>
                关闭
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
