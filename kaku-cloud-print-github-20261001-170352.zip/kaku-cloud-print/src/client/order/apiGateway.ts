import { apiRequest } from "../api/client";
import type { OrderGateway } from "./types";

export const apiOrderGateway: OrderGateway = {
  remove(id, signal) {
    return apiRequest(`/files/${encodeURIComponent(id)}`, {
      method: "DELETE",
      signal,
    });
  },
  upload(file, kind, signal) {
    return apiRequest(
      `/files?kind=${kind}&name=${encodeURIComponent(file.name)}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/octet-stream" },
        body: file,
        signal,
      },
    );
  },
  async submit(payload, idempotencyKey, signal) {
    if (!payload.quote.quoteId)
      throw new Error("请先重新算价，获取服务器报价后再提交订单");
    const { quote, ...details } = payload;
    return apiRequest("/orders", {
      method: "POST",
      signal,
      headers: { "Idempotency-Key": idempotencyKey },
      body: JSON.stringify({ ...details, quoteId: quote.quoteId }),
    });
  },
};
