import type { OrderFileKind } from "./types";

export const FILE_ACCEPT =
  ".pdf,.ai,.cdr,.eps,.psd,.png,.jpg,.jpeg,.tif,.tiff,.zip";
export const MAX_FILE_COUNT = 20;
export const MAX_TOTAL_BYTES = 100 * 1024 * 1024;

const acceptedExtensions = new Set(FILE_ACCEPT.split(","));

export interface SelectedOrderFile {
  key: string;
  file: File;
  kind: OrderFileKind;
}

export function fileKey(file: File, kind: OrderFileKind): string {
  return `${kind}\u0000${file.name}\u0000${file.size}\u0000${file.lastModified}\u0000${file.type}`;
}

export function addFiles(
  existing: SelectedOrderFile[],
  incoming: File[],
  kind: OrderFileKind,
): { files: SelectedOrderFile[]; errors: string[] } {
  const next = [...existing];
  const errors: string[] = [];
  const known = new Set(next.map((entry) => entry.key));
  let bytes = next.reduce((sum, entry) => sum + entry.file.size, 0);
  for (const file of incoming) {
    const extension = `.${file.name.split(".").pop()?.toLowerCase() ?? ""}`;
    if (!acceptedExtensions.has(extension)) {
      errors.push(`${file.name}：文件格式不支持`);
      continue;
    }
    const key = fileKey(file, kind);
    if (known.has(key)) continue;
    if (next.length >= MAX_FILE_COUNT) {
      errors.push("最多可选择 20 个文件");
      break;
    }
    if (bytes + file.size > MAX_TOTAL_BYTES) {
      errors.push(`${file.name}：文件总大小不能超过 100 MB`);
      continue;
    }
    known.add(key);
    bytes += file.size;
    next.push({ key, file, kind });
  }
  return { files: next, errors };
}
