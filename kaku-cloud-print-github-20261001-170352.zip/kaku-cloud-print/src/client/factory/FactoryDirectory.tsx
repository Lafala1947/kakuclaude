import { useEffect, useState } from 'react';
import { Link, useParams, useSearchParams } from 'react-router-dom';
import { ArrowRight, Factory, MapPin, SlidersHorizontal, Map, List } from 'lucide-react';
import FactoryMap from './FactoryMap';
import { factoryMaterials, factoryCrafts, matchesFactory, parseFactoryDirectory, type FactoryDirectoryDocument, type FactorySearch } from '../../shared/factories';
import './factory-directory.css';

function readSearch(params: URLSearchParams): FactorySearch {
  return { province: params.get('province') || '', city: params.get('city') || '', district: params.get('district') || '', material: params.get('material') || '', crafts: params.getAll('craft') };
}
function searchParams(query: FactorySearch) {
  const params = new URLSearchParams({ province: query.province.trim(), city: query.city.trim(), district: query.district.trim(), material: query.material });
  query.crafts.forEach(c => params.append('craft', c));
  return params;
}
export default function FactoryDirectory() {
  const { factoryId } = useParams();
  const [params, setParams] = useSearchParams();
  const [draft, setDraft] = useState<FactorySearch>(() => readSearch(params));
  const [data, setData] = useState<FactoryDirectoryDocument | null>(null);
  const [error, setError] = useState('');
  const [retry, setRetry] = useState(0);
  const view = params.get('view') === 'list' ? 'list' : 'map';
  function changeView(next: 'map' | 'list') {
    const query = new URLSearchParams(params);
    query.set('view', next);
    setParams(query, { replace: true });
  }
  const filterKey = JSON.stringify(readSearch(params));
  useEffect(() => { setDraft(JSON.parse(filterKey) as FactorySearch); }, [filterKey]);
  useEffect(() => {
    const controller = new AbortController();
    setData(null); setError('');
    void fetch(`${import.meta.env.BASE_URL}factories.json`, { cache: 'no-store', signal: controller.signal })
      .then(async res => { if (!res.ok) throw new Error('印厂资料暂时无法读取，请稍后重试。'); return parseFactoryDirectory(await res.text()); })
      .then(value => { if (!controller.signal.aborted) setData(value); })
      .catch(() => { if (!controller.signal.aborted) setError('印厂资料暂时无法读取，请稍后重试。'); });
    return () => controller.abort();
  }, [retry]);
  const submitted = readSearch(params);
  const searched = !!(submitted.province && submitted.city && submitted.district && submitted.material);
  const active = data?.factories.filter(f => f.active) || [];
  const matches = searched ? active.filter(f => matchesFactory(f, submitted)) : [];
  const selected = active.find(f => f.id === factoryId);
  const back = `/factories${params.size ? `?${params}` : ''}`;
  return <div className="factory-directory">
    <header className="directory-heading"><div><span className="admin-kicker">KAKU / PRINT NEAR YOU</span><h1>{factoryId && selected ? selected.name : '在需要的地方，找到合适的印厂'}</h1><p>告诉我们印刷品在哪里使用、需要怎样制作，再选择能承接的印厂。</p></div><div className="directory-launch"><Factory size={25} /><span>首期接入计划<strong>6–10 家印厂 / 设备</strong></span></div></header>
    <ol className="directory-steps" aria-label="选厂下单流程"><li className={!factoryId ? 'current' : ''}>使用地址与需求</li><li className={factoryId ? 'current' : ''}>选择承接印厂</li><li>报价与下单<span>待接入</span></li><li>生产与配送<span>待接入</span></li></ol>
    {error ? <div className="directory-empty"><p role="alert">{error}</p><button className="button secondary" onClick={() => setRetry(n => n + 1)}>重新加载</button></div> : !data ? <p role="status">正在读取印厂资料…</p> : factoryId ? selected ? <>
      <Link className="directory-back" to={back}>← 返回匹配结果</Link>
      <section className="directory-detail"><div><span className="directory-type">{selected.kind === 'equipment' ? '印刷设备' : '印刷厂'}</span><h2>生产与服务能力</h2><p>{selected.description}</p><dl><dt>承接主体</dt><dd>{selected.operator}</dd><dt>生产地址</dt><dd>{selected.address}</dd><dt>服务区域</dt><dd>{selected.regions.map(r => `${r.province} / ${r.city} / ${r.district === '*' ? '全市' : r.district}`).join('；')}</dd><dt>支持材质</dt><dd>{selected.materials.map(m => factoryMaterials[m]).join('、')}</dd><dt>支持工艺</dt><dd>{selected.crafts.map(c => factoryCrafts[c]).join('、') || '未登记附加工艺'}</dd><dt>生产设备</dt><dd>{selected.equipment.join('、') || '待补充'}</dd></dl></div><aside><MapPin size={24} /><h2>本次使用地区</h2><p>{searched ? `${submitted.province} / ${submitted.city} / ${submitted.district}` : '尚未填写'}</p>{searched && <p>{factoryMaterials[submitted.material as keyof typeof factoryMaterials] || '材质未识别'} · {submitted.crafts.map(c => factoryCrafts[c as keyof typeof factoryCrafts]).filter(Boolean).join('、') || '无指定附加工艺'}</p>}{searched && !matchesFactory(selected, submitted) && <p role="alert">此印厂不符合当前筛选条件，请返回重新选择。</p>}<button className="button primary" disabled>该印厂报价下单待开通</button><p className="directory-help">完成印厂入驻、独立报价与订单归属接入后，在这里继续下单。当前选择不会生成订单。</p></aside></section>
    </> : <section className="directory-empty"><h2>该印厂暂不可选</h2><p>资料不存在或已暂停展示，请重新选择。</p><Link className="button secondary" to={back}>返回印厂列表</Link></section> : <div className="directory-layout">
      <form className="directory-filter" onSubmit={event => { event.preventDefault(); const query = searchParams(draft); query.set('view', view); setParams(query); }}>
        <h2><MapPin size={20} />印刷品使用地区</h2><p className="directory-help">先按地区匹配，无需提供详细门牌。</p>
        {(['province', 'city', 'district'] as const).map((key, i) => <label key={key}>{['省 / 直辖市', '城市', '区 / 县'][i]}<input required maxLength={120} list={`factory-${key}`} value={draft[key]} placeholder={['如：广东省', '如：深圳市', '如：南山区'][i]} onChange={e => setDraft(value => ({ ...value, [key]: e.target.value }))} /><datalist id={`factory-${key}`}>{[...new Set(active.flatMap(f => f.regions).filter(r => key === 'province' || (r.province === draft.province && (key === 'city' || r.city === draft.city))).map(r => r[key]))].filter(v => v !== '*').map(v => <option key={v} value={v} />)}</datalist></label>)}
        <h2><SlidersHorizontal size={19} />生产需求</h2><label>卡片材质<select required value={draft.material} onChange={e => setDraft(value => ({ ...value, material: e.target.value }))}><option value="">请选择材质</option>{Object.entries(factoryMaterials).map(([id, name]) => <option key={id} value={id}>{name}</option>)}</select></label>
        <fieldset><legend>需要的工艺（可多选）</legend>{Object.entries(factoryCrafts).map(([id, name]) => <label key={id} className="directory-checkbox"><input type="checkbox" checked={draft.crafts.includes(id)} onChange={e => setDraft(value => ({ ...value, crafts: e.target.checked ? [...value.crafts, id] : value.crafts.filter(c => c !== id) }))} />{name}</label>)}</fieldset>
        <button className="button primary" type="submit">查找可承接印厂 <ArrowRight size={17} /></button>
      </form>
      <section className="directory-results" aria-label="匹配结果"><header><h2>{searched ? '匹配印厂' : '选择为你生产的印厂'}</h2><span>按服务区域与已登记能力筛选</span></header>
        <div className="directory-view-switch" role="group" aria-label="印厂显示方式"><button type="button" aria-pressed={view === 'map'} onClick={() => changeView('map')}><Map size={16} />地图显示</button><button type="button" aria-pressed={view === 'list'} onClick={() => changeView('list')}><List size={16} />列表显示</button></div>
        {view === 'map' && <FactoryMap factories={(searched ? matches : active).toSorted((a, b) => a.name.localeCompare(b.name, 'zh-CN'))} detailQuery={params.toString()} searched={searched} />}
        {active.length === 0 ? <div className="directory-empty"><Factory size={42} strokeWidth={1.3} /><h3>首批印厂正在接入</h3><p>平台计划先连接 6–10 家印厂或印刷设备。完成真实资料登记后，这里将展示符合你需求的承接方。</p><Link to="/products" className="button secondary">先浏览卡片产品</Link></div> : !searched ? <div className="directory-empty"><MapPin size={38} /><h3>填写使用地区后查看匹配印厂</h3><p>选择材质和工艺，找到服务该地区且具备对应能力的印厂。</p></div> : matches.length === 0 ? <div className="directory-empty"><h3>暂未找到符合条件的印厂</h3><p>请确认地区名称完整、材质与工艺选择正确，或调整需求后重新查找。</p></div> : view === 'map' ? null : <><p className="directory-help" role="status">找到 {matches.length} 家；按名称排序，不代表距离或推荐排名。</p>{matches.sort((a, b) => a.name.localeCompare(b.name, 'zh-CN')).map(f => <article key={f.id} className="directory-card"><div className="directory-factory-mark"><Factory size={30} /></div><div><span className="directory-type">{f.kind === 'equipment' ? '印刷设备' : '印刷厂'}</span><h3>{f.name}</h3><p>{f.description}</p><p className="directory-help">{f.address}</p><div className="directory-tags">{f.materials.map(m => <span key={m}>{factoryMaterials[m]}</span>)}{f.crafts.map(c => <span key={c}>{factoryCrafts[c]}</span>)}</div><Link className="button secondary" to={`/factories/${f.id}?${params.toString()}`}>选择此印厂</Link></div></article>)}</>}
        <div className="directory-explainer"><h3>像选店一样选择印刷服务</h3><p>比较印厂支持的材质和工艺，选择承接方后再进入报价与下单。具体规格、实时产能、交期和配送费用将在各厂服务接入后确认。</p></div>
      </section>
    </div>}
  </div>;
}
