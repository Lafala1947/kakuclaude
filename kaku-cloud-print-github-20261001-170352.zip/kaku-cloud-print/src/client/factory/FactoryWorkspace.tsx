import { Link, NavLink, useParams } from 'react-router-dom';
import { ArrowRight, ArrowUpRight, Factory, Layers3 } from 'lucide-react';
import { adminGroups, useAdminAccess } from '../admin/AdminAccess';
import AdminSectionNav from '../AdminSectionNav';
import { apiEnabled } from '../api/client';
import { factoryModules, moduleStatus, type FactoryModule } from './modules';
import './factory.css';

function ModuleLinks({ module }: { module: FactoryModule }) {
  const { group } = useAdminAccess();
  const links = module.links.filter(link => link.group === group && (!link.apiOnly || apiEnabled));
  return links.length ? <div className="factory-actions">{links.map(link =>
    <Link key={link.to} to={link.to} className="button secondary">{link.name}<ArrowUpRight size={16} /></Link>
  )}</div> : module.links.length ? <p className="factory-muted">现有业务功能按管理组权限开放。</p> : null;
}

export default function FactoryWorkspace() {
  const { moduleId } = useParams();
  const { group } = useAdminAccess();
  const selected = factoryModules.find(module => module.id === moduleId);
  const index = selected ? factoryModules.indexOf(selected) : -1;
  if (moduleId && !selected) return <section className="admin-access-message"><h1>模块不存在</h1><Link to="/admin/factory">返回工厂总览</Link></section>;
  return <div className="admin-workspace factory-workspace">
    <AdminSectionNav />
    <div className="factory-layout">
      <aside className="factory-sidebar">
        <div className="factory-sidebar-brand"><Factory size={25} /><div>卡库云印<small>云端印刷工厂</small></div></div>
        <nav aria-label="工厂业务模块">
          <NavLink end to="/admin/factory"><Layers3 size={17} />工厂总览</NavLink>
          {factoryModules.map((module, i) => <NavLink key={module.id} to={`/admin/factory/${module.id}`}><span className="factory-step-index">{String(i + 1).padStart(2, '0')}</span>{module.name}<i className={`factory-dot ${module.state}`} aria-label={moduleStatus[module.state]} /></NavLink>)}
        </nav>
        <p className="factory-sidebar-note">{group && adminGroups[group].name}<br />业务操作按账号权限开放</p>
      </aside>
      <div className="factory-main">
        <header className="factory-heading">
          <span className="admin-kicker">KAKU / CLOUD FACTORY</span>
          <h1>{selected ? selected.name : '云端印刷工厂'}</h1>
          <p>{selected ? selected.description : '从使用地址出发，连接客户与合适的印厂，贯通接单、生产和交付。'}</p>
          <div className="factory-cmyk" aria-hidden="true"><i /><i /><i /><i /></div>
        </header>
        {selected ? <>
          <div className={`factory-phase ${selected.state}`}><b>{moduleStatus[selected.state]}</b><span>{selected.id === 'network' ? '选厂页面与筛选框架已接入，真实印厂资料及独立接单待接入。' : selected.state === 'planned' ? '功能待建设，当前仅展示模块框架。' : selected.state === 'partial' ? '基础流程已接入，审核细则后续完善。' : '现有接单功能可用；选厂信息与订单的关联将在印厂接入时完善。'}</span></div>
          <section className="factory-handoff" aria-label="模块交接">
            <div><span>接收什么</span><h2>上游输入</h2><p>{selected.input}</p></div>
            <ArrowRight aria-hidden="true" />
            <div><span>交付什么</span><h2>下游输出</h2><p>{selected.output}</p></div>
          </section>
          <section className="factory-section"><h2>功能范围</h2><div className="factory-areas">{selected.areas.map(area => <div key={area}><Layers3 size={18} /><strong>{area}</strong></div>)}</div><ModuleLinks module={selected} /></section>
          {selected.id === 'network' && <section className="factory-network-note"><h2>首批接入 · 6–10 家</h2><p>首期按服务省市区、材质和已登记工艺筛选；独立设备关联实际承接订单的印厂。具体规格、距离、实时产能和交期待后续接入。</p><p>工厂账号、各厂报价、订单归属与数据隔离将在接入阶段实现。</p><Link to="/factories" className="button secondary">查看客户选厂页面 <ArrowUpRight size={16} /></Link></section>}
          <nav className="factory-adjacent" aria-label="业务衔接">{index > 0 ? <Link to={`/admin/factory/${factoryModules[index - 1].id}`}>上一环节 · {factoryModules[index - 1].name}</Link> : <span />}{index < factoryModules.length - 1 && <Link to={`/admin/factory/${factoryModules[index + 1].id}`}>下一环节 · {factoryModules[index + 1].name}<ArrowRight size={16} /></Link>}</nav>
        </> : <>
          <section className="factory-journey"><div><span className="admin-kicker">CUSTOMER JOURNEY</span><h2>先选印厂，再下单</h2><p>首批连接 6–10 家印厂或设备</p></div><ol>{['填写使用地址', '匹配生产能力', '客户选择印厂', '报价与提交订单'].map(step => <li key={step}>{step}</li>)}</ol></section>
          <section className="factory-section"><h2>三端协同</h2><div className="factory-portals"><article><span>客户端</span><h3>找印厂 · 购买印刷品</h3><p>按使用地区与制作需求选厂，逐步接入下单与进度跟踪。</p><Link to="/factories">进入选厂页面 <ArrowUpRight size={15} /></Link></article><article><span>印厂端 · 待建设</span><h3>接订单 · 组织生产</h3><p>每家印厂维护能力、接单与交期，只处理归属本厂的业务。</p><Link to="/admin/factory/production">查看履约模块框架 <ArrowUpRight size={15} /></Link></article><article><span>平台端</span><h3>管入驻 · 管规则</h3><p>管理供给网络和平台运营，后续接入结算、评价与售后。</p><Link to="/admin/factory/network">查看印厂接入框架 <ArrowUpRight size={15} /></Link></article></div></section>
          <section className="factory-section"><div className="factory-section-heading"><h2>业务全景</h2><span>沿订单的交付过程展开</span></div><div className="factory-module-grid">{factoryModules.map((module, i) => <Link key={module.id} to={`/admin/factory/${module.id}`} className={`factory-module ${module.state}`}><div><span className="factory-module-index">{String(i + 1).padStart(2, '0')}</span><span className={`factory-status ${module.state}`}>{moduleStatus[module.state]}</span></div><h3>{module.name}<ArrowUpRight size={19} /></h3><p>{module.subtitle}</p></Link>)}</div></section>
          <section className="factory-section"><h2>我的业务入口</h2><p className="factory-muted">已接入功能，可直接进入处理。</p>{factoryModules.filter(module => module.links.some(link => link.group === group && (!link.apiOnly || apiEnabled))).map(module => <ModuleLinks key={module.id} module={module} />)}</section>
          <p className="factory-footnote">当前为平台整体框架。印厂匹配与生产履约模块将逐步接入，页面不显示模拟订单或虚构产能。</p>
        </>}
      </div>
    </div>
  </div>;
}
