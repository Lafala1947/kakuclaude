import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import * as L from 'leaflet';
import { LocateFixed, MapPin, ArrowUpRight } from 'lucide-react';
import { factoryMaterials, type PrintFactory } from '../../shared/factories';
import 'leaflet/dist/leaflet.css';
import './factory-map.css';

const initialCenter: L.LatLngTuple = [35, 104];
function fitFactories(map: L.Map, factories: PrintFactory[]) {
  const points = factories.flatMap(f => f.location ? [[f.location.latitude, f.location.longitude] as L.LatLngTuple] : []);
  if (points.length) map.fitBounds(L.latLngBounds(points), { padding: [45, 45], maxZoom: 13, animate: false });
  else map.setView(initialCenter, 4, { animate: false });
}

export default function FactoryMap({ factories, detailQuery, searched }: {
  factories: PrintFactory[]; detailQuery: string; searched: boolean;
}) {
  const container = useRef<HTMLDivElement>(null);
  const mapRef = useRef<L.Map | null>(null);
  const tileRef = useRef<L.TileLayer | null>(null);
  const boundsKey = useRef('');
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [tileError, setTileError] = useState(false);
  const visible = factories.filter(f => f.active);
  const selected = visible.find(f => f.id === selectedId) ?? visible[0];
  const located = visible.filter(f => f.location);

  useEffect(() => {
    if (!container.current) return;
    const map = L.map(container.current, { scrollWheelZoom: false, zoomControl: false }).setView(initialCenter, 4);
    mapRef.current = map;
    L.control.zoom({ position: 'topright' }).addTo(map);
    const tiles = L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
      maxZoom: 19,
      attribution: '&copy; <a href="https://www.openstreetmap.org/copyright" target="_blank" rel="noopener noreferrer">OpenStreetMap</a> contributors',
    }).addTo(map);
    tileRef.current = tiles;
    tiles.on('tileerror', () => setTileError(true));
    const resize = () => map.invalidateSize({ pan: false });
    const observer = typeof ResizeObserver !== 'undefined' ? new ResizeObserver(resize) : null;
    observer?.observe(container.current);
    window.addEventListener('resize', resize);
    return () => {
      observer?.disconnect(); window.removeEventListener('resize', resize);
      map.remove(); mapRef.current = null; tileRef.current = null; boundsKey.current = '';
    };
  }, []);

  useEffect(() => {
    const map = mapRef.current;
    if (!map) return;
    const group = L.layerGroup().addTo(map);
    visible.forEach((factory, index) => {
      if (!factory.location) return;
      // Factory names stay in DOM text/attributes, never interpolated into HTML.
      const label = document.createElement('span');
      label.textContent = String(index + 1);
      const marker = L.marker([factory.location.latitude, factory.location.longitude], {
        icon: L.divIcon({ html: label, className: `factory-map-pin${selected?.id === factory.id ? ' selected' : ''}`, iconSize: [34, 40], iconAnchor: [17, 40] }),
        title: factory.name, keyboard: true, riseOnHover: true,
        zIndexOffset: selected?.id === factory.id ? 1000 : 0,
      }).addTo(group);
      marker.getElement()?.setAttribute('aria-label', `在地图上查看：${factory.name}`);
      marker.on('click', () => setSelectedId(factory.id));
    });
    const nextBounds = JSON.stringify(visible.map(f => [f.id, f.location]));
    if (boundsKey.current !== nextBounds) { fitFactories(map, visible); boundsKey.current = nextBounds; }
    return () => { group.remove(); };
  }, [factories, selected?.id]);

  function select(factory: PrintFactory) {
    setSelectedId(factory.id);
    if (factory.location) mapRef.current?.panTo([factory.location.latitude, factory.location.longitude]);
  }
  return <section className="factory-map-view" aria-label="地图选厂">
    <div className="factory-map-toolbar"><span><i />{searched ? '符合筛选条件的印厂' : '已入驻印厂分布'} · {located.length} 个地图位置</span><button type="button" onClick={() => mapRef.current && fitFactories(mapRef.current, visible)}><LocateFixed size={15} />查看全部位置</button></div>
    <div className="factory-map-canvas-wrap">
      <div ref={container} className="factory-map-canvas" role="region" aria-label="印厂位置地图" />
      {located.length === 0 && <div className="factory-map-message"><MapPin size={19} /><span>{visible.length ? '匹配印厂尚未补充坐标，可在下方查看资料。' : '暂无可显示的印厂位置，录入真实坐标后将在地图标注。'}</span></div>}
      {tileError && <div className="factory-map-error" role="alert">地图底图加载失败，可切换列表继续选厂。<button type="button" onClick={() => { setTileError(false); tileRef.current?.redraw(); }}>重试地图</button></div>}
    </div>
    {visible.length > 0 && <div className="factory-map-selection">
      <div className="factory-map-options" aria-label="地图中的印厂">{visible.map((factory, index) => <button key={factory.id} type="button" aria-pressed={factory.id === selected?.id} onClick={() => select(factory)}><b>{index + 1}</b><span>{factory.name}<small>{factory.location ? factory.address : '位置待补充'}</small></span></button>)}</div>
      {selected && <article className="factory-map-selected"><span className="directory-type">{selected.kind === 'equipment' ? '印刷设备' : '印刷厂'}</span><h3>{selected.name}</h3><p>{selected.description}</p><p className="directory-help">{selected.address}</p><div className="directory-tags">{selected.materials.map(m => <span key={m}>{factoryMaterials[m]}</span>)}</div><Link className="button secondary" to={`/factories/${selected.id}${detailQuery ? `?${detailQuery}` : ''}`}>选择此印厂 <ArrowUpRight size={16} /></Link></article>}
    </div>}
    <p className="factory-map-caption">可拖动地图，使用 ＋ / − 缩放；标记是印厂生产地址，不代表服务范围。尚未计算距离或实时产能。</p>
  </section>;
}
