import type { AdminGroup } from '../admin/AdminAccess';

export type FactoryModule = {
  id: string; name: string; subtitle: string; state: 'connected' | 'partial' | 'planned';
  description: string; input: string; output: string; areas: string[];
  links: { name: string; to: string; group: AdminGroup; apiOnly?: boolean }[];
};

export const factoryModules: FactoryModule[] = [
  {
    id: 'network', name: '印厂网络', subtitle: '地址 · 能力 · 承接', state: 'partial',
    description: '连接首批 6–10 家印厂或印刷设备，让客户按使用地址和生产需求选择承接方。',
    input: '印刷品使用地址、材质、规格、数量与工艺需求',
    output: '可承接的印厂、生产能力与客户选择的履约工厂',
    areas: ['印厂入驻与资料', '服务区域与生产能力', '设备归属与承接主体', '地址筛选与印厂选择'], links: [],
  },
  {
    id: 'intake', name: '接单中心', subtitle: '报价 · 客户 · 订单', state: 'connected',
    description: '承接客户选厂后的报价与下单，集中管理订单和客户资料。',
    input: '客户选择的印厂、产品规格、使用地址与生产文件',
    output: '订单、报价明细与待审核文件',
    areas: ['在线报价与五类费用', '会员资料与等级', '订单查询与状态', '产品与网站内容'],
    links: [
      { name: '订单管理', to: '/admin/orders', group: 'sales', apiOnly: true },
      { name: '会员管理', to: '/admin/members', group: 'sales' },
      { name: '价格管理', to: '/admin/pricing', group: 'pricing' },
      { name: '产品管理', to: '/admin/products', group: 'pages' },
      { name: '首页内容管理', to: '/admin/pages', group: 'pages' },
    ],
  },
  {
    id: 'prepress', name: '文件处理', subtitle: '审核 · 版本 · 交接', state: 'partial',
    description: '保留已有文件审核入口，后续按实际印前流程完善审核方案。',
    input: '订单规格、印品文件与工艺对稿图', output: '审核结果与确认的生产文件版本',
    areas: ['文件接收', '审核与退回', '修订版本记录', '生产文件交接'],
    links: [{ name: '文件审核', to: '/admin/reviews', group: 'sales', apiOnly: true }],
  },
  {
    id: 'planning', name: '生产计划', subtitle: '工单 · 产能 · 排程', state: 'planned',
    description: '将确认可生产的订单转为工单，安排设备、材料与交期。',
    input: '审核通过的文件版本、订单规格、数量与交期', output: '生产工单、工序路线与设备排程',
    areas: ['生产工单', '产能与排程', '物料需求', '交期与优先级'], links: [],
  },
  {
    id: 'production', name: '车间生产', subtitle: '印刷 · 后道 · 报工', state: 'planned',
    description: '围绕工单衔接印刷与后道加工，记录各工序进度和异常。',
    input: '生产工单、排程、物料与确认文件', output: '完工数量、工序记录与待检产品',
    areas: ['设备任务', '印刷与后道工序', '开工完工报工', '异常与返工'], links: [],
  },
  {
    id: 'quality', name: '质量管理', subtitle: '检验 · 追溯 · 放行', state: 'planned',
    description: '对接生产记录，组织过程检验与成品检验。',
    input: '工序记录、待检产品与质量要求', output: '检验结果、合格数量与处置记录',
    areas: ['过程检验', '成品检验', '不良品处理', '质量追溯'], links: [],
  },
  {
    id: 'shipping', name: '仓储发货', subtitle: '库存 · 包装 · 配送', state: 'planned',
    description: '衔接合格品入库、包装、出库与物流交付。',
    input: '检验合格产品、包装要求与收货地址', output: '出入库记录、发货单与物流信息',
    areas: ['物料与成品库存', '包装与配货', '出库发货', '物流与签收'], links: [],
  },
  {
    id: 'operations', name: '经营管理', subtitle: '成本 · 结算 · 分析', state: 'planned',
    description: '汇总接单与履约数据，逐步建立各印厂成本、对账和经营分析。',
    input: '订单金额、生产耗用、履约记录与结算资料', output: '对账资料、成本明细与经营报表',
    areas: ['工厂对账与结算', '订单成本', '经营报表', '交付效率分析'], links: [],
  },
];
export const moduleStatus = { connected: '已有功能', partial: '基础流程', planned: '待建设' } as const;
