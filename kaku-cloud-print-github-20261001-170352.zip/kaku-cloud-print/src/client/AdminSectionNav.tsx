import { NavLink } from "react-router-dom";
import {
  FileSpreadsheet,
  UsersRound,
  PanelsTopLeft,
  LayoutDashboard,
  Package,
} from "lucide-react";
import { adminGroups, useAdminAccess } from "./admin/AdminAccess";
import "./members/members.css";
import { apiEnabled } from "./api/client";
import { useSession } from "./api/SessionContext";
export default function AdminSectionNav() {
  const { group, setGroup } = useAdminAccess();
  const session = useSession();
  return (
    <nav className="admin-section-nav" aria-label="后台管理模块">
      <NavLink end to="/admin">
        <LayoutDashboard size={17} />
        后台入口
      </NavLink>
      {group && <NavLink to="/admin/factory"><LayoutDashboard size={17} />工厂总览</NavLink>}
      {group === "pricing" && (
        <NavLink to="/admin/pricing">
          <FileSpreadsheet size={17} />
          价格管理
        </NavLink>
      )}
      {group === "sales" && (
        <NavLink to="/admin/members">
          <UsersRound size={17} />
          会员管理{!apiEnabled && <span>预览</span>}
        </NavLink>
      )}
      {apiEnabled && group === "sales" && (
        <NavLink to="/admin/orders">
          <Package size={17} />
          订单管理
        </NavLink>
      )}
      {apiEnabled && group === "sales" && (
        <NavLink to="/admin/reviews">
          <FileSpreadsheet size={17} />
          文件审核
        </NavLink>
      )}
      {group === "pages" && (
        <NavLink to="/admin/products">
          <Package size={17} />
          产品管理
        </NavLink>
      )}
      {group === "pages" && (
        <NavLink to="/admin/pages">
          <PanelsTopLeft size={17} />
          首页内容管理
        </NavLink>
      )}
      {group && (
        <div className="admin-role-chip">
          <span>
            {adminGroups[group].name}
            {apiEnabled ? " · 员工账号" : " · 权限演示"}
          </span>
          <button
            disabled={session.loading}
            onClick={() =>
              apiEnabled
                ? void session.logout().catch(() => {})
                : setGroup(null)
            }
          >
            {apiEnabled ? "退出登录" : "退出管理组"}
          </button>
        </div>
      )}
    </nav>
  );
}
