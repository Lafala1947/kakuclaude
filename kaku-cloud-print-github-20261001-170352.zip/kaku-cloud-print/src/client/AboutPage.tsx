import { useState } from 'react';
import { Link } from 'react-router-dom';
import { ArrowUpRight } from 'lucide-react';
import './about.css';

// Content and original image references supplied by the user: https://alabel.cn/about
const team = [
  {
    name: '张明', role: '首席运营',
    description: '20年全球头部印刷供应商工作经验，擅长捕捉市场动态，把控产品方向。',
    image: 'https://baas-api.wanwang.xin/toc/image/preview/male-photographer-holding-camera-studio.jpg?w=400&h=500',
  },
  {
    name: '李娜', role: '设计总监',
    description: '20年美国4A广告公司设计总监工作经验，对产品营销如何通过设计语言表达有独到的见解。',
    image: 'https://material-image.wanwang.xin/1251905301345487/public/d45424f7-b2b7-4045-844b-f83bf04d3fd5.jpg',
  },
  {
    name: '王强', role: '生产主管',
    description: '20年外资印厂生产管理经验，印前、印刷、印后有标准的管理和操作流程。',
    image: 'https://material-image.wanwang.xin/1251905301345487/public/0bccb2ac-6ebd-4d04-a4ad-7041f90c7d47.webp',
  },
];
const principles = [
  { title: '专一深耕', text: '深耕印刷行业20年，经历了行业的波澜起伏，最终聚焦在卡片定制单一产品，致力于将产品做到极致。' },
  { title: '质优价廉', text: '印前、印刷、印后专业的设备配备和技术保障，将多年经营经验集于一体，在质量稳定的基础上保证价格的竞争力。' },
  { title: '优质服务', text: '在线接单报价、生产、物流，全程可视可控。' },
];
function AboutImage({ src, alt, label }: { src: string; alt: string; label: string }) {
  const [failed, setFailed] = useState(false);
  return failed ? <div className="about-image-fallback" role="img" aria-label={`${alt}（图片暂不可用）`}><span>KAKU</span><strong>{label}</strong></div> : <img src={src} alt={alt} loading="lazy" onError={() => setFailed(true)} />;
}
export default function AboutPage() {
  return <div className="about-page">
    <header className="about-hero">
      <span className="admin-kicker">KAKU / ABOUT US</span>
      <h1>关于我们</h1>
      <p>用图文记录美好，<br className="about-mobile-break" />用印刷讲述故事</p>
      <div className="about-cmyk" aria-hidden="true"><i /><i /><i /><i /></div>
    </header>
    <section className="about-story" aria-labelledby="about-story-title">
      <div className="about-story-image"><AboutImage src="https://material-image.wanwang.xin/1251905301345487/public/3367bd1b-a2e6-4ffd-8c0d-e3fb2bea5d7f.jpg" alt="卡库云印品牌故事" label="专注卡片专业智造" /><span className="about-image-caption">KAKU CLOUD PRINT · EST. 2021</span></div>
      <div className="about-story-copy"><span className="admin-kicker">OUR STORY</span><h2 id="about-story-title">品牌故事</h2>
        <p>卡库云印诞生于对印刷艺术的热爱。2021年，一群热爱图像技术的年轻人走到一起，希望创建一个专注于卡片专业智造的专业平台。</p>
        <p>“卡库”对我们有着特殊的意义。它代表着我们追求的三个核心理念：</p>
        <dl className="about-beliefs"><div><dt>一个目标</dt><dd>卡片仓库</dd></div><div><dt>多种风格</dt><dd>融合各种印刷术，多元表达</dd></div><div><dt>云端可控</dt><dd>传统印刷术与现代 AI 技术的融合尝试</dd></div></dl>
        <p>多年来，我们始终坚持用心对待每一位客户，用专业成就每一份订单。我们相信，您的每一个产品都有独特的美，值得被认真记录。</p>
      </div>
    </section>
    <section className="about-principles" aria-labelledby="about-principles-title"><div className="about-section-heading"><span className="admin-kicker">WHAT WE BELIEVE</span><h2 id="about-principles-title">经营理念</h2></div><div className="about-principle-grid">{principles.map(item => <article key={item.title}><h3>{item.title}</h3><p>{item.text}</p></article>)}</div></section>
    <section className="about-team" aria-labelledby="about-team-title"><div className="about-section-heading"><span className="admin-kicker">OUR TEAM</span><h2 id="about-team-title">团队介绍</h2><p>专业的运营生产团队，为你打造完美作品</p></div><div className="about-team-grid">{team.map(person => <article key={person.name}><div className="about-portrait"><AboutImage src={person.image} alt={person.name} label={person.name} /></div><div className="about-person"><span>{person.role}</span><h3>{person.name}</h3><p>{person.description}</p></div></article>)}</div></section>
    <section className="about-next"><div><h2>从一个想法，到一张好卡片</h2><p>了解我们的产品，开始你的卡片定制。</p></div><Link to="/products" className="button primary">浏览卡片产品 <ArrowUpRight size={18} /></Link></section>
  </div>;
}
