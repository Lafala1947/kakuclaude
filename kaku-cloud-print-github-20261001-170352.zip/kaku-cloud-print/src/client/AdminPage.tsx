import { apiEnabled, apiRequest, ApiError } from "./api/client";
import type { Versioned } from "../shared/api";
import ServerPublishControls from "./content/ServerPublishControls";
import { conflictMessage } from "./content/useServerConfigDraft";
import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  Check,
  CheckCircle2,
  ChevronRight,
  Download,
  FileSpreadsheet,
  FolderOpen,
  Info,
  Layers,
  Package,
  Palette,
  Printer,
  RefreshCw,
  Save,
  Scissors,
  Truck,
  Upload,
  X,
} from "lucide-react";
import type { PricingConfig } from "../shared/contracts";
import { defaultInput } from "../shared/contracts";
import { defaultConfig, validateConfig } from "../lib/config";
import { calculateQuote } from "../lib/pricing";
import { parsePricingCsv, serializePricingCsv } from "../lib/csv";
import { download, message, money } from "./utils";
import { usePricingDraft } from "./DraftContext";
import CatalogSettings from "./CatalogSettings";
import AdminSectionNav from "./AdminSectionNav";

type Group = "design" | "printing" | "paper" | "finishing" | "logistics";
type Field = {
  key: string;
  label: string;
  unit: string;
  help?: string;
  percent?: boolean;
  step?: number;
  min?: number;
};
const categories: {
  id: Group;
  name: string;
  icon: typeof Palette;
  description: string;
}[] = [
  {
    id: "design",
    name: "设计费",
    icon: Palette,
    description: "按客户购买款数收取，计入成本加价。",
  },
  {
    id: "printing",
    name: "印刷费",
    icon: Printer,
    description: "起印费用 + 超出起印量的加印费用，按印刷面数计费。",
  },
  {
    id: "paper",
    name: "纸张费",
    icon: Layers,
    description: "根据纸张克重、吨价和含损耗大纸数量计算。",
  },
  {
    id: "finishing",
    name: "后道工艺费",
    icon: Scissors,
    description: "每项工艺单独设置费率；共用版费只收取一次。",
  },
  {
    id: "logistics",
    name: "物流费",
    icon: Truck,
    description: "按成品重量加包装重量计算，不参与加价。",
  },
];
const fieldGroups: Record<Group, { title: string; fields: Field[] }[]> = {
  design: [
    {
      title: "设计服务",
      fields: [
        {
          key: "adjust",
          label: "文件调整",
          unit: "元 / 款",
          help: "客户已有文件，需要排版或文字调整。",
        },
        {
          key: "custom",
          label: "定制设计",
          unit: "元 / 款",
          help: "根据客户需求重新设计。",
        },
      ],
    },
  ],
  printing: [
    {
      title: "起印与加印",
      fields: [
        {
          key: "baseQuantity",
          label: "单面起印数量",
          unit: "印",
          step: 1,
          min: 1,
        },
        { key: "basePrice", label: "单面起印费", unit: "元" },
        {
          key: "stepQuantity",
          label: "加印计费步长",
          unit: "印 / 档",
          step: 1,
          min: 1,
        },
        { key: "stepPrice", label: "单面每档加印费", unit: "元 / 档" },
      ],
    },
  ],
  paper: [
    {
      title: "纸张成本",
      fields: [
        { key: "gsm", label: "纸张克重", unit: "g / ㎡", min: 1, step: 1 },
        { key: "tonPrice", label: "采购吨价", unit: "元 / 吨" },
        {
          key: "waste",
          label: "数量损耗加放率",
          unit: "%",
          percent: true,
          step: 0.1,
        },
      ],
    },
    {
      title: "大纸与拼版参数",
      fields: [
        { key: "sheetWidth", label: "大纸长边", unit: "mm", min: 1 },
        { key: "sheetHeight", label: "大纸短边", unit: "mm", min: 1 },
        { key: "left", label: "左侧预留", unit: "mm" },
        { key: "right", label: "右侧预留", unit: "mm" },
        { key: "gripper", label: "咬口预留", unit: "mm", min: 8 },
        { key: "tail", label: "尾边预留", unit: "mm" },
        { key: "gap", label: "相邻成品总间距", unit: "mm" },
        {
          key: "shareCount",
          label: "实际分摊款数",
          unit: "款",
          step: 1,
          help: "填 0 按满版拼数分摊；不能大于可拼版位。",
        },
      ],
    },
  ],
  finishing: [
    {
      title: "表面加工",
      fields: [
        {
          key: "lamination",
          label: "覆膜加工",
          unit: "元 / ㎡ / 面",
          help: "按含损耗大纸面积计算。",
        },
        {
          key: "foil",
          label: "烫金加工",
          unit: "元 / ㎡",
          help: "按每张累计图案面积 × 加工数量计算。",
        },
      ],
    },
    {
      title: "裁切与模切版",
      fields: [
        { key: "cutting", label: "普通裁切", unit: "元 / 整版" },
        { key: "dieRate", label: "异形模切加工", unit: "元 / 大张" },
        {
          key: "diePlate",
          label: "基础模切版费",
          unit: "元 / 整版",
          help: "异形模切或压纹、击凸、压凹触发，只收一次。",
        },
      ],
    },
    {
      title: "模切版附加工艺",
      fields: [
        { key: "texture", label: "压纹附加版费", unit: "元 / 整版" },
        { key: "emboss", label: "击凸附加版费", unit: "元 / 整版" },
        { key: "deboss", label: "压凹附加版费", unit: "元 / 整版" },
      ],
    },
  ],
  logistics: [
    {
      title: "重量与基础运费",
      fields: [
        { key: "firstWeight", label: "首重", unit: "kg", min: 0.01 },
        { key: "firstPrice", label: "首重费用", unit: "元" },
        {
          key: "additionalPrice",
          label: "续重费用",
          unit: "元 / kg",
          help: "超出首重的部分，不足 1 kg 按 1 kg。",
        },
        { key: "packagingWeight", label: "每单包装重量", unit: "kg" },
      ],
    },
    {
      title: "配送区域系数",
      fields: [
        { key: "localMultiplier", label: "本地 / 省内", unit: "倍" },
        { key: "nationalMultiplier", label: "国内常规地区", unit: "倍" },
        { key: "remoteMultiplier", label: "偏远地区", unit: "倍" },
      ],
    },
  ],
};
const DRAFT_KEY = "yinhao-pricing-draft-v1";

export default function AdminPage({
  deployed,
  onReload,
}: {
  deployed: PricingConfig | null;
  onReload: () => Promise<void>;
}) {
  const {
    draft,
    setDraft,
    dirty,
    setDirty,
    serverRevision,
    setServerRevision,
  } = usePricingDraft(deployed);
  const [category, setCategory] = useState<Group>("finishing");
  const [notice, setNotice] = useState<{
    text: string;
    error?: boolean;
  } | null>(null);
  const [serverLoading, setServerLoading] = useState(apiEnabled);
  const [serverSaving, setServerSaving] = useState(false);
  const [conflicted, setConflicted] = useState(false);
  const latest = useRef(draft);
  latest.current = draft;
  const currentRevision = useRef(serverRevision);
  currentRevision.current = serverRevision;
  const requestBusy = useRef(false);
  const serverData = useRef<Versioned<PricingConfig> | null>(null);
  useEffect(() => {
    if (!apiEnabled) return;
    let active = true;
    const controller = new AbortController();
    void apiRequest<Versioned<PricingConfig>>("/config/pricing", {
      signal: controller.signal,
    })
      .then((envelope) => {
        const data = validateConfig(envelope.data);
        if (!envelope.revision) throw new Error("服务器配置版本无效。");
        if (!active) return;
        serverData.current = { ...envelope, data };
        const baseRevision = currentRevision.current;
        if (
          (baseRevision && baseRevision !== envelope.revision) ||
          (!baseRevision &&
            (!deployed ||
              serializePricingCsv(data) !== serializePricingCsv(deployed)))
        ) {
          setConflicted(true);
          setNotice({ text: conflictMessage, error: true });
        } else setServerRevision(envelope.revision);
      })
      .catch((error) => {
        if (active)
          setNotice({
            text: `服务器费用表读取失败：${message(error)}`,
            error: true,
          });
      })
      .finally(() => {
        if (active) setServerLoading(false);
      });
    return () => {
      active = false;
      controller.abort();
    };
  }, []);
  async function reloadServerPricing() {
    if (requestBusy.current) throw new Error("正在处理服务器请求，请稍候。");
    const previous = latest.current;
    requestBusy.current = true;
    setServerLoading(true);
    try {
      const envelope =
        await apiRequest<Versioned<PricingConfig>>("/config/pricing");
      const data = validateConfig(envelope.data);
      if (!envelope.revision) throw new Error("服务器配置版本无效。");
      if (previous !== latest.current)
        throw new Error("加载期间草稿已修改，本次未替换。请再次确认加载。");
      serverData.current = { ...envelope, data };
      setDraft(structuredClone(data));
      setDirty(false);
      setServerRevision(envelope.revision);
      setConflicted(false);
      setNotice(null);
      await onReload();
    } finally {
      requestBusy.current = false;
      setServerLoading(false);
    }
  }
  async function publishPricing() {
    if (requestBusy.current) throw new Error("正在处理服务器请求，请稍候。");
    if (conflicted) throw new Error(conflictMessage);
    if (!serverRevision || !serverData.current)
      throw new Error("请先加载服务器最新版本。");
    const previous = latest.current;
    const data = validateConfig({
      ...previous,
      version: Math.max(previous.version, serverData.current.data.version) + 1,
    });
    requestBusy.current = true;
    setServerSaving(true);
    let published = false;
    try {
      const envelope = await apiRequest<Versioned<PricingConfig>>(
        "/config/pricing",
        {
          method: "PUT",
          body: JSON.stringify({ revision: serverRevision, data }),
        },
      );
      const accepted = validateConfig(envelope.data);
      serverData.current = { ...envelope, data: accepted };
      setServerRevision(envelope.revision);
      if (latest.current === previous) {
        setDraft(accepted);
        setDirty(false);
      }
      published = true;
      await onReload();
    } catch (error) {
      if (published)
        throw new Error(
          `服务器已发布，但当前页面刷新失败，请重新加载：${message(error)}`,
        );
      if (error instanceof ApiError && error.status === 409) {
        setConflicted(true);
        throw new Error(conflictMessage);
      }
      throw error;
    } finally {
      requestBusy.current = false;
      setServerSaving(false);
    }
  }
  const fileRef = useRef<HTMLInputElement>(null);
  const meta = categories.find((c) => c.id === category)!;
  const preview = useMemo(() => {
    try {
      return {
        result: calculateQuote(defaultInput, draft, { preview: true }),
        error: "",
      };
    } catch (e) {
      return { result: null, error: message(e) };
    }
  }, [draft]);
  function change(group: Group, key: string, value: number | string | boolean) {
    setDraft((d) => ({ ...d, [group]: { ...d[group], [key]: value } }));
    setDirty(true);
    setNotice(null);
  }
  function saveDraft() {
    try {
      validateConfig(draft);
      localStorage.setItem(DRAFT_KEY, JSON.stringify(draft));
      if (apiEnabled && serverRevision)
        localStorage.setItem(`${DRAFT_KEY}-revision`, serverRevision);
      setDirty(false);
      setNotice({ text: "草稿已保存在当前浏览器，线上费用表未改变。" });
    } catch (e) {
      setNotice({ text: message(e), error: true });
    }
  }
  function loadDraft() {
    try {
      const value = localStorage.getItem(DRAFT_KEY);
      if (!value) throw new Error("当前浏览器还没有保存的草稿。");
      setDraft(validateConfig(JSON.parse(value)));
      if (apiEnabled) {
        const base = localStorage.getItem(`${DRAFT_KEY}-revision`);
        if (base) {
          setServerRevision(base);
          setConflicted(base !== serverData.current?.revision);
        }
      }
      setDirty(false);
      setNotice({ text: "已恢复本机草稿，可继续编辑或导出。" });
    } catch (e) {
      setNotice({ text: message(e), error: true });
    }
  }
  function exportCsv() {
    try {
      const next = validateConfig({
        ...draft,
        version: Math.max(draft.version, deployed?.version ?? 0) + 1,
      });
      download(serializePricingCsv(next), "pricing.csv");
      setDraft(next);
      setDirty(false);
      setNotice({
        text: apiEnabled
          ? `已下载 v${next.version} 费用表备份，尚未发布到服务器。`
          : `已下载 v${next.version} 费用表。请上传覆盖网站目录中的 pricing.csv；下载不会直接修改线上价格。`,
      });
    } catch (e) {
      setNotice({ text: message(e), error: true });
    }
  }
  async function importCsv(file?: File) {
    if (!file) return;
    try {
      if (file.size > 1024 * 1024) throw new Error("费用表不能超过 1 MB。");
      const text = await file.text();
      setDraft(parsePricingCsv(text));
      setDirty(true);
      setNotice({ text: `已导入 ${file.name}，请核对费用后再导出发布。` });
    } catch (e) {
      setNotice({ text: message(e), error: true });
    } finally {
      if (fileRef.current) fileRef.current.value = "";
    }
  }
  return (
    <div className="admin-page">
      <div className="breadcrumb">
        <Link to="/quote">报价下单</Link>
        <ChevronRight size={12} />
        <b>费用表管理</b>
      </div>
      <div className="page-heading admin-heading">
        <div>
          <span className="eyebrow">PRICING WORKSPACE</span>
          <h1>
            费用设置<span className="admin-version">CSV</span>
          </h1>
          <p>
            {apiEnabled
              ? "五类费用，一张表管理。调整、试算，再发布到服务器。"
              : "五类费用，一张表管理。调整、试算，再上传发布。"}
          </p>
        </div>
        <Link to="/quote" className="button secondary">
          <ArrowLeft size={15} />
          返回报价页
        </Link>
      </div>
      <AdminSectionNav />
      <div className="workflow-banner">
        <div className="workflow-icon">
          <FileSpreadsheet size={23} />
        </div>
        <div>
          <b>
            {apiEnabled
              ? "编辑费用，确认后发布到服务器"
              : "用 Excel 管价格，静态网站也能运行"}
          </b>
          <p>
            {apiEnabled ? (
              "本地草稿和导出备份不会改变线上价格；发布成功后前台使用新版本。"
            ) : (
              <>
                编辑费用 <ArrowRight size={12} /> 下载 pricing.csv{" "}
                <ArrowRight size={12} /> 上传覆盖网站同名文件{" "}
                <ArrowRight size={12} /> 前台读取新价格
              </>
            )}
          </p>
        </div>
        <span>无需数据库</span>
      </div>
      <div className="admin-toolbar">
        <div className="file-info">
          <FileSpreadsheet size={20} />
          <div>
            <b>pricing.csv</b>
            <span>
              线上 v{deployed?.version ?? "—"} ·{" "}
              {dirty ? "有未导出的修改" : "本地编辑工作区"}
            </span>
          </div>
        </div>
        <div className="toolbar-actions">
          {apiEnabled && (
            <ServerPublishControls
              publish={publishPricing}
              reload={reloadServerPricing}
              loading={serverLoading}
              disabled={serverSaving}
              canPublish={!!serverRevision && !conflicted}
            />
          )}
          <input
            hidden
            ref={fileRef}
            type="file"
            accept=".csv,text/csv"
            aria-label="导入CSV费用表"
            onChange={(e) => void importCsv(e.target.files?.[0])}
          />
          <button
            className="button secondary"
            onClick={() => fileRef.current?.click()}
          >
            <Upload size={15} />
            导入费用表
          </button>
          <button className="button secondary" onClick={saveDraft}>
            <Save size={15} />
            保存本机草稿
          </button>
          <button className="button primary" onClick={exportCsv}>
            <Download size={15} />
            导出费用表
          </button>
        </div>
      </div>
      {notice && (
        <div
          role={notice.error ? "alert" : "status"}
          className={`notice ${notice.error ? "error" : "success"}`}
        >
          {notice.error ? <Info size={16} /> : <CheckCircle2 size={16} />}
          <span>{notice.text}</span>
          <button
            aria-label="关闭提示"
            className="icon-button"
            onClick={() => setNotice(null)}
          >
            <X size={16} />
          </button>
        </div>
      )}
      <div className="admin-layout">
        <aside className="admin-sidebar">
          <span className="nav-caption">费用分类</span>
          {categories.map((c) => (
            <button
              key={c.id}
              className={category === c.id ? "active" : ""}
              onClick={() => setCategory(c.id)}
            >
              <c.icon size={18} />
              <span>{c.name}</span>
              <ChevronRight size={14} />
            </button>
          ))}
          <div className="sidebar-divider" />
          <button onClick={loadDraft}>
            <FolderOpen size={17} />
            <span>恢复本机草稿</span>
          </button>
          <button
            onClick={() => {
              if (apiEnabled) {
                setNotice({
                  text: "请使用加载服务器最新版本，并确认替换草稿。",
                });
                return;
              }
              setDraft(structuredClone(deployed ?? defaultConfig));
              setDirty(false);
              setNotice({ text: "已还原当前页面加载的线上费用表。" });
            }}
          >
            <RefreshCw size={17} />
            <span>还原线上配置</span>
          </button>
          <div className="sidebar-note">
            <Info size={15} />
            <p>
              {apiEnabled
                ? "草稿仅在本机保存。确认费用后发布到服务器。"
                : "此页面是费用表编辑工具。草稿仅在本机保存，导出后需手动上传。"}
            </p>
          </div>
        </aside>
        <div className="admin-form-area">
          <section className="admin-form-card">
            <header>
              <div className="admin-category-icon">
                <meta.icon size={22} />
              </div>
              <div>
                <h2>{meta.name}</h2>
                <p>{meta.description}</p>
              </div>
              <span className="editable-tag">可编辑</span>
            </header>
            {category === "design" && (
              <div className="inline-info">
                <Info size={15} />
                <span>
                  自备文件不收设计费。下方初始值为 0，请按实际服务定价填写。
                </span>
              </div>
            )}
            {category === "paper" && (
              <label className="admin-text-field">
                纸张名称
                <input
                  aria-label="纸张名称"
                  type="text"
                  maxLength={50}
                  value={draft.paper.name}
                  onChange={(e) => change("paper", "name", e.target.value)}
                />
              </label>
            )}
            {category === "logistics" && (
              <label className="toggle-row">
                <span>
                  <b>启用快递配送</b>
                  <small>关闭时前台仅提供到店自提。</small>
                </span>
                <input
                  type="checkbox"
                  checked={draft.logistics.enabled}
                  onChange={(e) =>
                    change("logistics", "enabled", e.target.checked)
                  }
                />
                <span className="switch" />
              </label>
            )}
            {fieldGroups[category].map((group) => (
              <div className="admin-field-section" key={group.title}>
                <h3>{group.title}</h3>
                <div className="admin-fields">
                  {group.fields.map((field) => {
                    const raw = Number(
                      (draft[category] as unknown as Record<string, unknown>)[
                        field.key
                      ],
                    );
                    const value = field.percent
                      ? Number((raw * 100).toFixed(8))
                      : raw;
                    return (
                      <label className="admin-field" key={field.key}>
                        <span>{field.label}</span>
                        <span className="input-with-unit">
                          <input
                            aria-label={field.label}
                            type="number"
                            min={field.min ?? 0}
                            step={field.step ?? 0.01}
                            value={Number.isFinite(value) ? value : ""}
                            onChange={(e) =>
                              change(
                                category,
                                field.key,
                                e.target.value === ""
                                  ? NaN
                                  : Number(e.target.value) /
                                      (field.percent ? 100 : 1),
                              )
                            }
                          />
                          <span>{field.unit}</span>
                        </span>
                        {field.help && <small>{field.help}</small>}
                      </label>
                    );
                  })}
                </div>
              </div>
            ))}
            <CatalogSettings
              group={category}
              config={draft}
              onChange={(next) => {
                setDraft(next);
                setDirty(true);
                setNotice(null);
              }}
            />
            {category === "printing" && (
              <label className="admin-select-field">
                加印计费方式
                <select
                  aria-label="加印计费方式"
                  value={draft.printing.roundSteps ? "ceil" : "proportional"}
                  onChange={(e) =>
                    change("printing", "roundSteps", e.target.value === "ceil")
                  }
                >
                  <option value="ceil">按整档进位（不足一档按一档）</option>
                  <option value="proportional">按实际印数比例</option>
                </select>
                <small>
                  例如 500 张加放 5% 后为 525 印，整档模式会计入一个加印档。
                </small>
              </label>
            )}
            {category === "finishing" && (
              <div className="formula-note">
                <b>费用如何计算？</b>
                <p>
                  覆膜按大纸面积计；烫金按每张实际图案面积计。异形模切、压纹、击凸、压凹共用一次基础版费，再累计已选工艺的附加版费。
                </p>
              </div>
            )}
            {category === "logistics" && (
              <div className="formula-note">
                <b>重量与运费</b>
                <p>
                  成品净面积 × 克重 × 总张数 ÷ 1000 + 包装重量 =
                  计费重量（kg）。超首重部分向上取整到公斤，基础运费再乘配送区域系数。
                </p>
              </div>
            )}
          </section>
          <section className="publishing-card">
            <div className="section-title">
              <h2>
                <span />
                销售与发布
              </h2>
              <span
                className={draft.published ? "published-badge" : "draft-badge"}
              >
                {draft.published ? "导出表将开放报价" : "未开放报价"}
              </span>
            </div>
            <div className="publish-fields">
              <label className="admin-field">
                <span>
                  成本加价率 <em>必填</em>
                </span>
                <span className="input-with-unit">
                  <input
                    aria-label="成本加价率"
                    type="number"
                    min="0"
                    max="1000"
                    step="0.1"
                    value={
                      draft.markup === null
                        ? ""
                        : Number((draft.markup * 100).toFixed(8))
                    }
                    placeholder="请填写"
                    onChange={(e) => {
                      setDraft((d) => ({
                        ...d,
                        markup:
                          e.target.value === ""
                            ? null
                            : Number(e.target.value) / 100,
                      }));
                      setDirty(true);
                    }}
                  />
                  <span>%</span>
                </span>
                <small>成本加价，不是毛利率。例如 30% 表示成本 × 1.3。</small>
              </label>
              <label className="toggle-row">
                <span>
                  <b>开放前台报价</b>
                  <small>填写加价率并上传导出的表后生效。</small>
                </span>
                <input
                  aria-label="开放前台报价"
                  type="checkbox"
                  checked={draft.published}
                  onChange={(e) => {
                    setDraft((d) => ({ ...d, published: e.target.checked }));
                    setDirty(true);
                  }}
                />
                <span className="switch" />
              </label>
            </div>
            <div className="publish-footnote">
              <Info size={14} />
              <span>
                {apiEnabled
                  ? "这里的修改先保留在草稿，点击发布到服务器后生效。"
                  : "线上页面只读取上传的 CSV；这里的修改不会自动发布。"}
              </span>
            </div>
          </section>
        </div>
        <aside className="admin-preview">
          <div className="preview-card">
            <header>
              <span className="preview-icon">
                <Printer size={19} />
              </span>
              <h2>实时成本试算</h2>
              <span className="live-dot" />
            </header>
            <div className="preview-spec">
              <b>90 × 54 mm 定制插卡</b>
              <span>
                {draft.paper.gsm}g {draft.paper.name} · 双面彩色
              </span>
              <span>500 张 / 款 · 1 款 · 不覆膜 · 普通裁切</span>
              <span>自备文件 · 到店自提</span>
            </div>
            {preview.result ? (
              <>
                <dl className="cost-list">
                  {(
                    [
                      ["设计费", preview.result.cost.design],
                      ["印刷费", preview.result.cost.printing],
                      ["纸张费", preview.result.cost.paper],
                      ["后道工艺费", preview.result.cost.finishing],
                      ["物流费", preview.result.cost.logistics],
                    ] as [string, number][]
                  ).map(([label, v]) => (
                    <div key={label}>
                      <dt>{label}</dt>
                      <dd>¥ {money(v)}</dd>
                    </div>
                  ))}
                </dl>
                <div className="preview-total">
                  <span>测算成本</span>
                  <b>¥ {money(preview.result.cost.total)}</b>
                </div>
                <div className="preview-sale">
                  <span>
                    {draft.markup === null
                      ? "销售价尚未设置"
                      : "加价后试算金额"}
                  </span>
                  <strong>
                    {draft.markup === null
                      ? "—"
                      : `¥ ${money(preview.result.total)}`}
                  </strong>
                </div>
                <div className="imposition-info">
                  <div>
                    <span>自动拼数</span>
                    <b>{preview.result.cost.imposition} 拼</b>
                  </div>
                  <div>
                    <span>分摊款数</span>
                    <b>{preview.result.cost.shareCount} 款</b>
                  </div>
                </div>
                <p className="preview-hint">
                  本例用于核对基础费率。其他设计、工艺和物流选项请在下方完整试算中查看。
                </p>
              </>
            ) : (
              <div className="notice error" role="alert">
                {preview.error}
              </div>
            )}
          </div>
          <div className="admin-help-card">
            <Package size={20} />
            <h3>准备发布？</h3>
            <ol>
              <li>检查五类费用和加价率</li>
              <li>勾选“开放前台报价”</li>
              <li>
                {apiEnabled ? "点击发布到服务器" : "导出并上传 pricing.csv"}
              </li>
              <li>重新读取费用表验证</li>
            </ol>
            <button
              className="button secondary"
              onClick={() => void onReload()}
            >
              <RefreshCw size={14} />
              重新读取线上费用表
            </button>
          </div>
        </aside>
      </div>
      <CostSandbox config={draft} />
      <div className="admin-bottom-note">
        <FileSpreadsheet size={17} />
        <p>
          在 Excel 中编辑时，保留字段标识和表头，使用{" "}
          <b>CSV UTF-8（逗号分隔）</b> 格式保存。
          {apiEnabled
            ? "导出文件用于备份或再次导入；服务器配置接口公开提供报价所需费用。"
            : "静态费用表为公开文件，不适合存放需要保密的成本。"}
        </p>
        <button
          className="text-button"
          onClick={() =>
            download(serializePricingCsv(defaultConfig), "pricing-template.csv")
          }
        >
          下载初始模板
          <Download size={14} />
        </button>
      </div>
    </div>
  );
}

function CostSandbox({ config }: { config: PricingConfig }) {
  const [quantity, setQuantity] = useState(500);
  const [foil, setFoil] = useState(false);
  const [die, setDie] = useState(false);
  const [lamination, setLamination] = useState<0 | 1 | 2>(0);
  const [design, setDesign] = useState<"provided" | "adjust" | "custom">(
    "provided",
  );
  const [shipping, setShipping] = useState<"pickup" | "express">("pickup");
  const [region, setRegion] = useState<"local" | "national" | "remote">(
    "local",
  );
  const result = useMemo(() => {
    try {
      return {
        quote: calculateQuote(
          {
            ...defaultInput,
            quantity,
            lamination,
            cutting: die ? "die" : "straight",
            crafts: foil ? ["foil"] : [],
            design,
            shipping,
            region,
          },
          config,
          { preview: true },
        ),
        error: "",
      };
    } catch (e) {
      return { quote: null, error: message(e) };
    }
  }, [config, quantity, foil, die, lamination, design, shipping, region]);
  return (
    <section className="sandbox">
      <div className="section-title">
        <h2>
          <span />
          组合费用试算
        </h2>
        <span className="section-meta">
          使用当前未发布草稿 · 90 × 54 mm · 1 款
        </span>
      </div>
      <div className="sandbox-controls">
        <label>
          每款数量
          <input
            aria-label="试算数量"
            type="number"
            min="1"
            value={quantity || ""}
            onChange={(e) => setQuantity(Number(e.target.value))}
          />
        </label>
        <label>
          设计服务
          <select
            aria-label="试算设计服务"
            value={design}
            onChange={(e) => setDesign(e.target.value as typeof design)}
          >
            <option value="provided">自备文件</option>
            <option value="adjust">文件调整</option>
            <option value="custom">定制设计</option>
          </select>
        </label>
        <label>
          覆膜
          <select
            aria-label="试算覆膜"
            value={lamination}
            onChange={(e) => setLamination(Number(e.target.value) as 0 | 1 | 2)}
          >
            <option value="0">不覆膜</option>
            <option value="1">单面覆膜</option>
            <option value="2">双面覆膜</option>
          </select>
        </label>
        <label>
          配送
          <select
            aria-label="试算配送"
            value={shipping}
            onChange={(e) => setShipping(e.target.value as typeof shipping)}
          >
            <option value="pickup">自提</option>
            <option value="express" disabled={!config.logistics.enabled}>
              快递
            </option>
          </select>
        </label>
        <label>
          区域
          <select
            aria-label="试算配送区域"
            value={region}
            onChange={(e) => setRegion(e.target.value as typeof region)}
          >
            <option value="local">本地</option>
            <option value="national">常规</option>
            <option value="remote">偏远</option>
          </select>
        </label>
        <label className="check-field">
          <input
            type="checkbox"
            checked={foil}
            onChange={(e) => setFoil(e.target.checked)}
          />
          烫金 10cm² / 张
        </label>
        <label className="check-field">
          <input
            type="checkbox"
            checked={die}
            onChange={(e) => setDie(e.target.checked)}
          />
          异形模切
        </label>
      </div>
      {result.quote ? (
        <div className="sandbox-result">
          <span>
            生产 + 设计成本{" "}
            <b>
              ¥ {money(result.quote.cost.total - result.quote.cost.logistics)}
            </b>
          </span>
          <span>
            物流 <b>¥ {money(result.quote.shippingTotal)}</b>
          </span>
          <span>
            试算合计 <strong>¥ {money(result.quote.total)}</strong>
            {config.markup === null && <small>（未设置加价）</small>}
          </span>
        </div>
      ) : (
        <p className="form-error" role="alert">
          {result.error}
        </p>
      )}
    </section>
  );
}
