import { Fragment, useEffect, useRef, useState, type ReactNode } from "react";
import { Link, useLocation } from "react-router-dom";
import { HelpCircle, FileText, RotateCcw } from "lucide-react";
import type {
  AdminQuote,
  CraftId,
  PricingConfig,
  QuoteInput,
  ProductReference,
} from "../shared/contracts";
import { defaultInput } from "../shared/contracts";
import {
  extraGroups,
  coatingIds,
  type ExtraId,
  type MaterialId,
} from "../shared/catalog";
import { calculateQuote } from "../lib/pricing";
import { message, money } from "./utils";
import QuoteDialog from "./QuoteDialog";
import OrderDetails, { type OrderGateway } from "./order/OrderDetails";
import "./reference.css";
import { apiEnabled, apiRequest } from "./api/client";
import { useSession } from "./api/SessionContext";
import { apiOrderGateway } from "./order/apiGateway";
import type { ServerQuote } from "../shared/api";
function Row({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="reference-row">
      <div className="reference-label">{label}</div>
      <div className="reference-content">{children}</div>
    </div>
  );
}
function Option({
  name,
  checked,
  onChange,
  disabled = false,
  hint,
}: {
  name: string;
  checked: boolean;
  onChange: () => void;
  disabled?: boolean;
  hint?: string;
}) {
  return (
    <label
      className={`reference-option ${disabled ? "unavailable" : ""}`}
      title={hint}
    >
      <input
        type="checkbox"
        checked={checked}
        onChange={onChange}
        disabled={disabled}
      />
      <span>{name}</span>
      {hint && <HelpCircle aria-label={hint} size={16} />}
    </label>
  );
}
const craftNames: Record<CraftId, string> = {
  foil: "热烫",
  texture: "压纹",
  emboss: "击凸",
  deboss: "压凹",
};
const designNames = {
  provided: "自备设计文件",
  adjust: "文件调整",
  custom: "定制设计",
};
export default function QuotePage({
  config,
  orderGateway,
  product,
}: {
  config: PricingConfig;
  orderGateway?: OrderGateway;
  product?: ProductReference;
}) {
  const [input, setInput] = useState<QuoteInput>(() =>
    structuredClone(defaultInput),
  );
  const [calculated, setCalculated] = useState<{
    quote: AdminQuote;
    signature: string;
  } | null>(null);
  const [error, setError] = useState("");
  const [dialog, setDialog] = useState(false);
  const [orderPending, setOrderPending] = useState(false);
  const [calculating, setCalculating] = useState(false);
  const quoteRequest = useRef<AbortController | null>(null);
  const session = useSession();
  const [tab, setTab] = useState<"details" | "guide">("details");
  const location = useLocation();
  useEffect(() => {
    if (location.hash === "#guide") setTab("guide");
    else if (location.hash === "#details") setTab("details");
  }, [location.hash]);
  const signature = JSON.stringify([
    input,
    config,
    product,
    apiEnabled ? session.user?.id : null,
  ]);
  useEffect(() => {
    setCalculating(false);
    return () => quoteRequest.current?.abort();
  }, [signature]);
  const quote = calculated?.signature === signature ? calculated.quote : null;
  function patch(update: Partial<QuoteInput>) {
    if (orderPending) return;
    setCalculated(null);
    setInput((current) => ({ ...current, ...update }));
    setError("");
    setDialog(false);
  }
  function toggleExtra(id: ExtraId) {
    const selected = input.extras.includes(id);
    let extras = selected
      ? input.extras.filter((x) => x !== id)
      : [...input.extras, id];
    const update: Partial<QuoteInput> = {};
    if (coatingIds.includes(id)) {
      extras = extras.filter((x) => !coatingIds.includes(x) || x === id);
      update.lamination = selected ? 0 : input.sides;
    }
    if (["premiumDie", "circle", "roundCorners"].includes(id) && !selected)
      update.cutting = "die";
    if (id === "circle" && !selected) {
      update.width = input.circleDiameter;
      update.height = input.circleDiameter;
    }
    patch({ ...update, extras });
  }
  const extraOption = (id: ExtraId, name: string) => {
    const available =
      config.extras[id].enabled && config.extras[id].rate !== null;
    return (
      <Option
        key={id}
        name={name}
        checked={input.extras.includes(id)}
        onChange={() => toggleExtra(id)}
        disabled={!available}
        hint={!available ? "待配置：请在后台启用并填写加工费" : undefined}
      />
    );
  };
  const craftOption = (id: CraftId) => (
    <Option
      key={id}
      name={craftNames[id]}
      checked={input.crafts.includes(id)}
      onChange={() =>
        patch({
          crafts: input.crafts.includes(id)
            ? input.crafts.filter((x) => x !== id)
            : [...input.crafts, id],
        })
      }
    />
  );
  function calculate() {
    if (apiEnabled) {
      void calculateOnServer();
      return;
    }
    try {
      const result = calculateQuote(input, config);
      setCalculated({
        quote: product
          ? { ...result, product: structuredClone(product) }
          : result,
        signature,
      });
      setError("");
    } catch (e) {
      setCalculated(null);
      setError(message(e));
    }
  }
  async function calculateOnServer() {
    quoteRequest.current?.abort();
    const controller = new AbortController();
    quoteRequest.current = controller;
    setCalculating(true);
    setCalculated(null);
    setError("");
    try {
      const result = await apiRequest<ServerQuote>("/quotes", {
        method: "POST",
        signal: controller.signal,
        body: JSON.stringify({
          input,
          ...(product ? { productId: product.id } : {}),
        }),
      });
      if (!controller.signal.aborted)
        setCalculated({ quote: result, signature });
    } catch (e) {
      if (!controller.signal.aborted) setError(message(e));
    } finally {
      if (!controller.signal.aborted) setCalculating(false);
    }
  }
  const materials = [
    {
      id: "market300",
      name: `市场${config.paper.gsm}克${config.paper.name}`,
      enabled: true,
    },
    ...Object.entries(config.materials).map(([id, m]) => ({
      id,
      name: m.name,
      enabled: m.enabled && m.tonPrice !== null,
    })),
  ];
  return (
    <div className="reference-page">
      {product && (
        <div className="quote-product-context">
          <div>
            <strong>当前产品：{product.name}</strong>
            <span>
              产品编号 {product.code} · {product.categoryName}
            </span>
          </div>
          <Link to={`/products/${product.id}`}>查看产品资料</Link>
          <p>以下报价基于你选择的规格和工艺，请核对后再计算。</p>
        </div>
      )}
      <fieldset
        className="reference-specifications"
        disabled={orderPending || calculating}
        aria-label="报价规格"
      >
        <div className="reference-heading">
          <div>
            <span>定制印刷 / 卡片</span>
            <h1>异形单张 · 定制插卡</h1>
          </div>
          <button
            type="button"
            className="button secondary"
            onClick={() => {
              patch(structuredClone(defaultInput));
              setCalculated(null);
            }}
          >
            <RotateCcw size={15} />
            重置规格
          </button>
        </div>
        {!config.published && (
          <div className="reference-notice" role="status">
            费用表尚未发布，可先选择产品规格。
            <Link to="/admin">前往后台设置费用</Link>
          </div>
        )}
        <section className="reference-section">
          <h2 className="reference-title">产品信息</h2>
          <Row label="材料">
            <div className="reference-materials">
              {materials.map((m) => (
                <button
                  type="button"
                  key={m.id}
                  aria-pressed={input.material === m.id}
                  disabled={!m.enabled}
                  title={
                    !m.enabled ? "待配置：请在后台填写材料价格" : undefined
                  }
                  className={input.material === m.id ? "selected" : ""}
                  onClick={() => patch({ material: m.id as MaterialId })}
                >
                  {m.name}
                  <HelpCircle size={16} />
                </button>
              ))}
            </div>
          </Row>
          <Row label="尺寸(MM)">
            <input
              aria-label="成品宽度"
              className="reference-dimension"
              type="number"
              min="1"
              placeholder="长边"
              value={Number.isFinite(input.width) ? input.width : ""}
              onChange={(e) =>
                patch({
                  width: e.target.value === "" ? NaN : Number(e.target.value),
                })
              }
            />
            <span>×</span>
            <input
              aria-label="成品高度"
              className="reference-dimension"
              type="number"
              min="1"
              placeholder="短边"
              value={Number.isFinite(input.height) ? input.height : ""}
              onChange={(e) =>
                patch({
                  height: e.target.value === "" ? NaN : Number(e.target.value),
                })
              }
            />
            {input.extras.includes("circle") && (
              <span className="reference-hint">圆形成品的长宽需与直径一致</span>
            )}
          </Row>
          <Row label="印面">
            {([2, 1] as const).map((s) => (
              <label className="reference-option" key={s}>
                <input
                  type="radio"
                  name="sides"
                  checked={input.sides === s}
                  onChange={() =>
                    patch({
                      sides: s,
                      lamination: Math.min(input.lamination, s) as 0 | 1 | 2,
                    })
                  }
                />
                {s === 2 ? "双面" : "单面"}
              </label>
            ))}
          </Row>
          <Row label="印色">
            <label className="reference-option">
              <input
                type="radio"
                name="ink"
                checked={input.ink === "cmyk"}
                onChange={() => patch({ ink: "cmyk" })}
              />
              彩色
            </label>
            <label
              className={`reference-option ${!config.spotInk.enabled || config.spotInk.rate === null ? "unavailable" : ""}`}
              title={
                !config.spotInk.enabled || config.spotInk.rate === null
                  ? "待配置：请在后台填写专色费用"
                  : undefined
              }
            >
              <input
                type="radio"
                name="ink"
                checked={input.ink === "spot"}
                disabled={
                  !config.spotInk.enabled || config.spotInk.rate === null
                }
                onChange={() => patch({ ink: "spot" })}
              />
              四色加1专
              <HelpCircle size={16} />
            </label>
          </Row>
          {extraGroups.map((group) => (
            <Fragment key={group.id}>
              <Row label={group.label}>
                {group.id === "common" && (
                  <Option
                    name="模切"
                    checked={input.cutting === "die"}
                    onChange={() =>
                      patch(
                        input.cutting === "die"
                          ? {
                              cutting: "straight",
                              extras: input.extras.filter(
                                (x) =>
                                  ![
                                    "premiumDie",
                                    "circle",
                                    "roundCorners",
                                  ].includes(x),
                              ),
                            }
                          : { cutting: "die" },
                      )
                    }
                  />
                )}
                {group.id === "special" &&
                  (["texture", "emboss", "deboss"] as CraftId[]).map(
                    craftOption,
                  )}
                {group.items.map(([id, name]) => (
                  <span className="reference-option-wrap" key={id}>
                    {extraOption(id, name)}
                    {id === "circle" && input.extras.includes("circle") && (
                      <select
                        aria-label="圆形直径"
                        value={input.circleDiameter}
                        onChange={(e) => {
                          const d = Number(e.target.value);
                          patch({ circleDiameter: d, width: d, height: d });
                        }}
                      >
                        {[30, 40, 50, 60, 70, 80, 90, 100].map((d) => (
                          <option value={d} key={d}>
                            {d}mm圆形
                          </option>
                        ))}
                      </select>
                    )}
                  </span>
                ))}
                {group.id === "coating" &&
                  input.extras.some((x) => coatingIds.includes(x)) && (
                    <label className="reference-inline">
                      加工面数
                      <select
                        aria-label="覆膜加工面数"
                        value={input.lamination}
                        onChange={(e) =>
                          patch({ lamination: Number(e.target.value) as 1 | 2 })
                        }
                      >
                        <option value={1}>单面</option>
                        {input.sides === 2 && <option value={2}>双面</option>}
                      </select>
                    </label>
                  )}
              </Row>
              {group.id === "shape" && (
                <Row label="烫金工艺">
                  {craftOption("foil")}
                  {input.crafts.includes("foil") && (
                    <label className="reference-inline">
                      每张烫金面积
                      <input
                        aria-label="每张烫金面积"
                        type="number"
                        min="0.01"
                        step="0.1"
                        value={
                          Number.isFinite(input.foilArea) ? input.foilArea : ""
                        }
                        onChange={(e) =>
                          patch({
                            foilArea:
                              e.target.value === ""
                                ? NaN
                                : Number(e.target.value),
                          })
                        }
                      />
                      cm²
                    </label>
                  )}
                </Row>
              )}
            </Fragment>
          ))}
          <Row label="设计服务">
            {Object.entries(designNames).map(([value, label]) => (
              <label className="reference-option" key={value}>
                <input
                  type="radio"
                  name="design"
                  checked={input.design === value}
                  onChange={() =>
                    patch({ design: value as QuoteInput["design"] })
                  }
                />
                {label}
              </label>
            ))}
          </Row>
          <Row label="款数">
            <input
              aria-label="购买款数"
              className="reference-variants"
              type="number"
              min="1"
              step="1"
              value={Number.isFinite(input.variants) ? input.variants : ""}
              onChange={(e) =>
                patch({
                  variants:
                    e.target.value === "" ? NaN : Number(e.target.value),
                })
              }
            />
            <span className="reference-hint">
              不同图案分别计款，每款数量相同
            </span>
          </Row>
          <p className="reference-config-note">
            灰色选项尚未设置费用；可在费用表管理中逐项启用。
          </p>
        </section>
        <section className="reference-section">
          <h2 className="reference-title">产品算价</h2>
          <div className="reference-quantity">
            <span>单款数量(张)</span>
            {[500, 1000, 2000, 3000, 5000].map((n) => (
              <button
                type="button"
                aria-pressed={input.quantity === n}
                className={input.quantity === n ? "selected" : ""}
                key={n}
                onClick={() => patch({ quantity: n })}
              >
                {n}
              </button>
            ))}
            <label>
              <span>自定义:</span>
              <input
                aria-label="每款交付数量"
                type="number"
                min="1"
                step="1"
                value={Number.isFinite(input.quantity) ? input.quantity : ""}
                onChange={(e) =>
                  patch({
                    quantity:
                      e.target.value === "" ? NaN : Number(e.target.value),
                  })
                }
              />
            </label>
            <button
              type="button"
              className="calculate-button"
              disabled={!config.published || (apiEnabled && session.loading)}
              onClick={calculate}
            >
              {calculating ? "算价中…" : "算价"}
            </button>
          </div>
          {error && (
            <p className="reference-error" role="alert">
              {error}
            </p>
          )}
          <div className="reference-result" aria-live="polite">
            <div>
              <span className="reference-hint">
                {quote ? "订单预估总价" : "选择规格与数量后点击算价"}
              </span>
              <div className="reference-price">
                {quote ? (
                  <>
                    <small>¥</small>
                    <strong>{money(quote.total)}</strong>
                    <span>
                      共 {quote.totalQuantity} 张 · ¥
                      {quote.unitPrice.toFixed(4)} / 张
                    </span>
                  </>
                ) : (
                  <strong>—</strong>
                )}
              </div>
              {quote && (
                <p>
                  制作费 ¥{money(quote.productionTotal)}　设计费 ¥
                  {money(quote.designTotal)}　物流费 ¥
                  {money(quote.shippingTotal)}
                </p>
              )}
            </div>
            <button
              type="button"
              className="button secondary"
              disabled={!quote}
              onClick={() => setDialog(true)}
            >
              <FileText size={16} />
              生成报价单
            </button>
          </div>
          <p className="reference-hint">
            报价按合版条件测算；税费及其他未列费用需另行确认。修改规格或配送方式后请重新算价。
          </p>
          {apiEnabled && quote && (
            <p className="reference-hint">
              {quote.tier} · 制作费按{" "}
              {(quote.discount * 100).toFixed(2).replace(/\.00$/, "")}% 计价 ·
              报价有效至{" "}
              {new Date(quote.expiresAt!).toLocaleTimeString("zh-CN")}
            </p>
          )}
        </section>
      </fieldset>
      <OrderDetails
        key={apiEnabled ? (session.user?.id ?? "guest") : "static"}
        quote={quote}
        shipping={input.shipping}
        region={input.region}
        logisticsEnabled={config.logistics.enabled}
        onDeliveryChange={patch}
        gateway={
          orderGateway ??
          (apiEnabled && session.user?.role === "member"
            ? apiOrderGateway
            : undefined)
        }
        unavailableMessage={
          apiEnabled
            ? session.user?.role === "staff"
              ? "员工账号用于后台管理，请使用会员账号下单。"
              : "请先登录会员账号，再重新算价并提交订单。"
            : undefined
        }
        addressStorageKey={
          apiEnabled
            ? session.user?.role === "member"
              ? `kaku-addresses-${session.user.id}`
              : null
            : undefined
        }
        onPendingChange={setOrderPending}
      />
      {apiEnabled && (
        <p className="reference-hint">
          <Link to={session.user ? "/orders" : "/login"}>
            {session.user ? "查看我的订单" : "登录会员账号"}
          </Link>
        </p>
      )}
      <section className="reference-information" id="details">
        <div className="reference-tabs">
          <button
            className={tab === "details" ? "active" : ""}
            onClick={() => setTab("details")}
          >
            印品介绍
          </button>
          <button
            className={tab === "guide" ? "active" : ""}
            onClick={() => setTab("guide")}
          >
            文件规范
          </button>
        </div>
        <div className="reference-wave" />
        <div className="reference-info-content" id="guide">
          <h2>
            {tab === "details"
              ? "让每一张卡片，恰到好处"
              : "好的印品，从文件开始"}
          </h2>
          {tab === "details" ? (
            <>
              <p>品牌插卡、产品吊牌、感谢卡，按你的尺寸与图案定制。</p>
              <div className="reference-info-grid">
                <article>
                  <b>01 / 选材料</b>
                  <p>选择克重与纸张，再填写成品尺寸。</p>
                </article>
                <article>
                  <b>02 / 选工艺</b>
                  <p>覆膜、模切、烫金与包装可按需组合。</p>
                </article>
                <article>
                  <b>03 / 核对制作</b>
                  <p>核对款数、数量、文件与收货资料后下单。</p>
                </article>
              </div>
            </>
          ) : (
            <div className="reference-info-grid">
              <article>
                <b>尺寸与出血</b>
                <p>
                  文件按成品尺寸制作，四周预留 3mm 出血；重要文字避开裁切边。
                </p>
              </article>
              <article>
                <b>色彩与文字</b>
                <p>使用 CMYK 色彩模式，图片建议 300dpi，文字转曲或嵌入字体。</p>
              </article>
              <article>
                <b>工艺与对稿</b>
                <p>模切、烫金、UV 等工艺单独标注，并提供对应对稿图。</p>
              </article>
            </div>
          )}
        </div>
      </section>
      {dialog && quote && (
        <QuoteDialog
          quote={quote}
          config={config}
          onClose={() => setDialog(false)}
        />
      )}
    </div>
  );
}
