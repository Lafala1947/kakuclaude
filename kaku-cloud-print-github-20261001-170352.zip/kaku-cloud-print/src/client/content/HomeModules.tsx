import type { ReactNode } from "react";
import { Link } from "react-router-dom";
import {
  ArrowUpRight,
  ArrowRight,
  Ruler,
  Layers3,
  Files,
  ReceiptText,
  Scissors,
  FileCheck2,
  UserRound,
} from "lucide-react";
import type { HomeModule } from "../../shared/homepage";
import CardArtwork from "./CardArtwork";
import { FeaturedProducts } from "../products/ProductCatalog";

function ContentLink({
  href,
  children,
  className,
}: {
  href: string;
  children: ReactNode;
  className?: string;
}) {
  return href.startsWith("/") ? (
    <Link to={href} className={className}>
      {children}
    </Link>
  ) : (
    <a href={href} className={className}>
      {children}
    </a>
  );
}
function Action({
  module: m,
  secondary = false,
  className = "home-text-link",
}: {
  module: HomeModule;
  secondary?: boolean;
  className?: string;
}) {
  const label = secondary ? m.secondaryLabel : m.actionLabel,
    href = secondary ? m.secondaryHref : m.actionHref;
  return label && href ? (
    <ContentLink href={href} className={className}>
      {label}
      <ArrowUpRight size={18} />
    </ContentLink>
  ) : null;
}
function Heading({ m }: { m: HomeModule }) {
  return (
    <div className="home-section-heading">
      <div>
        <span className="home-eyebrow">{m.eyebrow}</span>
        <h2>{m.title}</h2>
        {m.text && <p className="cms-text">{m.text}</p>}
      </div>
      <Action module={m} />
    </div>
  );
}
function Image({ m, hero = false }: { m: HomeModule; hero?: boolean }) {
  return m.image ? (
    <figure className={hero ? "home-hero-art" : "cms-module-image"}>
      <img
        src={
          m.image.startsWith("assets/")
            ? `${import.meta.env.BASE_URL}${m.image}`
            : m.image
        }
        alt={m.imageAlt}
        loading={hero ? undefined : "lazy"}
        fetchPriority={hero ? "high" : undefined}
      />
      {m.note && <figcaption>{m.note}</figcaption>}
    </figure>
  ) : null;
}
export default function HomeModuleView({
  module: m,
  first = false,
}: {
  module: HomeModule;
  first?: boolean;
}) {
  const icons = [Ruler, Layers3, Files, ReceiptText];
  const Title = first ? "h1" : "h2";
  switch (m.type) {
    case "catalog":
      return (
        <section className="home-products" id={m.id}>
          <Heading m={m} />
          <FeaturedProducts />
        </section>
      );
    case "hero":
      return (
        <section className="home-hero" id={m.id}>
          <div className="home-hero-copy">
            <div className="home-eyebrow">
              <span />
              {m.eyebrow}
            </div>
            <Title className="cms-hero-title">{m.title}</Title>
            <p className="cms-text">{m.text}</p>
            <div className="home-hero-actions">
              <Action module={m} className="home-action dark" />
              <Action module={m} secondary />
            </div>
            <div className="home-hero-footnote">
              <div className="home-cmyk" aria-label="CMYK 印刷四色">
                <span>C</span>
                <span>M</span>
                <span>Y</span>
                <span>K</span>
              </div>
              <span>材质 · 色彩 · 工艺</span>
            </div>
          </div>
          <Image m={m} hero />
        </section>
      );
    case "services":
      return (
        <section className="cms-services" id={m.id} aria-label={m.title}>
          <div className="home-service-strip">
            {m.items.map((item, i) => {
              const Icon = icons[i % icons.length];
              return (
                <div key={item.id}>
                  <Icon size={22} strokeWidth={1.4} />
                  <div>
                    <b>{item.title}</b>
                    <span>{item.text}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      );
    case "products":
      return (
        <section className="home-products" id={m.id}>
          <Heading m={m} />
          <div className="home-product-grid">
            {m.items.map((item) => {
              const body = (
                <>
                  <CardArtwork kind={item.kind} />
                  <div className="home-product-info">
                    <span className="home-product-en">{item.eyebrow}</span>
                    <h3>
                      {item.title}
                      {item.actionHref && <ArrowUpRight size={22} />}
                    </h3>
                    <p>{item.text}</p>
                    <div className="home-product-tags">
                      {item.tags
                        .split("、")
                        .filter(Boolean)
                        .map((t, i) => (
                          <span key={i}>{t}</span>
                        ))}
                    </div>
                  </div>
                  {item.actionLabel && item.actionHref && (
                    <span className="cms-product-action">
                      {item.actionLabel}
                    </span>
                  )}
                </>
              );
              return item.actionHref ? (
                <ContentLink
                  href={item.actionHref}
                  className="home-product"
                  key={item.id}
                >
                  {body}
                </ContentLink>
              ) : (
                <article className="home-product" key={item.id}>
                  {body}
                </article>
              );
            })}
          </div>
          <p className="home-product-note">{m.note}</p>
        </section>
      );
    case "process":
      return (
        <section className="home-process" id={m.id}>
          <Heading m={m} />
          <div className="home-step-grid">
            {m.items.map((item, i) => {
              const Icon = [Ruler, Scissors, ReceiptText][i % 3];
              return (
                <article key={item.id}>
                  <div className="home-step-top">
                    <span>{String(i + 1).padStart(2, "0")}</span>
                    <Icon size={26} strokeWidth={1.3} />
                  </div>
                  <h3>{item.title}</h3>
                  <p>{item.text}</p>
                </article>
              );
            })}
          </div>
          <div className="home-cost-strip">
            <div>
              <ReceiptText size={18} />
              <b>{m.note}</b>
            </div>
            <div>
              {["设计费", "印刷费", "纸张费", "后道工艺费", "物流费"].map(
                (t) => (
                  <span key={t}>{t}</span>
                ),
              )}
            </div>
          </div>
        </section>
      );
    case "resources":
      return (
        <section className="home-bottom-grid" id={m.id} aria-label={m.title}>
          {m.items.map((item, i) => (
            <article
              className={i % 2 ? "home-member-guide" : "home-file-guide"}
              key={item.id}
            >
              <span className="home-small-icon">
                {i % 2 ? <UserRound size={24} /> : <FileCheck2 size={24} />}
              </span>
              <div className="cms-resource-content">
                <span className="home-eyebrow">{item.eyebrow}</span>
                <h2>{item.title}</h2>
                <p>{item.text}</p>
                <div className="home-guide-points">
                  {item.tags
                    .split("、")
                    .filter(Boolean)
                    .map((t, j) => (
                      <span key={j}>{t}</span>
                    ))}
                </div>
                {item.actionLabel && item.actionHref && (
                  <ContentLink
                    href={item.actionHref}
                    className="home-text-link"
                  >
                    {item.actionLabel}
                    <ArrowUpRight size={17} />
                  </ContentLink>
                )}
              </div>
            </article>
          ))}
        </section>
      );
    case "cta":
      return (
        <section className="home-final-cta" id={m.id}>
          <div>
            <span className="home-eyebrow">{m.eyebrow}</span>
            <h2>{m.title}</h2>
            <p className="cms-text">{m.text}</p>
          </div>
          <Action module={m} className="home-action dark" />
        </section>
      );
    default:
      return (
        <section className="home-products cms-custom-module" id={m.id}>
          <Heading m={m} />
          <Image m={m} />
          {!m.image && m.note && <p>{m.note}</p>}
          <Action module={m} secondary />
          {m.items.map((item) => (
            <article key={item.id}>
              <h3>{item.title}</h3>
              <p className="cms-text">{item.text}</p>
              {item.actionHref && (
                <ContentLink href={item.actionHref}>
                  {item.actionLabel}
                  <ArrowRight size={16} />
                </ContentLink>
              )}
            </article>
          ))}
        </section>
      );
  }
}
