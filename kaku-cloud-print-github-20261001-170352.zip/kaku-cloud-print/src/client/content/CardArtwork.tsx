export default function CardArtwork({
  kind,
}: {
  kind: "insert" | "thanks" | "shape";
}) {
  return (
    <div
      className={`home-product-art ${kind}`}
      role="img"
      aria-label={
        {
          insert: "包装插卡版式示意：白色品牌卡与青蓝底卡",
          thanks: "感谢卡版式示意：洋红色卡片上的感谢文字",
          shape: "异形卡片版式示意：圆形标签与圆角卡片",
        }[kind]
      }
    >
      <div className="home-art-grid" />
      <div className="home-demo-card back" />
      {kind === "shape" ? (
        <>
          <div className="home-shape-round">
            hello<span>GOOD TO SEE YOU</span>
          </div>
          <div className="home-shape-tag">
            <i />
            MADE
            <br />
            FOR YOU<small>为你，特别定制</small>
          </div>
        </>
      ) : (
        <div className="home-demo-card front">
          <small>
            {kind === "insert" ? "A NOTE INSIDE" : "A LITTLE THANK YOU"}
          </small>
          <strong>
            {kind === "insert" ? (
              <>
                a little
                <br />
                goodness.
              </>
            ) : (
              <>
                Thank
                <br />
                you.
              </>
            )}
          </strong>
          <span>
            {kind === "insert"
              ? "每一次打开，都有好心意。"
              : "谢谢你，选择我们。"}
          </span>
        </div>
      )}
      <span className="home-art-caption">版式示意</span>
    </div>
  );
}
