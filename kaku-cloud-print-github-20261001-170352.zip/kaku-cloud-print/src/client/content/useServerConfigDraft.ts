import { useEffect, useRef, useState } from "react";
import type { Versioned } from "../../shared/api";
import { apiRequest, ApiError } from "../api/client";

export const conflictMessage =
  "服务器配置已被其他人更新。草稿已保留，请先备份草稿，再加载服务器最新版本后重新编辑并发布。";

/** Keeps the revision attached to the editor's base, never to an unrelated GET. */
export function useServerConfigDraft<T>(
  path: string,
  key: string,
  initial: T,
  parse: (text: string) => T,
  serialize: (data: T) => string,
) {
  const [draft, setDraftState] = useState(initial);
  const [deployed, setDeployed] = useState<T | null>(null);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [notice, setNotice] = useState("");
  const [saved, setSaved] = useState(JSON.stringify(initial));
  const [revision, setRevision] = useState<string | null>(null);
  const [conflicted, setConflicted] = useState(false);
  const value = useRef(initial),
    edited = useRef(false),
    busy = useRef(false),
    sequence = useRef(0);
  const dirty = JSON.stringify(draft) !== saved;
  function setDraft(next: T) {
    edited.current = true;
    value.current = next;
    setDraftState(next);
  }
  function accept(envelope: Versioned<T>) {
    if (!envelope.revision || typeof envelope.revision !== "string")
      throw new Error("服务器配置版本无效。");
    return parse(JSON.stringify(envelope.data));
  }
  useEffect(() => {
    const id = ++sequence.current;
    const controller = new AbortController();
    let storedRevision: string | null = null;
    let localNotice = "";
    try {
      const raw = localStorage.getItem(key);
      if (raw) {
        const data = parse(raw);
        setDraft(data);
        setSaved(JSON.stringify(data));
        storedRevision = localStorage.getItem(`${key}-revision`);
      }
    } catch {
      localNotice = "本地草稿无法读取，原始备份未覆盖。";
    }
    void apiRequest<Versioned<T>>(path, { signal: controller.signal })
      .then((envelope) => {
        const data = accept(envelope);
        if (id !== sequence.current) return;
        setDeployed(data);
        const conflict =
          !!storedRevision && storedRevision !== envelope.revision;
        setRevision(storedRevision || envelope.revision);
        setConflicted(conflict);
        if (!edited.current) {
          value.current = data;
          setDraftState(structuredClone(data));
          setSaved(JSON.stringify(data));
        }
        setNotice(conflict ? conflictMessage : localNotice);
      })
      .catch((error) => {
        if (id === sequence.current)
          setNotice(
            `服务器配置读取失败：${error instanceof Error ? error.message : "请重试"}。草稿仍可编辑，请加载服务器最新版本后发布。`,
          );
      })
      .finally(() => {
        if (id === sequence.current) setLoading(false);
      });
    return () => {
      sequence.current++;
      controller.abort();
    };
  }, [path, key]);
  useEffect(() => {
    if (!dirty) return;
    const warn = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);
  function save() {
    const text = serialize(value.current);
    localStorage.setItem(key, text);
    if (revision) localStorage.setItem(`${key}-revision`, revision);
    setSaved(JSON.stringify(value.current));
  }
  async function publish() {
    if (busy.current) throw new Error("正在处理服务器请求，请稍候。");
    if (conflicted) throw new Error(conflictMessage);
    if (!revision) throw new Error("请先加载服务器最新版本，再发布。");
    const submitted = parse(serialize(value.current));
    const id = ++sequence.current;
    busy.current = true;
    setSaving(true);
    try {
      const envelope = await apiRequest<Versioned<T>>(path, {
        method: "PUT",
        body: JSON.stringify({ revision, data: submitted }),
      });
      const data = accept(envelope);
      if (id !== sequence.current) return;
      setDeployed(data);
      setRevision(envelope.revision);
      setNotice("");
      // Edits made during the request remain in the editor and stay dirty.
      if (JSON.stringify(value.current) === JSON.stringify(submitted)) {
        value.current = data;
        setDraftState(structuredClone(data));
      }
      setSaved(JSON.stringify(data));
      // Do not change a separately saved local draft or silently rebase it.
    } catch (error) {
      if (error instanceof ApiError && error.status === 409) {
        setConflicted(true);
        throw new Error(conflictMessage);
      }
      throw error;
    } finally {
      busy.current = false;
      setSaving(false);
    }
  }
  async function reload() {
    if (busy.current) throw new Error("正在处理服务器请求，请稍候。");
    const id = ++sequence.current;
    const previous = value.current;
    busy.current = true;
    setLoading(true);
    try {
      const envelope = await apiRequest<Versioned<T>>(path);
      const data = accept(envelope);
      if (id !== sequence.current) return;
      if (value.current !== previous)
        throw new Error("加载期间草稿已修改，本次未替换。请再次确认加载。");
      setDraft(structuredClone(data));
      setDeployed(data);
      setRevision(envelope.revision);
      setConflicted(false);
      setSaved(JSON.stringify(data));
      setNotice("");
    } finally {
      busy.current = false;
      setLoading(false);
    }
  }
  return {
    deployed,
    draft,
    setDraft,
    save,
    publish,
    reload,
    loading,
    saving,
    notice,
    dirty,
    canPublish: !!revision && !conflicted,
  };
}
