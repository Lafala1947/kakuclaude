import { useState } from "react";
import { message } from "../utils";

export default function ServerPublishControls({
  publish,
  reload,
  disabled,
  canPublish = true,
  loading,
}: {
  publish: () => Promise<void>;
  reload: () => Promise<void>;
  disabled?: boolean;
  canPublish?: boolean;
  loading?: boolean;
}) {
  const [confirm, setConfirm] = useState(false);
  const [feedback, setFeedback] = useState<{
    error: boolean;
    text: string;
  } | null>(null);
  const [busy, setBusy] = useState(false);
  async function run(action: () => Promise<void>, text: string) {
    setBusy(true);
    setFeedback(null);
    try {
      await action();
      setFeedback({ error: false, text });
      setConfirm(false);
    } catch (error) {
      setFeedback({ error: true, text: message(error) });
    } finally {
      setBusy(false);
    }
  }
  return (
    <>
      <button
        className="button primary"
        disabled={disabled || loading || busy || !canPublish}
        onClick={() => void run(publish, "已发布到服务器，公开内容已更新。")}
      >
        发布到服务器
      </button>
      <button
        className="button secondary"
        disabled={disabled || loading || busy}
        onClick={() => setConfirm(true)}
      >
        加载服务器最新版本
      </button>
      {confirm && (
        <div className="cms-confirm" role="alert">
          <p>加载最新版本将替换当前编辑草稿。需要保留修改时，请先下载备份。</p>
          <button
            className="button danger"
            disabled={busy || loading}
            onClick={() => void run(reload, "已加载服务器最新版本。")}
          >
            确认加载并替换草稿
          </button>
          <button
            className="button secondary"
            disabled={busy}
            onClick={() => setConfirm(false)}
          >
            取消加载
          </button>
        </div>
      )}
      {feedback && (
        <p
          className={`cms-notice ${feedback.error ? "error" : ""}`}
          role={feedback.error ? "alert" : "status"}
        >
          {feedback.text}
        </p>
      )}
    </>
  );
}
