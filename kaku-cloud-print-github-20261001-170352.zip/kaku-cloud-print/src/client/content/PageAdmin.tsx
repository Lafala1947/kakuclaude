import { apiEnabled } from "../api/client";
import ServerPublishControls from "./ServerPublishControls";
import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowDown,
  ArrowUp,
  Download,
  Eye,
  Plus,
  Save,
  Trash2,
  Upload,
} from "lucide-react";
import {
  moduleNames,
  newModule,
  newItem,
  parseHomepage,
  serializeHomepage,
  MAX_DOCUMENT_BYTES,
  type HomeModule,
  type HomeItem,
  type ModuleType,
  type HomepageDocument,
} from "../../shared/homepage";
import { useHomeContent } from "./HomeContentContext";
import AdminSectionNav from "../AdminSectionNav";
import { download, message } from "../utils";

export default function PageAdmin() {
  const {
    draft,
    deployed,
    setDraft,
    save,
    loading,
    notice,
    dirty,
    publish,
    reload,
    saving,
    canPublish,
  } = useHomeContent();
  const [selected, setSelected] = useState(draft.modules[0].id),
    [type, setType] = useState<ModuleType>("text");
  const [feedback, setFeedback] = useState<{
    error: boolean;
    text: string;
  } | null>(null);
  const [confirmation, setConfirmation] = useState<"delete" | "reset" | null>(
    null,
  );
  const [imported, setImported] = useState<HomepageDocument | null>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const m = draft.modules.find((m) => m.id === selected) ?? draft.modules[0];
  const index = draft.modules.indexOf(m);
  const hasItems = [
    "services",
    "products",
    "process",
    "resources",
    "text",
  ].includes(m.type);
  const hasHeading = !["services", "resources"].includes(m.type);
  function update(next: HomepageDocument) {
    setDraft(next);
    setFeedback(null);
    setConfirmation(null);
  }
  function patch(partial: Partial<HomeModule>) {
    update({
      ...draft,
      modules: draft.modules.map((x) =>
        x.id === m.id ? { ...x, ...partial } : x,
      ),
    });
  }
  function patchItem(id: string, partial: Partial<HomeItem>) {
    patch({
      items: m.items.map((x) => (x.id === id ? { ...x, ...partial } : x)),
    });
  }
  function attempt(run: () => void, text: string) {
    try {
      run();
      setFeedback({ error: false, text });
    } catch (e) {
      setFeedback({ error: true, text: message(e) });
    }
  }
  function move(delta: number) {
    const modules = [...draft.modules];
    [modules[index], modules[index + delta]] = [
      modules[index + delta],
      modules[index],
    ];
    update({ ...draft, modules });
  }
  function textField(
    label: string,
    field: keyof HomeModule,
    multiline = false,
  ) {
    return (
      <label className="cms-field">
        {label}
        {multiline ? (
          <textarea
            rows={field === "text" ? 4 : 2}
            maxLength={field === "title" ? 200 : 3000}
            value={String(m[field])}
            onChange={(e) => patch({ [field]: e.target.value })}
          />
        ) : (
          <input
            value={String(m[field])}
            maxLength={
              ["image", "actionHref", "secondaryHref"].includes(field)
                ? 1000
                : field === "note"
                  ? 3000
                  : field === "imageAlt"
                    ? 300
                    : field === "eyebrow"
                      ? 150
                      : 100
            }
            onChange={(e) => patch({ [field]: e.target.value })}
          />
        )}
      </label>
    );
  }
  return (
    <div className="admin-workspace page-admin">
      <AdminSectionNav />
      <header className="workspace-heading">
        <div>
          <span className="admin-kicker">PAGE CONTENT / 页面组</span>
          <h1>首页内容管理</h1>
          <p>按模块编排首页，调整展示顺序与内容。</p>
        </div>
        {loading ? (
          <button className="button secondary" disabled>
            <Eye size={16} />
            预览草稿
          </button>
        ) : (
          <Link className="button secondary" to="/admin/home-preview">
            <Eye size={16} />
            预览草稿
          </Link>
        )}
      </header>
      <div className="cms-publish-bar">
        <div>
          <b>
            {apiEnabled
              ? "草稿 → 预览 → 发布到服务器"
              : "草稿 → 预览 → 下载配置 → 上传发布"}
          </b>
          <span className="cms-save-state">
            {dirty ? "有未保存的修改" : "草稿未修改"}
          </span>
          <p>
            {apiEnabled
              ? "保存草稿仅保存在此浏览器；点击发布到服务器后，公开首页立即更新。"
              : "保存草稿仅保存在此浏览器。下载 homepage.json 并上传覆盖网站同名文件，才会更新公开首页。"}
          </p>
        </div>
        <div className="cms-toolbar">
          {apiEnabled && publish && reload && (
            <ServerPublishControls
              publish={publish}
              reload={reload}
              loading={loading}
              disabled={saving}
              canPublish={canPublish}
            />
          )}
          <button
            className="button secondary"
            onClick={() => fileRef.current?.click()}
          >
            <Upload size={16} />
            导入首页配置
          </button>
          <button
            className="button secondary"
            disabled={loading}
            onClick={() => attempt(save, "草稿已保存在此浏览器，尚未发布。")}
          >
            <Save size={16} />
            保存本地草稿
          </button>
          <button
            className="button primary"
            disabled={loading}
            onClick={() =>
              attempt(
                () =>
                  download(
                    serializeHomepage(draft),
                    "homepage.json",
                    "application/json;charset=utf-8",
                  ),
                apiEnabled
                  ? "首页配置备份已下载，尚未发布。"
                  : "首页配置已下载，请上传服务器覆盖 homepage.json 后发布。",
              )
            }
          >
            <Download size={16} />
            下载首页配置
          </button>
        </div>
      </div>
      <input
        className="cms-visually-hidden"
        type="file"
        accept=".json,application/json"
        ref={fileRef}
        aria-label="导入首页配置文件"
        onChange={async (e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (!file) return;
          try {
            if (file.size > MAX_DOCUMENT_BYTES)
              throw new Error("首页配置不能超过 500 KB。");
            setImported(parseHomepage(await file.text()));
            setFeedback(null);
          } catch (err) {
            setFeedback({ error: true, text: message(err) });
          }
        }}
      />
      {notice && (
        <p className="cms-notice" role="status">
          {notice}
        </p>
      )}
      {feedback && (
        <p
          className={`cms-notice ${feedback.error ? "error" : ""}`}
          role={feedback.error ? "alert" : "status"}
        >
          {feedback.text}
        </p>
      )}
      {imported && (
        <div className="cms-confirm" role="alert">
          <b>
            已检查配置中的 {imported.modules.length}{" "}
            个模块。导入将替换当前编辑草稿。
          </b>
          <button
            className="button primary"
            onClick={() => {
              update(imported);
              setSelected(imported.modules[0].id);
              setImported(null);
              setFeedback({
                error: false,
                text: "配置已导入草稿，尚未保存或发布。",
              });
            }}
          >
            确认导入配置
          </button>
          <button
            className="button secondary"
            onClick={() => setImported(null)}
          >
            取消导入
          </button>
        </div>
      )}
      {loading ? (
        <p role="status">正在读取首页配置…</p>
      ) : (
        <div className="cms-editor-layout">
          <aside className="cms-module-list">
            <div className="cms-list-heading">
              <h2>首页模块</h2>
              <span>{draft.modules.length} / 30</span>
            </div>
            <p>选择模块编辑，使用上下箭头调整顺序。</p>
            <ol>
              {draft.modules.map((item, i) => (
                <li key={item.id}>
                  <button
                    className={m.id === item.id ? "selected" : ""}
                    aria-pressed={m.id === item.id}
                    aria-label={`选择模块 ${item.title}`}
                    onClick={() => {
                      setSelected(item.id);
                      setConfirmation(null);
                    }}
                  >
                    <span className="cms-module-number">
                      {String(i + 1).padStart(2, "0")}
                    </span>
                    <span>
                      <b>{item.title}</b>
                      <small>
                        {moduleNames[item.type]} ·{" "}
                        {item.enabled ? "显示" : "已隐藏"}
                      </small>
                    </span>
                    <span
                      className={`cms-visible-dot ${item.enabled ? "on" : ""}`}
                    />
                  </button>
                </li>
              ))}
            </ol>
            <label className="cms-field">
              新增模块类型
              <select
                value={type}
                onChange={(e) => setType(e.target.value as ModuleType)}
              >
                {Object.entries(moduleNames).map(([key, name]) => (
                  <option key={key} value={key}>
                    {name}
                  </option>
                ))}
              </select>
            </label>
            <button
              className="button secondary"
              disabled={draft.modules.length >= 30}
              onClick={() => {
                const added = newModule(type);
                update({ ...draft, modules: [...draft.modules, added] });
                setSelected(added.id);
              }}
            >
              <Plus size={16} />
              新增模块
            </button>
            <button
              className="cms-reset"
              onClick={() => setConfirmation("reset")}
            >
              用已发布内容重置草稿
            </button>
          </aside>
          <section className="cms-edit-panel" aria-label="模块编辑">
            {m.type === "catalog" && (
              <p className="cms-notice">
                此模块自动展示已发布产品中“上架且首页推荐”的产品，顺序跟随产品管理。产品资料请在
                <Link to="/admin/products">产品管理</Link>
                中维护；预览首页时也使用已发布产品。
              </p>
            )}
            <div className="cms-edit-heading">
              <div>
                <span className="admin-kicker">{moduleNames[m.type]}</span>
                <h2>编辑模块</h2>
              </div>
              <div className="cms-icon-actions">
                <button
                  aria-label="模块上移"
                  disabled={index === 0}
                  onClick={() => move(-1)}
                >
                  <ArrowUp size={18} />
                </button>
                <button
                  aria-label="模块下移"
                  disabled={index === draft.modules.length - 1}
                  onClick={() => move(1)}
                >
                  <ArrowDown size={18} />
                </button>
                <button
                  aria-label="删除模块"
                  disabled={draft.modules.length === 1}
                  onClick={() => setConfirmation("delete")}
                >
                  <Trash2 size={18} />
                </button>
              </div>
            </div>
            {confirmation && (
              <div className="cms-confirm" role="alert">
                <p>
                  {confirmation === "delete"
                    ? `删除“${m.title}”及其全部内容条目？`
                    : "用已发布内容替换当前草稿？本地保存的草稿在再次保存前不会改变。"}
                </p>
                <button
                  className="button danger"
                  onClick={() => {
                    if (confirmation === "delete") {
                      const modules = draft.modules.filter(
                        (x) => x.id !== m.id,
                      );
                      if (!modules.some((x) => x.enabled)) {
                        setFeedback({
                          error: true,
                          text: "请先显示另一个模块，再删除当前模块。",
                        });
                        setConfirmation(null);
                        return;
                      }
                      update({ ...draft, modules });
                      setSelected(
                        modules[Math.min(index, modules.length - 1)].id,
                      );
                    } else {
                      update(structuredClone(deployed));
                      setSelected(deployed.modules[0].id);
                    }
                  }}
                >
                  {confirmation === "delete" ? "确认删除模块" : "确认重置草稿"}
                </button>
                <button
                  className="button secondary"
                  onClick={() => setConfirmation(null)}
                >
                  取消
                </button>
              </div>
            )}
            <label className="cms-toggle">
              <input
                type="checkbox"
                aria-label="在首页显示"
                checked={m.enabled}
                onChange={(e) => {
                  if (
                    !e.target.checked &&
                    draft.modules.filter((x) => x.enabled).length === 1
                  ) {
                    setFeedback({
                      error: true,
                      text: "首页至少需要一个显示的模块。",
                    });
                    return;
                  }
                  patch({ enabled: e.target.checked });
                }}
              />
              在首页显示<span>{m.enabled ? "显示中" : "已隐藏"}</span>
            </label>
            {textField("模块标题", "title", true)}
            {!hasHeading && (
              <p className="admin-muted">
                此标题用于识别模块；前台展示下方的内容条目。
              </p>
            )}
            {hasHeading && (
              <>
                {textField("标题上方小字", "eyebrow")}
                {textField("模块说明", "text", true)}
                <div className="cms-field-grid">
                  {textField("主按钮文字", "actionLabel")}
                  {textField("主按钮链接", "actionHref")}
                </div>
                <p className="admin-muted">
                  站内链接可用 /quote、/register、/login；外部链接须以 https://
                  开头。按钮不显示时，将文字和链接一同留空。
                </p>
              </>
            )}
            {["hero", "text"].includes(m.type) && (
              <>
                <div className="cms-field-grid">
                  {textField("次按钮文字", "secondaryLabel")}
                  {textField("次按钮链接", "secondaryHref")}
                </div>
                {textField("图片地址", "image")}
                {textField("图片说明", "imageAlt")}
                <p className="admin-muted">
                  可填写 assets/文件名.svg 或 HTTPS
                  图片地址。图片需另行上传，本页不上传图片文件。
                </p>
              </>
            )}
            {["hero", "products", "process", "text"].includes(m.type) &&
              textField(
                m.type === "process" ? "费用说明" : "补充说明 / 图片注释",
                "note",
                true,
              )}
            {hasItems && (
              <div className="cms-items">
                <div className="cms-list-heading">
                  <h3>内容条目</h3>
                  <button
                    className="button secondary"
                    disabled={m.items.length >= 20}
                    onClick={() => patch({ items: [...m.items, newItem()] })}
                  >
                    <Plus size={16} />
                    新增条目
                  </button>
                </div>
                {m.items.length === 0 && (
                  <p className="admin-muted">还没有内容条目，可添加第一条。</p>
                )}
                {m.items.map((item, i) => (
                  <fieldset className="cms-item" key={item.id}>
                    <legend>条目 {i + 1}</legend>
                    <div className="cms-item-actions">
                      <button
                        aria-label={`条目 ${i + 1} 上移`}
                        disabled={i === 0}
                        onClick={() => {
                          const items = [...m.items];
                          [items[i - 1], items[i]] = [items[i], items[i - 1]];
                          patch({ items });
                        }}
                      >
                        <ArrowUp size={15} />
                      </button>
                      <button
                        aria-label={`条目 ${i + 1} 下移`}
                        disabled={i === m.items.length - 1}
                        onClick={() => {
                          const items = [...m.items];
                          [items[i + 1], items[i]] = [items[i], items[i + 1]];
                          patch({ items });
                        }}
                      >
                        <ArrowDown size={15} />
                      </button>
                      <button
                        className="cms-delete-item"
                        onClick={() =>
                          patch({
                            items: m.items.filter((x) => x.id !== item.id),
                          })
                        }
                      >
                        删除条目 {i + 1}
                      </button>
                    </div>
                    <label className="cms-field">
                      条目 {i + 1} 标题
                      <input
                        maxLength={200}
                        value={item.title}
                        onChange={(e) =>
                          patchItem(item.id, { title: e.target.value })
                        }
                      />
                    </label>
                    <label className="cms-field">
                      条目 {i + 1} 说明
                      <textarea
                        rows={3}
                        maxLength={3000}
                        value={item.text}
                        onChange={(e) =>
                          patchItem(item.id, { text: e.target.value })
                        }
                      />
                    </label>
                    {["products", "resources"].includes(m.type) && (
                      <>
                        <label className="cms-field">
                          条目 {i + 1} 小字
                          <input
                            maxLength={150}
                            value={item.eyebrow}
                            onChange={(e) =>
                              patchItem(item.id, { eyebrow: e.target.value })
                            }
                          />
                        </label>
                        <label className="cms-field">
                          条目 {i + 1} 标签（用顿号分隔）
                          <input
                            maxLength={300}
                            value={item.tags}
                            onChange={(e) =>
                              patchItem(item.id, { tags: e.target.value })
                            }
                          />
                        </label>
                      </>
                    )}
                    {m.type === "products" && (
                      <label className="cms-field">
                        条目 {i + 1} 卡片示意
                        <select
                          value={item.kind}
                          onChange={(e) =>
                            patchItem(item.id, {
                              kind: e.target.value as HomeItem["kind"],
                            })
                          }
                        >
                          <option value="insert">包装插卡</option>
                          <option value="thanks">品牌感谢卡</option>
                          <option value="shape">异形卡片</option>
                        </select>
                      </label>
                    )}
                    {["products", "resources", "text"].includes(m.type) && (
                      <div className="cms-field-grid">
                        <label className="cms-field">
                          条目 {i + 1} 按钮文字
                          <input
                            maxLength={100}
                            value={item.actionLabel}
                            onChange={(e) =>
                              patchItem(item.id, {
                                actionLabel: e.target.value,
                              })
                            }
                          />
                        </label>
                        <label className="cms-field">
                          条目 {i + 1} 按钮链接
                          <input
                            maxLength={1000}
                            value={item.actionHref}
                            onChange={(e) =>
                              patchItem(item.id, { actionHref: e.target.value })
                            }
                          />
                        </label>
                      </div>
                    )}
                  </fieldset>
                ))}
              </div>
            )}
          </section>
        </div>
      )}
    </div>
  );
}
