import { apiEnabled } from "../api/client";
import { useServerConfigDraft } from "../content/useServerConfigDraft";
import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  defaultHomepage,
  parseHomepage,
  serializeHomepage,
  type HomepageDocument,
} from "../../shared/homepage";
const KEY = "kaku-homepage-draft-v1";
const Context = createContext<{
  deployed: HomepageDocument;
  draft: HomepageDocument;
  setDraft: (d: HomepageDocument) => void;
  save: () => void;
  publish?: () => Promise<void>;
  reload?: () => Promise<void>;
  saving?: boolean;
  canPublish?: boolean;
  loading: boolean;
  notice: string;
  dirty: boolean;
}>({
  deployed: defaultHomepage,
  draft: defaultHomepage,
  setDraft: () => {},
  save: () => {},
  loading: false,
  notice: "",
  dirty: false,
});
function StaticHomeContentProvider({ children }: { children: ReactNode }) {
  const [deployed, setDeployed] = useState<HomepageDocument>(defaultHomepage);
  const [draft, setDraftState] = useState<HomepageDocument>(defaultHomepage);
  const [loading, setLoading] = useState(true),
    [notice, setNotice] = useState("");
  const hasDraft = useRef(false);
  const [savedSnapshot, setSavedSnapshot] = useState(() =>
    JSON.stringify(defaultHomepage),
  );
  const dirty = JSON.stringify(draft) !== savedSnapshot;
  useEffect(() => {
    if (!dirty) return;
    const warn = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);
  useEffect(() => {
    let active = true;
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 10000);
    const notices: string[] = [];
    try {
      const stored = localStorage.getItem(KEY);
      if (stored) {
        const storedDraft = parseHomepage(stored);
        setDraftState(storedDraft);
        setSavedSnapshot(JSON.stringify(storedDraft));
        hasDraft.current = true;
      }
    } catch {
      notices.push("本地草稿无法读取，已保留原数据；可导入备份或保存新草稿。");
    }
    async function load() {
      try {
        const response = await fetch(
          `${import.meta.env.BASE_URL}homepage.json?t=${Date.now()}`,
          { cache: "no-store", signal: controller.signal },
        );
        if (!response.ok) throw new Error("读取失败");
        const data = parseHomepage(await response.text());
        if (active) {
          setDeployed(data);
          if (!hasDraft.current) {
            setDraftState(structuredClone(data));
            setSavedSnapshot(JSON.stringify(data));
          }
        }
      } catch {
        if (active)
          notices.push("已发布首页配置暂时无法读取，当前使用内置首页内容。");
      } finally {
        clearTimeout(timeout);
        if (active) {
          setNotice(notices.join(" "));
          setLoading(false);
        }
      }
    }
    void load();
    return () => {
      active = false;
      clearTimeout(timeout);
      controller.abort();
    };
  }, []);
  function setDraft(d: HomepageDocument) {
    hasDraft.current = true;
    setDraftState(d);
  }
  function save() {
    const text = serializeHomepage(draft);
    localStorage.setItem(KEY, text);
    setSavedSnapshot(JSON.stringify(draft));
    hasDraft.current = true;
  }
  return (
    <Context.Provider
      value={{ deployed, draft, setDraft, save, loading, notice, dirty }}
    >
      {children}
    </Context.Provider>
  );
}
export const useHomeContent = () => useContext(Context);

export function HomeContentProvider({ children }: { children: ReactNode }) {
  return apiEnabled ? (
    <ServerHomeContentProvider>{children}</ServerHomeContentProvider>
  ) : (
    <StaticHomeContentProvider>{children}</StaticHomeContentProvider>
  );
}
function ServerHomeContentProvider({ children }: { children: ReactNode }) {
  const state = useServerConfigDraft(
    "/config/homepage",
    KEY,
    defaultHomepage,
    parseHomepage,
    serializeHomepage,
  );
  return (
    <Context.Provider
      value={{ ...state, deployed: state.deployed ?? defaultHomepage }}
    >
      {children}
    </Context.Provider>
  );
}
