import { useNavigate, Link } from "react-router-dom";
import {
  ArrowUpRight,
  FileSpreadsheet,
  UsersRound,
  PanelsTopLeft,
} from "lucide-react";
import { adminGroups, useAdminAccess, type AdminGroup } from "./AdminAccess";
import { apiEnabled } from "../api/client";
import { useSession } from "../api/SessionContext";
import '../factory/factory.css';
export default function AdminPortal() {
  const { group, setGroup } = useAdminAccess();
  const session = useSession();
  const navigate = useNavigate();
  const icons = {
    pricing: FileSpreadsheet,
    sales: UsersRound,
    pages: PanelsTopLeft,
  };
  return (
    <div className="admin-workspace admin-portal">
      <header className="workspace-heading">
        <div>
          <span className="admin-kicker">KAKU / MANAGEMENT</span>
          <h1>后台管理工作台</h1>
          <p>按职责进入管理组，让价格、客户与内容各有归属。</p>
        </div>
        <Link to="/" className="button secondary">
          查看网站 <ArrowUpRight size={16} />
        </Link>
      </header>
      <div className="admin-demo-banner">
        <b>{apiEnabled ? "员工工作台" : "权限演示"}</b>
        <span>
          {apiEnabled
            ? "使用员工账号登录，管理组权限由服务器分配。"
            : "可切换管理组体验对应功能；员工账号与真实权限将在接入服务端后启用。"}
        </span>
        {group && (
          <button
            disabled={session.loading}
            onClick={() =>
              apiEnabled
                ? void session.logout().catch(() => {})
                : setGroup(null)
            }
          >
            退出{adminGroups[group].name}
          </button>
        )}
      </div>
      {apiEnabled && session.loading && <p role="status">正在验证员工身份…</p>}
      {apiEnabled && session.error && <p role="alert">{session.error}</p>}
      {apiEnabled && !group && (
        <p>
          <Link className="button primary" to="/login">
            员工登录
          </Link>
          {session.user?.role === "member" && (
            <span>当前会员账号没有后台管理权限。</span>
          )}
        </p>
      )}
      {group && <section className="factory-portal-entry"><div><span className="admin-kicker">KAKU / CLOUD FACTORY</span><h2>云端印刷工厂</h2><p>印厂网络、接单、生产与交付，在这里查看平台整体业务。</p></div><Link to="/admin/factory" className="button primary">进入工厂总览 <ArrowUpRight size={18} /></Link></section>}
      <div className="admin-group-grid">
        {(Object.keys(adminGroups) as AdminGroup[])
          .filter((key) => !apiEnabled || group === key)
          .map((key) => {
            const g = adminGroups[key],
              Icon = icons[key];
            return (
              <section key={key} className={`admin-group-card ${g.color}`}>
                <div className="admin-group-top">
                  <Icon size={28} strokeWidth={1.5} />
                  <span>{group === key ? "当前管理组" : g.name}</span>
                </div>
                <h2>{g.title}</h2>
                <p>{g.description}</p>
                <ul>
                  {(key === "pricing"
                    ? ["五类费用维护", "费用表导入与导出", "报价参数核对"]
                    : key === "sales"
                      ? ["会员查询与筛选", "资料与状态管理", "会员等级设置"]
                      : [
                          "产品资料与上下架",
                          "首页模块与草稿预览",
                          "产品及首页配置导入导出",
                        ]
                  ).map((t) => (
                    <li key={t}>{t}</li>
                  ))}
                </ul>
                <button
                  className="button primary"
                  onClick={() => {
                    if (!apiEnabled) setGroup(key);
                    navigate(g.path);
                  }}
                >
                  进入{g.name}
                  <ArrowUpRight size={18} />
                </button>
                {key === "pages" && (
                  <button
                    className="button secondary product-portal-entry"
                    onClick={() => {
                      if (!apiEnabled) setGroup("pages");
                      navigate("/admin/products");
                    }}
                  >
                    进入产品管理
                    <ArrowUpRight size={18} />
                  </button>
                )}
                {apiEnabled && key === "sales" && (
                  <Link to="/admin/orders" className="button secondary">
                    管理订单
                  </Link>
                )}
                {apiEnabled && key === "sales" && (
                  <Link to="/admin/reviews" className="button secondary">
                    文件审核
                  </Link>
                )}
              </section>
            );
          })}
      </div>
      <section className="admin-permission-table">
        <h2>管理组权限</h2>
        <div className="admin-table-scroll">
          <table>
            <thead>
              <tr>
                <th>功能模块</th>
                <th>价格组</th>
                <th>销售组</th>
                <th>页面组</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <th>产品管理</th>
                <td>—</td>
                <td>—</td>
                <td>
                  <span className="permission-yes">可管理</span>
                </td>
              </tr>
              {(Object.keys(adminGroups) as AdminGroup[]).map((key) => (
                <tr key={key}>
                  <th>{adminGroups[key].title}</th>
                  {(Object.keys(adminGroups) as AdminGroup[]).map((col) => (
                    <td key={col}>
                      {key === col ? (
                        <span className="permission-yes">可管理</span>
                      ) : (
                        "—"
                      )}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="admin-muted">
          {apiEnabled
            ? "修改经服务器权限校验后保存；销售组可管理会员与订单。"
            : "价格、产品与首页内容通过下载配置文件、上传服务器更新；会员数据当前仍为演示资料。"}
        </p>
      </section>
    </div>
  );
}
