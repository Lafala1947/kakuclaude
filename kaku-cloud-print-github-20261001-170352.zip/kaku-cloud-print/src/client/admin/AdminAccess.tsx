import { createContext, useContext, useState, type ReactNode } from "react";
import { Link } from "react-router-dom";
import { apiEnabled } from '../api/client';
import { useSession } from '../api/SessionContext';
export const adminGroups = {
  pricing: {
    name: "价格组",
    title: "价格管理",
    path: "/admin/pricing",
    description: "维护设计、印刷、纸张、后道工艺及物流费用。",
    color: "cyan",
  },
  sales: {
    name: "销售组",
    title: "会员管理",
    path: "/admin/members",
    description: "查询会员资料，调整会员等级与账号状态。",
    color: "magenta",
  },
  pages: {
    name: "页面组",
    title: "首页内容管理",
    path: "/admin/pages",
    description: "管理产品资料与上下架，编排首页模块和展示内容。",
    color: "yellow",
  },
} as const;
export type AdminGroup = keyof typeof adminGroups;
const AccessContext = createContext<{
  group: AdminGroup | null;
  setGroup: (group: AdminGroup | null) => void;
}>({ group: null, setGroup: () => {} });
export function AdminAccessProvider({ children }: { children: ReactNode }) {
  const [group, setGroup] = useState<AdminGroup | null>(null);
  const session = useSession();
  const serverGroup = !session.loading && !session.error && session.user?.role === 'staff' ? session.user.group : null;
  return (
    <AccessContext.Provider value={{ group: apiEnabled ? serverGroup : group, setGroup: apiEnabled ? () => {} : setGroup }}>
      {children}
    </AccessContext.Provider>
  );
}
export const useAdminAccess = () => useContext(AccessContext);
export function AdminGuard({
  group: required,
  children,
}: {
  group?: AdminGroup;
  children: ReactNode;
}) {
  const { group } = useAdminAccess();
  const session = useSession();
  if (apiEnabled && session.loading) return <p role="status">正在验证员工身份…</p>;
  if (apiEnabled && session.error) return <section className="admin-access-message"><h1>无法验证员工身份</h1><p role="alert">{session.error}</p><button onClick={() => void session.refresh().catch(() => {})}>重新验证</button></section>;
  if (group && (!required || group === required)) return <>{children}</>;
  return (
    <section className="admin-access-message">
      <span className="admin-kicker">卡库云印 / 后台工作台</span>
      <h1>{group ? "当前组无权访问此模块" : apiEnabled ? "请使用有权限的员工账号登录" : "请选择后台管理组"}</h1>
      <p>
        {group && required
          ? `当前为${adminGroups[group].name}，此页面属于${adminGroups[required].name}。`
          : apiEnabled ? "后台权限由服务器验证，会员账号无法进入员工管理模块。" : "从后台入口选择管理组后，进入对应的工作页面。"}
      </p>
      <Link className="button primary" to="/admin">
        返回后台入口
      </Link>
      <p className="admin-muted">
        {apiEnabled ? "请联系管理员分配员工管理组。" : "当前为权限演示，尚未接入员工登录与服务端权限校验。"}
      </p>
    </section>
  );
}
