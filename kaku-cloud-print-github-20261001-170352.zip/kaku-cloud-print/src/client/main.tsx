import React from "react";
import ReactDOM from "react-dom/client";
import { HashRouter } from "react-router-dom";
import App from "./App";
import { DraftProvider } from "./DraftContext";
import { MemberProvider } from "./members/MemberContext";
import { SessionProvider } from "./api/SessionContext";
import "./styles.css";
import "./corporate.css";
import "./admin/workspace.css";
import "./products/products.css";
ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <HashRouter>
      <SessionProvider>
        <DraftProvider>
          <MemberProvider>
            <App />
          </MemberProvider>
        </DraftProvider>
      </SessionProvider>
    </HashRouter>
  </React.StrictMode>,
);
