export const apiEnabled = Boolean(import.meta.env.VITE_API_BASE_URL);
const base = (import.meta.env.VITE_API_BASE_URL || "/api").replace(/\/$/, "");
let expectedSessionUserId: string | null = null;
export function setApiSessionUserId(id: string | null) {
  expectedSessionUserId = id;
}
export class ApiError extends Error {
  constructor(
    message: string,
    public status: number,
  ) {
    super(message);
  }
}
export async function apiRequest<T>(
  path: string,
  options: RequestInit = {},
): Promise<T> {
  const headers = new Headers(options.headers);
  headers.set("X-Kaku-Request", "1");
  headers.set("X-Kaku-User-Id", expectedSessionUserId ?? "anonymous");
  if (typeof options.body === "string" && !headers.has("Content-Type"))
    headers.set("Content-Type", "application/json");
  const controller = new AbortController();
  const abort = () => controller.abort();
  let timedOut = false;
  if (options.signal?.aborted) controller.abort();
  else options.signal?.addEventListener("abort", abort, { once: true });
  const timer = setTimeout(
    () => {
      timedOut = true;
      controller.abort();
    },
    path.startsWith("/files?") ? 300000 : 30000,
  );
  try {
    const response = await fetch(`${base}${path}`, {
      ...options,
      signal: controller.signal,
      headers,
      credentials: "include",
      cache: "no-store",
    });
    if (!response.ok) {
      const body = await response.json().catch(() => null);
      throw new ApiError(
        typeof body?.error === "string"
          ? body.error
          : `请求失败（${response.status}）`,
        response.status,
      );
    }
    return (await response.json()) as T;
  } catch (error) {
    if (timedOut)
      throw new ApiError(
        "请求超时，请重试；订单提交后可先查看我的订单确认结果。",
        408,
      );
    throw error;
  } finally {
    clearTimeout(timer);
    options.signal?.removeEventListener("abort", abort);
  }
}
export const apiFileUrl = (id: string) =>
  `${base}/files/${encodeURIComponent(id)}`;
