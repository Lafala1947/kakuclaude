import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import type { SessionResponse, SessionUser } from "../../shared/api";
import { apiEnabled, apiRequest, setApiSessionUserId } from "./client";

export interface LoginInput {
  email: string;
  password: string;
}
export interface RegisterInput extends LoginInput {
  name: string;
  company?: string;
  phone?: string;
}
interface SessionState {
  user: SessionUser | null;
  loading: boolean;
  error: string;
  login: (input: LoginInput) => Promise<void>;
  register: (input: RegisterInput) => Promise<void>;
  logout: () => Promise<void>;
  refresh: () => Promise<void>;
}
const unavailable = async () => {
  throw new Error("会话服务未就绪");
};
const SessionContext = createContext<SessionState>({
  user: null,
  loading: false,
  error: "",
  login: unavailable,
  register: unavailable,
  logout: unavailable,
  refresh: unavailable,
});
const invalidationKey = "kaku-session-invalidation";
function broadcast(phase: "start" | "complete") {
  try {
    localStorage.setItem(
      invalidationKey,
      JSON.stringify({ phase, id: crypto.randomUUID() }),
    );
  } catch {
    /* Storage can be unavailable; focus checks and request identity still protect account boundaries. */
  }
}
export function SessionProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<SessionUser | null>(null);
  const [loading, setLoading] = useState(apiEnabled);
  const [error, setError] = useState("");
  const generation = useRef(0);
  const checking = useRef(false);
  const authenticating = useRef(false);
  const externalAuth = useRef(false);
  const clearIdentity = useCallback(() => {
    setApiSessionUserId(null);
    setUser(null);
  }, []);
  const refresh = useCallback(async () => {
    if (
      !apiEnabled ||
      checking.current ||
      authenticating.current ||
      externalAuth.current
    )
      return;
    const current = ++generation.current;
    checking.current = true;
    try {
      const result = await apiRequest<SessionResponse>("/session");
      if (current === generation.current) {
        setApiSessionUserId(result.user?.id ?? null);
        setUser(result.user ?? null);
        setError("");
      }
    } catch (err) {
      if (current === generation.current) {
        clearIdentity();
        setError(err instanceof Error ? err.message : "无法连接会话服务");
      }
      throw err;
    } finally {
      if (current === generation.current) {
        checking.current = false;
        setLoading(false);
      }
    }
  }, [clearIdentity]);
  const authenticate = useCallback(
    async (path: string, body: unknown) => {
      if (!apiEnabled) return;
      if (authenticating.current) throw new Error("正在处理账号请求，请稍候");
      const current = ++generation.current;
      authenticating.current = true;
      checking.current = false;
      externalAuth.current = false;
      broadcast("start");
      // Capture the prior expected identity for logout before invalidating local private state.
      const operation = apiRequest<SessionResponse>(path, {
        method: "POST",
        body: JSON.stringify(body),
      });
      clearIdentity();
      setLoading(true);
      setError("");
      try {
        const result = await operation;
        if (current !== generation.current)
          throw new Error("账号状态已变更，请重新确认登录状态");
        setApiSessionUserId(result.user?.id ?? null);
        setUser(result.user ?? null);
      } catch (err) {
        if (current === generation.current)
          setError(err instanceof Error ? err.message : "无法连接会话服务");
        throw err;
      } finally {
        authenticating.current = false;
        if (current === generation.current) setLoading(false);
        else if (!externalAuth.current) void refresh().catch(() => {});
        broadcast("complete");
      }
    },
    [clearIdentity, refresh],
  );
  useEffect(() => {
    if (!apiEnabled) return;
    let recoveryTimer: ReturnType<typeof setTimeout> | undefined;
    setApiSessionUserId(null);
    const revalidate = () => {
      void refresh().catch(() => {});
    };
    const visible = () => {
      if (document.visibilityState === "visible") revalidate();
    };
    const storage = (event: StorageEvent) => {
      if (event.key !== invalidationKey || !event.newValue) return;
      let phase: unknown;
      try {
        phase = JSON.parse(event.newValue).phase;
      } catch {
        return;
      }
      if (phase !== "start" && phase !== "complete") return;
      clearTimeout(recoveryTimer);
      generation.current++;
      checking.current = false;
      clearIdentity();
      setError("");
      setLoading(true);
      externalAuth.current = phase === "start";
      if (phase === "complete") revalidate();
      else {
        // The initiating tab can close before broadcasting completion. Wait beyond
        // the normal authentication request timeout before checking its cookie.
        recoveryTimer = setTimeout(() => {
          externalAuth.current = false;
          revalidate();
        }, 35000);
      }
    };
    window.addEventListener("focus", revalidate);
    document.addEventListener("visibilitychange", visible);
    window.addEventListener("storage", storage);
    revalidate();
    return () => {
      clearTimeout(recoveryTimer);
      generation.current++;
      checking.current = false;
      setApiSessionUserId(null);
      window.removeEventListener("focus", revalidate);
      document.removeEventListener("visibilitychange", visible);
      window.removeEventListener("storage", storage);
    };
  }, [refresh, clearIdentity]);
  return (
    <SessionContext.Provider
      value={{
        user,
        loading,
        error,
        refresh,
        login: (input) => authenticate("/auth/login", input),
        register: (input) => authenticate("/auth/register", input),
        logout: () => authenticate("/auth/logout", {}),
      }}
    >
      {children}
    </SessionContext.Provider>
  );
}
export const useSession = () => useContext(SessionContext);
