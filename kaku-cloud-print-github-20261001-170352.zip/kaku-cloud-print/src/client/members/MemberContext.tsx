import { createContext, useCallback, useContext, useEffect, useRef, useState, type ReactNode } from "react";
import { apiEnabled, apiRequest } from '../api/client';
import { useSession } from '../api/SessionContext';
import type { MembersDocument, Versioned } from '../../shared/api';

export interface MemberRecord {
  id: string;
  name: string;
  email: string;
  company: string;
  phone: string;
  tierId: string;
  active: boolean;
  createdAt: string;
  notes: string;
}
export interface MemberTier {
  id: string;
  name: string;
  discount: number;
}
const initialTiers: MemberTier[] = [
  { id: "standard", name: "普通会员", discount: 100 },
  { id: "silver", name: "银卡会员", discount: 95 },
  { id: "gold", name: "金卡会员", discount: 90 },
  { id: "business", name: "企业会员", discount: 85 },
];
const demoMembers = (): MemberRecord[] =>
  Array.from({ length: 8 }, (_, i) => ({
    id: `DEMO-${String(i + 1).padStart(3, "0")}`,
    name: `演示客户 ${String(i + 1).padStart(2, "0")}`,
    email: `member${String(i + 1).padStart(3, "0")}@example.com`,
    company: i % 2 === 0 ? `示例印品工作室 ${i + 1}` : "",
    phone: "",
    tierId: initialTiers[i % 4].id,
    active: i !== 3 && i !== 6,
    createdAt: `2026-09-${String(12 + i).padStart(2, "0")}`,
    notes: "仅用于页面预览的合成资料。",
  }));
export const validEmail = (email: string) =>
  /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && email.length <= 254;
interface MemberState {
  members: MemberRecord[];
  tiers: MemberTier[];
  updateMember: (member: MemberRecord) => void | Promise<void>;
  updateTiers: (tiers: MemberTier[]) => void | Promise<void>;
  loading: boolean;
  pending: boolean;
  error: string;
  owner: string;
  reload: () => Promise<void>;
  reset: () => void;
}
const MemberContext = createContext<MemberState | null>(null);
export function MemberProvider({ children }: { children: ReactNode }) {
  return apiEnabled ? <ApiMemberProvider>{children}</ApiMemberProvider> : <PreviewMemberProvider>{children}</PreviewMemberProvider>;
}
function PreviewMemberProvider({ children }: { children: ReactNode }) {
  const [members, setMembers] = useState(demoMembers);
  const [tiers, setTiers] = useState(() => structuredClone(initialTiers));
  function updateMember(member: MemberRecord) {
    const cleaned = {
      ...member,
      name: member.name.trim(),
      email: member.email.trim().toLowerCase(),
      company: member.company.trim(),
      phone: member.phone.trim(),
      notes: member.notes.trim(),
    };
    if (!cleaned.name) throw new Error("请填写联系人姓名");
    if (!validEmail(cleaned.email)) throw new Error("请填写有效邮箱");
    if (cleaned.phone && !/^\+?[\d\s()-]{6,20}$/.test(cleaned.phone))
      throw new Error("请填写有效联系电话，或留空");
    if (
      members.some(
        (m) => m.id !== member.id && m.email.toLowerCase() === cleaned.email,
      )
    )
      throw new Error("该邮箱已被其他演示会员使用");
    if (!tiers.some((t) => t.id === member.tierId))
      throw new Error("请选择有效会员等级");
    setMembers((current) =>
      current.map((m) => (m.id === member.id ? cleaned : m)),
    );
  }
  function updateTiers(next: MemberTier[]) {
    const clean = next.map((t) => ({ ...t, name: t.name.trim() }));
    if (clean.some((t) => !t.name)) throw new Error("请填写每个等级的名称");
    if (new Set(clean.map((t) => t.name)).size !== clean.length)
      throw new Error("等级名称不能重复");
    if (
      clean.some(
        (t) =>
          !Number.isFinite(t.discount) || t.discount <= 0 || t.discount > 100,
      )
    )
      throw new Error("折扣需大于 0 且不超过 100%");
    if (
      clean.some(
        (t) =>
          Math.abs(t.discount * 100 - Math.round(t.discount * 100)) > 0.000001,
      )
    )
      throw new Error("折扣最多保留两位小数");
    setTiers(clean);
  }
  return (
    <MemberContext.Provider
      value={{
        members,
        tiers,
        updateMember,
        updateTiers,
        loading: false, pending: false, error: '', owner: 'preview', reload: async () => {},
        reset: () => {
          setMembers(demoMembers());
          setTiers(structuredClone(initialTiers));
        },
      }}
    >
      {children}
    </MemberContext.Provider>
  );
}
function ApiMemberProvider({ children }: { children: ReactNode }) {
  const session = useSession();
  const owner = !session.loading && !session.error && session.user?.role === 'staff' && session.user.group === 'sales' ? session.user.id : '';
  const [state, setState] = useState<{owner: string; document: Versioned<MembersDocument>} | null>(null);
  const [loading, setLoading] = useState(false);
  const [pending, setPending] = useState(false);
  const [error, setError] = useState('');
  const generation = useRef(0);
  const busy = useRef(false);
  const reload = useCallback(async () => {
    const current = ++generation.current;
    setError(''); setState(null); setPending(false); busy.current = false;
    if (!owner) { setLoading(false); return; }
    setLoading(true);
    try {
      const document = await apiRequest<Versioned<MembersDocument>>('/members');
      if (current === generation.current) setState({owner, document});
    } catch (err) { if (current === generation.current) setError(err instanceof Error ? err.message : '无法读取会员资料'); }
    finally { if (current === generation.current) setLoading(false); }
  }, [owner]);
  useEffect(() => { void reload(); return () => { generation.current++; }; }, [reload]);
  const document = state?.owner === owner && owner ? state.document : null;
  async function save(path: string, body: object) {
    if (!document || !owner) throw new Error('请先登录销售组并加载会员资料');
    if (busy.current) throw new Error('正在保存，请稍候');
    busy.current = true; setPending(true);
    const current = generation.current;
    try {
      const next = await apiRequest<Versioned<MembersDocument>>(path, {method: 'PUT', body: JSON.stringify({revision: document.revision, ...body})});
      if (current !== generation.current) throw new Error('账号已变更，请重新加载资料');
      setState({owner, document: next});
    } finally { if (current === generation.current) { busy.current = false; setPending(false); } }
  }
  return <MemberContext.Provider value={{members: document?.data.members ?? [], tiers: document?.data.tiers ?? [], owner,
    loading: loading || session.loading, pending, error, reload,
    updateMember: member => save(`/members/${encodeURIComponent(member.id)}`, {member}),
    updateTiers: tiers => save('/member-tiers', {tiers}), reset: () => {},
  }}>{children}</MemberContext.Provider>;
}
export function useMembers() {
  const value = useContext(MemberContext);
  if (!value) throw new Error("会员预览需要 MemberProvider");
  return value;
}
