import { useState, type FormEvent } from "react";
import { Link } from "react-router-dom";
import {
  ArrowRight,
  Eye,
  EyeOff,
  ArrowLeft,
  UserRound,
  CheckCircle2,
} from "lucide-react";
import { validEmail } from "./MemberContext";
import "./members.css";
import { apiEnabled } from '../api/client';
import { useSession } from '../api/SessionContext';

export default function AuthPage({ mode }: { mode: "login" | "register" }) {
  const register = mode === "register";
  const passwordMinimum = apiEnabled ? 12 : 8;
  const session = useSession();
  const [pending, setPending] = useState(false);
  const [form, setForm] = useState({
    email: "",
    name: "",
    company: "",
    password: "",
    confirm: "",
  });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState("");
  const [success, setSuccess] = useState(false);
  function change(key: keyof typeof form, value: string) {
    setForm((current) => ({ ...current, [key]: value }));
    setError("");
    setSuccess(false);
  }
  async function submit(event: FormEvent) {
    event.preventDefault();
    if (pending || (apiEnabled && session.loading)) return;
    setSuccess(false);
    if (!validEmail(form.email.trim())) {
      setError("请填写有效的邮箱地址");
      return;
    }
    if (register && !form.name.trim()) {
      setError("请填写联系人姓名");
      return;
    }
    if (
      register &&
      (form.password.length < passwordMinimum ||
        form.password.length > 128 ||
        !/[a-z]/i.test(form.password) ||
        !/\d/.test(form.password))
    ) {
      setError(`密码至少 ${passwordMinimum} 位，最多 128 位，需同时包含字母和数字`);
      return;
    }
    if (!form.password.trim()) {
      setError("请填写密码");
      return;
    }
    if (register && form.password !== form.confirm) {
      setError("两次密码不一致，请重新确认");
      return;
    }
    setError("");
    if (apiEnabled) {
      setPending(true);
      try {
        if (register) await session.register({ name: form.name.trim(), email: form.email.trim(), password: form.password, company: form.company.trim() });
        else await session.login({email: form.email.trim(), password: form.password});
        setForm(current => ({...current, password: '', confirm: ''}));
        setSuccess(true);
      } catch (err) { setError(err instanceof Error ? err.message : '登录失败，请重试'); }
      finally { setPending(false); }
      return;
    }
    setSuccess(true);
  }
  return (
    <div className="member-auth-page">
      <Link className="member-back" to="/quote">
        <ArrowLeft size={15} />
        返回报价页
      </Link>
      <div className="member-auth-shell">
        <aside className="member-auth-aside">
          <div className="member-kicker">KAKU / 会员服务</div>
          <h2>
            每一次印刷，
            <br />
            从这里开始。
          </h2>
          <p>
            为你的品牌与好创意，
            <br />
            留一个专属的位置。
          </p>
          <div className="member-paper-scene" aria-hidden="true">
            <div className="member-paper back" />
            <div className="member-paper front">
              <span>卡库云印</span>
              <i>KAKU CLOUD PRINT</i>
              <div />
              <small>用心制作 · 每一张</small>
            </div>
          </div>
          <div className="member-aside-bottom">
            <span>定制插卡</span>
            <span>纸张 / 工艺 / 报价</span>
          </div>
        </aside>
        <section className="member-auth-form">
          <div className="member-preview-tag">{apiEnabled ? '账号服务' : '页面预览'}</div>
          <h1>{register ? "注册会员" : "会员登录"}</h1>
          <p className="member-auth-intro">
            {apiEnabled ? (register ? '创建会员账号，保存订单与印刷资料。' : '使用会员或员工账号登录。') : register
              ? "填写基本资料，预览会员注册流程。"
              : "欢迎回来，预览账号登录流程。"}
          </p>
          <div className="member-preview-note">
            {apiEnabled ? '账号身份由服务器验证，登录后可查看对应的订单或管理工作台。' : '当前仅校验填写格式，不创建账号、不验证身份，也不保存密码。'}
          </div>
          <form noValidate onSubmit={submit}>
            <fieldset disabled={pending || (apiEnabled && session.loading)} style={{border:0,padding:0,margin:0,minWidth:0}}>
            <label className="member-field">
              邮箱
              <input
                type="email"
                autoComplete="email"
                placeholder="name@example.com"
                maxLength={254}
                value={form.email}
                onChange={(e) => change("email", e.target.value)}
                required
              />
            </label>
            {register && (
              <div className="member-form-grid">
                <label className="member-field">
                  联系人
                  <input
                    autoComplete="name"
                    placeholder="你的姓名"
                    maxLength={50}
                    value={form.name}
                    onChange={(e) => change("name", e.target.value)}
                    required
                  />
                </label>
                <label className="member-field">
                  公司名称 <span className="member-optional">选填</span>
                  <input
                    aria-label="公司名称"
                    autoComplete="organization"
                    placeholder="公司 / 工作室"
                    maxLength={100}
                    value={form.company}
                    onChange={(e) => change("company", e.target.value)}
                  />
                </label>
              </div>
            )}
            <label className="member-field">
              密码
              <div className="member-password-field">
                <input
                  aria-label="密码"
                  type={showPassword ? "text" : "password"}
                  autoComplete={register ? "new-password" : "current-password"}
                  placeholder={
                    register ? `至少 ${passwordMinimum} 位，最多 128 位，包含字母和数字` : "输入密码"
                  }
                  minLength={register ? passwordMinimum : undefined}
                  maxLength={128}
                  value={form.password}
                  onChange={(e) => change("password", e.target.value)}
                  required
                />
                <button
                  type="button"
                  aria-label={showPassword ? "隐藏密码" : "显示密码"}
                  onClick={() => setShowPassword((v) => !v)}
                >
                  {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                </button>
              </div>
            </label>
            {register && (
              <label className="member-field">
                确认密码
                <input
                  type={showPassword ? "text" : "password"}
                  autoComplete="new-password"
                  placeholder="再次输入密码"
                  minLength={passwordMinimum}
                  maxLength={128}
                  value={form.confirm}
                  onChange={(e) => change("confirm", e.target.value)}
                  required
                />
              </label>
            )}
            {error && (
              <p role="alert" className="member-message error">
                {error}
              </p>
            )}
            {success && (
              <p role="status" className="member-message success">
                <CheckCircle2 size={17} />
                {apiEnabled ? (register ? '注册成功，已登录。' : '登录成功。') : register
                  ? "注册资料校验通过；当前为页面预览，未创建账号。"
                  : "登录资料格式校验通过；尚未验证账号和密码，未登录。"}
              </p>
            )}
            <button type="submit" className="member-primary member-auth-submit">
              {pending ? '正在提交…' : apiEnabled ? (register ? '注册并登录' : '登录') : register ? "预览注册校验" : "预览登录校验"}
              <ArrowRight size={17} />
            </button>
            </fieldset>
          </form>
          {apiEnabled && session.user && <p><Link to={session.user.role === 'staff' ? '/admin' : '/orders'}>{session.user.role === 'staff' ? '进入员工工作台' : '我的订单'}</Link></p>}
          <div className="member-auth-switch">
            {register ? "已有账号？" : "还没有账号？"}
            <Link to={register ? "/login" : "/register"}>
              {register ? "前往登录" : "注册会员"}
            </Link>
          </div>
          <div className="member-auth-admin">
            <UserRound size={14} />
            <Link to={apiEnabled ? '/admin' : '/admin/members'}>{apiEnabled ? '员工管理入口' : '查看会员管理预览'}</Link>
          </div>
        </section>
      </div>
    </div>
  );
}
