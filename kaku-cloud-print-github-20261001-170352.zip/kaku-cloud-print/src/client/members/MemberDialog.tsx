import { useEffect, useRef, useState, type RefObject } from "react";
import { X } from "lucide-react";
import { useMembers, type MemberRecord } from "./MemberContext";
import { apiEnabled } from '../api/client';

export default function MemberDialog({
  member,
  onClose,
  onSaved,
  fallbackFocus,
}: {
  member: MemberRecord;
  onClose: () => void;
  onSaved: () => void;
  fallbackFocus: RefObject<HTMLInputElement | null>;
}) {
  const { tiers, updateMember, pending } = useMembers();
  const [draft, setDraft] = useState({ ...member });
  const [error, setError] = useState("");
  const ref = useRef<HTMLElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    ref.current?.querySelector<HTMLElement>("button")?.focus();
    const handle = (event: KeyboardEvent) => {
      if (event.key === "Escape" && !pending) {
        event.preventDefault();
        onClose();
      }
      if (event.key === "Tab") {
        const fields = ref.current?.querySelectorAll<HTMLElement>(
          "button, input, select, textarea",
        );
        if (!fields?.length) return;
        const first = fields[0],
          last = fields[fields.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", handle);
    return () => {
      document.removeEventListener("keydown", handle);
      if (previous?.isConnected) previous.focus();
      else fallbackFocus.current?.focus();
    };
  }, [onClose, fallbackFocus, pending]);
  function change<K extends keyof MemberRecord>(
    key: K,
    value: MemberRecord[K],
  ) {
    setDraft((current) => ({ ...current, [key]: value }));
    setError("");
  }
  return (
    <div
      className="member-modal-backdrop"
      onClick={(e) => {
        if (e.target === e.currentTarget && !pending) onClose();
      }}
    >
      <section
        className="member-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="member-dialog-title"
        ref={ref}
      >
        <header>
          <div>
            <span className="member-kicker">{member.id} / {apiEnabled ? '会员资料' : '演示资料'}</span>
            <h2 id="member-dialog-title">会员资料</h2>
          </div>
          <button
            aria-label="关闭会员资料"
            className="icon-button"
            disabled={pending}
            onClick={onClose}
          >
            <X size={20} />
          </button>
        </header>
        <p className="member-preview-note">
          {apiEnabled ? '保存后更新服务器会员资料、等级与账号状态。' : '修改仅在本次页面预览中生效，刷新后恢复演示数据。'}
        </p>
        <form
          noValidate
          onSubmit={(e) => {
            e.preventDefault();
            if (pending) return;
            const failure = (err: unknown) => setError(err instanceof Error ? err.message : '无法保存修改');
            try {
              const result = updateMember(draft);
              if (result) void result.then(onSaved, failure); else onSaved();
            } catch (err) {
              failure(err);
            }
          }}
        >
          <fieldset disabled={pending} style={{border:0,padding:0,margin:0,minWidth:0}}>
          <div className="member-form-grid">
            <label className="member-field">
              联系人
              <input
                value={draft.name}
                maxLength={50}
                onChange={(e) => change("name", e.target.value)}
              />
            </label>
            <label className="member-field">
              联系电话
              <input
                value={draft.phone}
                maxLength={20}
                placeholder="选填"
                onChange={(e) => change("phone", e.target.value)}
              />
            </label>
          </div>
          <label className="member-field">
            邮箱
            <input
              type="email"
              maxLength={254}
              value={draft.email}
              onChange={(e) => change("email", e.target.value)}
            />
          </label>
          <label className="member-field">
            公司名称
            <input
              maxLength={100}
              value={draft.company}
              onChange={(e) => change("company", e.target.value)}
            />
          </label>
          <div className="member-form-grid">
            <label className="member-field">
              会员等级
              <select
                value={draft.tierId}
                onChange={(e) => change("tierId", e.target.value)}
              >
                {tiers.map((t) => (
                  <option key={t.id} value={t.id}>
                    {t.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="member-account-toggle">
              <input
                type="checkbox"
                checked={draft.active}
                onChange={(e) => change("active", e.target.checked)}
              />
              启用账号
            </label>
          </div>
          <label className="member-field">
            备注
            <textarea
              value={draft.notes}
              maxLength={500}
              rows={3}
              onChange={(e) => change("notes", e.target.value)}
            />
          </label>
          {error && (
            <p role="alert" className="member-message error">
              {error}
            </p>
          )}
          <footer>
            <button
              className="button secondary"
              type="button"
              onClick={onClose}
            >
              取消
            </button>
            <button type="submit" className="member-primary">
              {pending ? '正在保存…' : apiEnabled ? '保存修改' : '保存预览修改'}
            </button>
          </footer>
          </fieldset>
        </form>
      </section>
    </div>
  );
}
