import { useCallback, useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowLeft,
  ArrowUpRight,
  Search,
  UsersRound,
  UserCheck,
  Layers3,
  ChevronLeft,
  ChevronRight,
  RotateCcw,
} from "lucide-react";
import { useMembers, type MemberRecord } from "./MemberContext";
import MemberDialog from "./MemberDialog";
import AdminSectionNav from "../AdminSectionNav";
import "./members.css";
import { apiEnabled } from '../api/client';

function TierEditor() {
  const { tiers, members, updateTiers, pending } = useMembers();
  const [draft, setDraft] = useState(() => structuredClone(tiers));
  const [notice, setNotice] = useState<{ error: boolean; text: string } | null>(
    null,
  );
  return (
    <section className="member-panel member-tier-panel">
      <div className="member-panel-heading">
        <div>
          <h2>会员等级与折扣</h2>
          <p>{apiEnabled ? '100% 表示原价，95% 表示九五折。保存后影响会员生产费用，设计和物流不打折。' : '100% 表示原价，95% 表示九五折。以下为演示设置，不影响前台报价。'}</p>
        </div>
        <span className="member-preview-tag">{apiEnabled ? '正式优惠规则' : '演示设置'}</span>
      </div>
      <form
        noValidate
        onSubmit={(e) => {
          e.preventDefault();
          if (pending) return;
          const success = () => setNotice({error: false, text: apiEnabled ? '等级设置已保存到服务器，后续报价按新规则计算。' : '等级预览已更新，未保存到服务器，也未应用到报价。'});
          const failure = (err: unknown) => setNotice({error: true, text: err instanceof Error ? err.message : '无法保存等级'});
          try {
            const result = updateTiers(draft);
            if (result) void result.then(success, failure); else success();
          } catch (err) {
            failure(err);
          }
        }}
      >
        <fieldset disabled={pending} style={{border:0,padding:0,margin:0,minWidth:0}}>
        <div className="member-tier-grid">
          {draft.map((tier, i) => (
            <article className="member-tier-card" key={tier.id}>
              <div className="member-tier-top">
                <Layers3 size={20} />
                <span>
                  {members.filter((m) => m.tierId === tier.id).length}{" "}
                  {apiEnabled ? '位会员' : '位演示会员'}
                </span>
              </div>
              <label className="member-field">
                等级名称
                <input
                  aria-label={`${tiers[i].name}名称`}
                  value={tier.name}
                  maxLength={30}
                  onChange={(e) => {
                    setDraft((current) =>
                      current.map((t) =>
                        t.id === tier.id ? { ...t, name: e.target.value } : t,
                      ),
                    );
                    setNotice(null);
                  }}
                />
              </label>
              <label className="member-field">
                价格折扣
                <div className="member-discount-field">
                  <input
                    aria-label={`${tiers[i].name}折扣`}
                    type="number"
                    min="0.01"
                    max="100"
                    step="0.01"
                    value={Number.isFinite(tier.discount) ? tier.discount : ""}
                    onChange={(e) => {
                      setDraft((current) =>
                        current.map((t) =>
                          t.id === tier.id
                            ? {
                                ...t,
                                discount:
                                  e.target.value === ""
                                    ? NaN
                                    : Number(e.target.value),
                              }
                            : t,
                        ),
                      );
                      setNotice(null);
                    }}
                  />
                  <span>%</span>
                </div>
              </label>
              <small>会员等级不代表管理员权限</small>
            </article>
          ))}
        </div>
        {notice && (
          <p
            className={`member-message ${notice.error ? "error" : "success"}`}
            role={notice.error ? "alert" : "status"}
          >
            {notice.text}
          </p>
        )}
        <footer className="member-tier-footer">
          <span>{apiEnabled ? '初始等级均为原价；只有明确保存后才变更优惠规则。' : '等级折扣仅供展示，正式优惠规则后续对接。'}</span>
          <button className="member-primary" type="submit">
            {pending ? '正在保存…' : apiEnabled ? '保存等级设置' : '保存等级预览'}
          </button>
        </footer>
        </fieldset>
      </form>
    </section>
  );
}

export default function MemberAdmin() {
  const {owner} = useMembers();
  return <MemberWorkspace key={owner} />;
}
function MemberWorkspace() {
  const { members, tiers, reset, loading, error, reload, owner, pending } = useMembers();
  const [tab, setTab] = useState<"members" | "tiers">("members");
  const [search, setSearch] = useState("");
  const [status, setStatus] = useState("all");
  const [tier, setTier] = useState("all");
  const [page, setPage] = useState(1);
  const [selected, setSelected] = useState<MemberRecord | null>(null);
  const [notice, setNotice] = useState("");
  const close = useCallback(() => setSelected(null), []);
  const searchRef = useRef<HTMLInputElement>(null);
  const query = search.trim().toLowerCase();
  const filtered = members.filter(
    (m) =>
      (status === "all" || (status === "active" ? m.active : !m.active)) &&
      (tier === "all" || m.tierId === tier) &&
      [m.id, m.name, m.email, m.company].some((v) =>
        v.toLowerCase().includes(query),
      ),
  );
  const pageSize = 6,
    totalPages = Math.max(1, Math.ceil(filtered.length / pageSize)),
    currentPage = Math.min(page, totalPages),
    rows = filtered.slice((currentPage - 1) * pageSize, currentPage * pageSize);
  function clear() {
    setSearch("");
    setTier("all");
    setStatus("all");
    setPage(1);
  }
  if (apiEnabled && loading) return <p role="status">正在读取会员资料…</p>;
  if (apiEnabled && !owner) return <p>请先使用销售组员工账号登录。</p>;
  if (apiEnabled && error) return <section><p role="alert">{error}</p><button onClick={() => void reload()}>重新加载会员资料</button></section>;
  return (
    <div className="member-admin-page">
      <div className="breadcrumb">
        <Link to="/quote">报价下单</Link>
        <ChevronRight size={12} />
        <b>会员管理</b>
      </div>
      <div className="page-heading">
        <div>
          <span className="eyebrow">MEMBER WORKSPACE</span>
          <h1>
            会员管理{!apiEnabled && <span className="member-heading-tag">预览</span>}
          </h1>
          <p>查看客户资料，维护会员等级与账号状态。</p>
        </div>
        <Link to="/quote" className="button secondary">
          <ArrowLeft size={15} />
          返回报价页
        </Link>
      </div>
      <AdminSectionNav />
      <div className="member-preview-banner">
        <div>
          <span className="member-preview-dot" />
          <b>{apiEnabled ? '服务器会员资料' : '演示数据 · 页面预览'}</b>
          <p>
            {apiEnabled ? '保存后立即生效。发生版本冲突时请保留修改内容，重新加载最新资料后再编辑。重新加载会放弃当前未保存的编辑。' : '以下资料均为合成示例。修改仅在当前页面会话中保留，刷新后重置；尚未接入真实会员服务。'}
          </p>
        </div>
        <button
          className="button secondary"
          disabled={pending}
          onClick={() => {
            if (apiEnabled) { setSelected(null); void reload(); return; }
            reset();
            clear();
            setSelected(null);
            setTab("members");
            setNotice("已恢复初始演示数据。");
          }}
        >
          <RotateCcw size={15} />
          {apiEnabled ? '重新加载会员资料' : '重置演示'}
        </button>
      </div>
      <div className="member-overview">
        <div>
          <UsersRound size={20} />
          <span>{apiEnabled ? '注册会员' : '演示会员'}</span>
          <strong>{members.length}</strong>
        </div>
        <div>
          <UserCheck size={20} />
          <span>启用账号</span>
          <strong>{members.filter((m) => m.active).length}</strong>
        </div>
        <div>
          <Layers3 size={20} />
          <span>会员等级</span>
          <strong>{tiers.length}</strong>
        </div>
      </div>
      <div
        className="member-section-tabs"
        role="tablist"
        aria-label="会员管理视图"
      >
        <button
          role="tab"
          aria-selected={tab === "members"}
          aria-controls="member-list-panel"
          onClick={() => {
            setTab("members");
            setNotice("");
          }}
        >
          会员列表
        </button>
        <button
          role="tab"
          aria-selected={tab === "tiers"}
          aria-controls="member-tiers-panel"
          onClick={() => {
            setTab("tiers");
            setNotice("");
          }}
        >
          会员等级
        </button>
        <Link to="/register">
          {apiEnabled ? '会员注册页' : '预览注册页'}
          <ArrowUpRight size={14} />
        </Link>
      </div>
      {notice && (
        <p role="status" className="member-message success">
          {notice}
        </p>
      )}
      {tab === "members" ? (
        <section
          className="member-panel"
          id="member-list-panel"
          role="tabpanel"
          aria-label="会员列表"
        >
          <div className="member-table-toolbar">
            <label className="member-search">
              <Search size={17} />
              <input
                type="search"
                ref={searchRef}
                aria-label="搜索会员"
                placeholder="搜索姓名、邮箱、公司或编号"
                value={search}
                onChange={(e) => {
                  setSearch(e.target.value);
                  setPage(1);
                }}
              />
            </label>
            <select
              aria-label="会员等级筛选"
              value={tier}
              onChange={(e) => {
                setTier(e.target.value);
                setPage(1);
              }}
            >
              <option value="all">全部等级</option>
              {tiers.map((t) => (
                <option key={t.id} value={t.id}>
                  {t.name}
                </option>
              ))}
            </select>
            <select
              aria-label="账号状态筛选"
              value={status}
              onChange={(e) => {
                setStatus(e.target.value);
                setPage(1);
              }}
            >
              <option value="all">全部状态</option>
              <option value="active">已启用</option>
              <option value="disabled">已停用</option>
            </select>
          </div>
          <div className="member-table-scroll">
            <table className="member-table">
              <thead>
                <tr>
                  <th>会员 / 联系人</th>
                  <th>邮箱 / 公司</th>
                  <th>会员等级</th>
                  <th>账号状态</th>
                  <th>注册日期</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((m) => (
                  <tr key={m.id}>
                    <td>
                      <div className="member-name-cell">
                        <span className="member-avatar">
                          {m.name.slice(-2)}
                        </span>
                        <div>
                          <b>{m.name}</b>
                          <small>{m.id}</small>
                        </div>
                      </div>
                    </td>
                    <td>
                      <span>{m.email}</span>
                      <small>{m.company || "未填写公司"}</small>
                    </td>
                    <td>
                      <span className={`member-tier-badge ${m.tierId}`}>
                        {tiers.find((t) => t.id === m.tierId)?.name}
                      </span>
                    </td>
                    <td>
                      <span
                        className={`member-status ${m.active ? "active" : "disabled"}`}
                      >
                        <i />
                        {m.active ? "已启用" : "已停用"}
                      </span>
                    </td>
                    <td className="member-date">{m.createdAt}</td>
                    <td>
                      <button
                        className="member-table-action"
                        aria-label={`查看 ${m.name}`}
                        onClick={() => {
                          setSelected(m);
                          setNotice("");
                        }}
                      >
                        查看 / 编辑
                        <ChevronRight size={13} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {!rows.length && (
            <div className="member-empty">
              <Search size={28} />
              <h3>没有符合条件的会员</h3>
              <p>试试其他关键词，或清除等级和状态筛选。</p>
              <button className="button secondary" onClick={clear}>
                清除筛选
              </button>
            </div>
          )}
          <footer className="member-pagination">
            <span>
              共 {filtered.length} {apiEnabled ? '位会员' : '位演示会员'} · 每页 {pageSize} 位
            </span>
            <div>
              <button
                aria-label="上一页"
                disabled={currentPage === 1}
                onClick={() => setPage(currentPage - 1)}
              >
                <ChevronLeft size={17} />
              </button>
              <span>
                {currentPage} / {totalPages}
              </span>
              <button
                aria-label="下一页"
                disabled={currentPage === totalPages}
                onClick={() => setPage(currentPage + 1)}
              >
                <ChevronRight size={17} />
              </button>
            </div>
          </footer>
        </section>
      ) : (
        <div id="member-tiers-panel" role="tabpanel" aria-label="会员等级">
          <TierEditor />
        </div>
      )}
      {selected && (
        <MemberDialog
          member={selected}
          fallbackFocus={searchRef}
          onClose={close}
          onSaved={() => {
            close();
            setNotice(apiEnabled ? '会员资料已保存到服务器。' : "会员预览已更新，未保存到服务器。");
          }}
        />
      )}
    </div>
  );
}
