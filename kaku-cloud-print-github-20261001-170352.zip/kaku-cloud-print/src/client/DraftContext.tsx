import {
  createContext,
  useContext,
  useEffect,
  useState,
  type Dispatch,
  type ReactNode,
  type SetStateAction,
} from "react";
import type { PricingConfig } from "../shared/contracts";
import { defaultConfig } from "../lib/config";

type DraftState = {
  draft: PricingConfig | null;
  setDraft: Dispatch<SetStateAction<PricingConfig | null>>;
  serverRevision: string | null;
  setServerRevision: Dispatch<SetStateAction<string | null>>;
  dirty: boolean;
  setDirty: Dispatch<SetStateAction<boolean>>;
};
const DraftContext = createContext<DraftState | null>(null);

export function DraftProvider({ children }: { children: ReactNode }) {
  const [draft, setDraft] = useState<PricingConfig | null>(null);
  const [dirty, setDirty] = useState(false);
  const [serverRevision, setServerRevision] = useState<string | null>(null);
  useEffect(() => {
    if (!dirty) return;
    const warn = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);
  return (
    <DraftContext.Provider
      value={{
        draft,
        setDraft,
        dirty,
        setDirty,
        serverRevision,
        setServerRevision,
      }}
    >
      {children}
    </DraftContext.Provider>
  );
}

export function usePricingDraft(deployed: PricingConfig | null) {
  const context = useContext(DraftContext);
  const [localDraft, setLocalDraft] = useState(() =>
    structuredClone(deployed ?? defaultConfig),
  );
  const [localDirty, setLocalDirty] = useState(false);
  const [localRevision, setLocalRevision] = useState<string | null>(null);
  const draft = context?.draft ?? localDraft;
  const setDraft: Dispatch<SetStateAction<PricingConfig>> = (value) => {
    if (context)
      context.setDraft((previous) =>
        typeof value === "function" ? value(previous ?? localDraft) : value,
      );
    else setLocalDraft(value);
  };
  return {
    draft,
    setDraft,
    serverRevision: context?.serverRevision ?? localRevision,
    setServerRevision: context?.setServerRevision ?? setLocalRevision,
    dirty: context?.dirty ?? localDirty,
    setDirty: context?.setDirty ?? setLocalDirty,
  };
}
