import { Link } from "react-router-dom";
import { useHomeContent } from "./content/HomeContentContext";
import HomeModuleView from "./content/HomeModules";
import "./home.css";
import { parseHomepage } from "../shared/homepage";
export default function HomePage({ preview = false }: { preview?: boolean }) {
  const { deployed, draft, loading } = useHomeContent();
  if (preview && loading)
    return (
      <section className="admin-access-message">
        <p role="status">正在读取首页配置…</p>
        <Link to="/admin/pages">返回页面管理</Link>
      </section>
    );
  if (preview) {
    try {
      parseHomepage(JSON.stringify(draft));
    } catch (error) {
      return (
        <section className="admin-access-message">
          <h1>草稿需要修正后再预览</h1>
          <p role="alert">
            {error instanceof Error ? error.message : "草稿格式无效。"}
          </p>
          <Link className="button primary" to="/admin/pages">
            返回页面管理
          </Link>
        </section>
      );
    }
  }
  const modules = (preview ? draft : deployed).modules.filter((m) => m.enabled);
  return (
    <div className="home-page">
      {preview && (
        <div className="cms-preview-bar">
          <strong>首页草稿预览</strong>
          <span>仅本地预览，尚未发布到服务器。</span>
          <Link to="/admin/pages">返回页面管理</Link>
        </div>
      )}
      {!modules.some((m) => m.type === "hero") && (
        <h1 className="cms-visually-hidden">卡库云印 · 多材质卡片定制</h1>
      )}
      {modules.map((m) => (
        <HomeModuleView
          key={m.id}
          module={m}
          first={m.id === modules.find((x) => x.type === "hero")?.id}
        />
      ))}
    </div>
  );
}
