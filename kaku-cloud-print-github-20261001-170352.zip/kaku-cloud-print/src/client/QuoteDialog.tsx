import { useEffect, useRef } from "react";
import { Download, Printer, X } from "lucide-react";
import type { AdminQuote, PricingConfig } from "../shared/contracts";
import { extraNames } from "../shared/catalog";
import { resolveMaterial } from "../lib/pricing";
import { money, download } from "./utils";
const craftNames = {
  foil: "热烫",
  texture: "压纹",
  emboss: "击凸",
  deboss: "压凹",
};
const designNames = {
  provided: "自备设计文件",
  adjust: "文件调整",
  custom: "定制设计",
};
export default function QuoteDialog({
  quote,
  config,
  onClose,
}: {
  quote: AdminQuote;
  config: PricingConfig;
  onClose: () => void;
}) {
  const dialogRef = useRef<HTMLElement>(null);
  useEffect(() => {
    const previous = document.activeElement as HTMLElement | null;
    dialogRef.current?.querySelector<HTMLElement>("button")?.focus();
    const keyHandler = (event: KeyboardEvent) => {
      if (event.key === "Escape") onClose();
      if (event.key === "Tab") {
        const nodes = dialogRef.current?.querySelectorAll<HTMLElement>(
          "button, a[href], input, select",
        );
        if (!nodes?.length) return;
        const first = nodes[0],
          last = nodes[nodes.length - 1];
        if (event.shiftKey && document.activeElement === first) {
          event.preventDefault();
          last.focus();
        } else if (!event.shiftKey && document.activeElement === last) {
          event.preventDefault();
          first.focus();
        }
      }
    };
    document.addEventListener("keydown", keyHandler);
    return () => {
      document.removeEventListener("keydown", keyHandler);
      previous?.focus();
    };
  }, [onClose]);
  const q = quote.input;
  const material = resolveMaterial(q, config);
  const rows = [
    ["产品", quote.product?.name ?? "定制插卡"],
    ...(quote.product
      ? [
          ["产品编号", quote.product.code],
          ["材质分类", quote.product.categoryName],
        ]
      : []),
    ["纸张", `${material.gsm}g ${material.name}`],
    ["尺寸", `${q.width} × ${q.height} mm`],
    [
      "印刷",
      `${q.sides === 2 ? "双面" : "单面"}${q.ink === "spot" ? "四色加1专" : "彩色"}`,
    ],
    ["数量", `${q.quantity} 张 × ${q.variants} 款`],
    [
      "工艺",
      [
        q.lamination ? `${q.lamination}面覆膜` : "不覆膜",
        q.cutting === "die" ? "异形模切" : "普通裁切",
        ...q.crafts.map((c) => craftNames[c]),
        ...q.extras.map((id) => extraNames[id]),
      ].join(" / "),
    ],
    [
      "每张烫金面积",
      q.crafts.includes("foil") ? String(q.foilArea) + " cm²" : "无",
    ],
    ["设计服务", designNames[q.design]],
    ["配送方式", q.shipping === "express" ? "快递配送" : "到店自提"],
    [
      "配送区域",
      q.shipping === "pickup"
        ? "不适用"
        : {
            local: "本地 / 省内",
            national: "国内常规地区",
            remote: "偏远地区",
          }[q.region],
    ],
    [
      "计费重量",
      q.shipping === "express" ? quote.weight.toFixed(3) + " kg" : "不适用",
    ],
    ["总张数", String(quote.totalQuantity)],
    ["制作费", money(quote.productionTotal)],
    ["设计费", money(quote.designTotal)],
    ["物流费", money(quote.shippingTotal)],
    ["合计（元）", money(quote.total)],
    ...(quote.quoteId
      ? [
          ["报价编号", quote.quoteId],
          [
            "会员计价",
            `${quote.tier} · 制作费 ${(quote.discount * 100).toFixed(2)}%`,
          ],
          ["报价有效至", new Date(quote.expiresAt!).toLocaleString("zh-CN")],
        ]
      : []),
    ["费用表版本", String(quote.version)],
    ["报价时间", new Date(quote.createdAt).toLocaleString("zh-CN")],
  ];
  return (
    <div
      className="modal-backdrop"
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <section
        ref={dialogRef}
        className="quote-dialog"
        role="dialog"
        aria-modal="true"
        aria-labelledby="quote-dialog-title"
      >
        <header>
          <div>
            <span className="eyebrow">KAKU CLOUD PRINT</span>
            <h2 id="quote-dialog-title">卡库云印 · 卡片报价单</h2>
          </div>
          <button
            className="icon-button"
            aria-label="关闭报价单"
            onClick={onClose}
          >
            <X size={20} />
          </button>
        </header>
        <dl>
          {rows.map(([k, v]) => (
            <div key={k}>
              <dt>{k}</dt>
              <dd>{v}</dd>
            </div>
          ))}
        </dl>
        <p>
          本单为规格报价，非生产订单。按满版合版条件测算，税费及其他未列费用须另行确认。
        </p>
        <footer>
          <button className="button secondary" onClick={() => window.print()}>
            <Printer size={15} />
            打印
          </button>
          <button
            className="button primary"
            onClick={() =>
              download(
                "\uFEFF" +
                  rows
                    .map((row) =>
                      row
                        .map(
                          (v) =>
                            '"' +
                            (/^\s*[=+@-]/.test(v) ? "'" + v : v).replace(
                              /"/g,
                              '""',
                            ) +
                            '"',
                        )
                        .join(","),
                    )
                    .join("\r\n"),
                "卡库云印-卡片报价单.csv",
              )
            }
          >
            <Download size={15} />
            下载报价单
          </button>
        </footer>
      </section>
    </div>
  );
}
