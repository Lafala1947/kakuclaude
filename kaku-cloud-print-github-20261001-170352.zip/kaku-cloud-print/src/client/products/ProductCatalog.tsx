import { useState } from "react";
import { Link, useParams } from "react-router-dom";
import { ArrowUpRight, ArrowLeft, Search } from "lucide-react";
import { useProducts } from "./ProductsContext";
import {
  parseProducts,
  type Product,
  type ProductDocument,
} from "../../shared/products";
import CardArtwork from "../content/CardArtwork";
export function ProductImage({ product: p }: { product: Product }) {
  const [broken, setBroken] = useState(false);
  return p.image && !broken ? (
    <div className="catalog-image">
      <img
        src={
          p.image.startsWith("assets/")
            ? `${import.meta.env.BASE_URL}${p.image}`
            : p.image
        }
        alt={p.imageAlt}
        loading="lazy"
        onError={() => setBroken(true)}
      />
    </div>
  ) : (
    <CardArtwork kind={p.artwork} />
  );
}
export function ProductCards({
  data,
  featured = false,
  preview = false,
}: {
  data: ProductDocument;
  featured?: boolean;
  preview?: boolean;
}) {
  const products = data.products.filter(
    (p) => p.active && (!featured || p.featured),
  );
  return (
    <div className="catalog-grid">
      {products.map((p) => (
        <article className="catalog-card" key={p.id}>
          <ProductImage product={p} />
          <div className="catalog-card-content">
            <span className="catalog-category">
              {data.categories.find((c) => c.id === p.categoryId)?.name}
            </span>
            <h2>{p.name}</h2>
            <p>{p.summary}</p>
            <div className="home-product-tags">
              {p.tags
                .split("、")
                .filter(Boolean)
                .map((t, i) => (
                  <span key={i}>{t}</span>
                ))}
            </div>
            {preview ? (
              <p className="catalog-detail-copy">{p.description}</p>
            ) : (
              <Link to={`/products/${p.id}`}>
                查看产品 <ArrowUpRight size={17} />
              </Link>
            )}
            {preview && (
              <small>
                {p.quoteMode === "paper"
                  ? "纸质卡片通用报价"
                  : "报价待人工确认"}
              </small>
            )}
          </div>
        </article>
      ))}
    </div>
  );
}
export function FeaturedProducts() {
  const { deployed, loading } = useProducts();
  if (loading) return <p className="admin-muted">正在读取产品…</p>;
  if (!deployed)
    return <p className="admin-muted">产品信息暂不可用，请稍后刷新。</p>;
  if (!deployed.products.some((p) => p.active && p.featured))
    return <p className="admin-muted">暂无推荐产品。</p>;
  return <ProductCards data={deployed} featured />;
}
export default function ProductCatalog({
  preview = false,
  detail = false,
}: {
  preview?: boolean;
  detail?: boolean;
}) {
  const { deployed, draft, loading, editing, categoryEditing } = useProducts();
  const { productId } = useParams();
  const [search, setSearch] = useState(""),
    [category, setCategory] = useState("");
  if (loading)
    return (
      <section className="catalog-page">
        <p role="status">正在读取产品配置…</p>
      </section>
    );
  if (preview && (editing || categoryEditing))
    return (
      <section className="admin-access-message">
        <h1>请先保存产品或分类资料</h1>
        <Link to="/admin/products">返回产品管理</Link>
      </section>
    );
  const data = preview ? draft : deployed;
  if (!data)
    return (
      <section className="catalog-page product-empty">
        <h1>产品信息暂不可用</h1>
        <p>请稍后刷新页面查看。</p>
        <Link to="/">返回首页</Link>
      </section>
    );
  if (preview) {
    try {
      parseProducts(JSON.stringify(data));
    } catch {
      return (
        <section className="catalog-page">
          <h1>产品草稿需要修正</h1>
          <Link to="/admin/products">返回产品管理</Link>
        </section>
      );
    }
  }
  const product = detail
    ? data.products.find((p) => p.id === productId && p.active)
    : null;
  if (detail && !product)
    return (
      <section className="catalog-page product-empty">
        <h1>产品不存在或已下架</h1>
        <Link to="/products">返回产品中心</Link>
      </section>
    );
  if (product)
    return (
      <section className="catalog-page">
        <Link className="catalog-back" to="/products">
          <ArrowLeft size={16} />
          返回产品中心
        </Link>
        <div className="catalog-detail">
          <ProductImage key={product.image} product={product} />
          <div>
            <span className="admin-kicker">
              {data.categories.find((c) => c.id === product.categoryId)?.name} /{" "}
              {product.code}
            </span>
            <h1>{product.name}</h1>
            <p className="catalog-summary">{product.summary}</p>
            <p className="catalog-detail-copy">{product.description}</p>
            <div className="home-product-tags">
              {product.tags
                .split("、")
                .filter(Boolean)
                .map((t, i) => (
                  <span key={i}>{t}</span>
                ))}
            </div>
            {product.quoteMode === "paper" ? (
              <>
                <Link className="button primary" to={`/quote?product=${encodeURIComponent(product.id)}`}>
                  纸质卡片通用报价 <ArrowUpRight size={17} />
                </Link>
                <p className="admin-muted">
                  进入后会关联当前产品，请按实际需求选择规格和工艺。产品资料不预设报价参数。
                </p>
              </>
            ) : (
              <p className="catalog-inquiry">
                此产品暂不支持在线报价，需人工确认材质、规格与工艺。
              </p>
            )}
          </div>
        </div>
      </section>
    );
  const shown = {
    ...data,
    products: data.products.filter(
      (p) =>
        (!category || p.categoryId === category) &&
        `${p.name} ${p.summary} ${p.tags}`
          .toLowerCase()
          .includes(search.trim().toLowerCase()),
    ),
  };
  return (
    <section className="catalog-page">
      {preview && (
        <div className="cms-preview-bar">
          <strong>产品草稿预览</strong>
          <span>只显示草稿中已上架的产品，尚未发布。</span>
          <Link to="/admin/products">返回产品管理</Link>
        </div>
      )}
      <header className="workspace-heading">
        <div>
          <span className="admin-kicker">KAKU / CARD COLLECTION</span>
          <h1>{preview ? "产品目录预览" : "产品中心"}</h1>
          <p>按材质与用途，寻找适合你的卡片方案。</p>
        </div>
      </header>
      <div className="catalog-filter">
        <label className="product-search">
          <Search size={17} />
          <input
            type="search"
            aria-label="搜索展示产品"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="搜索产品名称或用途"
          />
        </label>
        <label>
          产品分类
          <select
            aria-label="展示产品分类"
            value={category}
            onChange={(e) => setCategory(e.target.value)}
          >
            <option value="">全部材质</option>
            {data.categories.map((c) => (
              <option value={c.id} key={c.id}>
                {c.name}
              </option>
            ))}
          </select>
        </label>
      </div>
      {shown.products.some((p) => p.active) ? (
        <ProductCards data={shown} preview={preview} />
      ) : (
        <div className="product-empty">
          <h2>暂无可展示产品</h2>
          <p>请调整筛选条件或稍后查看。</p>
        </div>
      )}
    </section>
  );
}
