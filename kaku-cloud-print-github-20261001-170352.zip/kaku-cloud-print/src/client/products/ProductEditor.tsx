import { useEffect, useRef, useState } from "react";
import {
  parseProducts,
  type Product,
  type ProductDocument,
} from "../../shared/products";
import { message } from "../utils";
export default function ProductEditor({
  product,
  document,
  onChange,
  onSave,
  onCancel,
}: {
  product: Product;
  document: ProductDocument;
  onChange: (p: Product) => void;
  onSave: (d: ProductDocument) => void;
  onCancel: () => void;
}) {
  const [error, setError] = useState(""),
    [discard, setDiscard] = useState(false);
  const nameRef = useRef<HTMLInputElement>(null);
  useEffect(() => {
    nameRef.current?.focus();
  }, [product.id]);
  const category = document.categories.find((c) => c.id === product.categoryId);
  function patch(value: Partial<Product>) {
    onChange({ ...product, ...value });
    setError("");
    setDiscard(false);
  }
  function text(
    label: string,
    field:
      | "code"
      | "name"
      | "summary"
      | "description"
      | "image"
      | "imageAlt"
      | "tags",
    max: number,
    multi = false,
  ) {
    return (
      <label className="cms-field">
        {label}
        {multi ? (
          <textarea
            rows={field === "description" ? 5 : 2}
            maxLength={max}
            value={product[field]}
            onChange={(e) => patch({ [field]: e.target.value })}
          />
        ) : (
          <input
            ref={field === "name" ? nameRef : undefined}
            maxLength={max}
            value={product[field]}
            onChange={(e) => patch({ [field]: e.target.value })}
          />
        )}
      </label>
    );
  }
  return (
    <section className="product-edit-panel" aria-label="产品编辑">
      <div className="cms-list-heading">
        <h2>
          {document.products.some((p) => p.id === product.id)
            ? "编辑产品"
            : "新增产品"}
        </h2>
        <span className="admin-muted">先保存资料，再保存或导出产品草稿</span>
      </div>
      <form
        noValidate
        onSubmit={(e) => {
          e.preventDefault();
          try {
            const exists = document.products.some((p) => p.id === product.id);
            const next = parseProducts(
              JSON.stringify({
                ...document,
                products: exists
                  ? document.products.map((p) =>
                      p.id === product.id ? product : p,
                    )
                  : [...document.products, product],
              }),
            );
            onSave(next);
          } catch (err) {
            setError(message(err));
          }
        }}
      >
        <div className="cms-field-grid">
          {text("产品编号", "code", 50)}
          {text("产品名称", "name", 100)}
        </div>
        <div className="cms-field-grid">
          <label className="cms-field">
            材质分类
            <select
              value={product.categoryId}
              onChange={(e) =>
                patch({
                  categoryId: e.target.value,
                  quoteMode:
                    document.categories.find((c) => c.id === e.target.value)
                      ?.material === "paper"
                      ? product.quoteMode
                      : "inquiry",
                })
              }
            >
              {document.categories.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name}
                </option>
              ))}
            </select>
          </label>
          <label className="cms-field">
            报价方式
            <select
              value={product.quoteMode}
              onChange={(e) =>
                patch({ quoteMode: e.target.value as Product["quoteMode"] })
              }
            >
              <option value="inquiry">仅展示，报价待人工确认</option>
              {category?.material === "paper" && (
                <option value="paper">纸质卡片通用报价</option>
              )}
            </select>
          </label>
        </div>
        <p className="admin-muted">
          产品编号使用字母、数字、横线或下划线。纸卡报价入口使用现有报价页，规格和工艺需由客户重新选择；此处不设置价格。
        </p>
        {text("产品简介", "summary", 300, true)}
        {text("产品详细说明", "description", 5000, true)}
        <div className="cms-field-grid">
          {text("产品图片地址", "image", 1000)}
          {text("产品图片说明", "imageAlt", 300)}
        </div>
        <p className="admin-muted">
          图片可填 assets/文件名.svg 或 HTTPS
          地址，需另行上传。留空时使用下方的卡片版式示意。
        </p>
        <div className="cms-field-grid">
          <label className="cms-field">
            默认示意图
            <select
              value={product.artwork}
              onChange={(e) =>
                patch({ artwork: e.target.value as Product["artwork"] })
              }
            >
              <option value="insert">包装插卡</option>
              <option value="thanks">品牌感谢卡</option>
              <option value="shape">异形卡片</option>
            </select>
          </label>
          {text("产品标签（用顿号分隔）", "tags", 300)}
        </div>
        <div className="product-switches">
          <label>
            <input
              type="checkbox"
              checked={product.active}
              onChange={(e) => patch({ active: e.target.checked })}
            />
            上架展示
          </label>
          <label>
            <input
              type="checkbox"
              checked={product.featured}
              onChange={(e) => patch({ featured: e.target.checked })}
            />
            首页推荐
          </label>
        </div>
        {error && (
          <p className="cms-notice error" role="alert">
            {error}
          </p>
        )}
        <div className="cms-toolbar">
          <button className="button primary" type="submit">
            保存产品到草稿
          </button>
          <button
            className="button secondary"
            type="button"
            onClick={() => setDiscard(true)}
          >
            取消编辑
          </button>
        </div>
        {discard && (
          <div className="cms-confirm">
            <p>放弃本次未保存的产品资料？</p>
            <button className="button danger" type="button" onClick={onCancel}>
              放弃本次编辑
            </button>
            <button
              className="button secondary"
              type="button"
              onClick={() => setDiscard(false)}
            >
              继续编辑
            </button>
          </div>
        )}
      </form>
    </section>
  );
}
