import { apiEnabled } from "../api/client";
import ServerPublishControls from "../content/ServerPublishControls";
import { useRef, useState } from "react";
import { Link } from "react-router-dom";
import {
  ArrowUp,
  ArrowDown,
  Download,
  Eye,
  Plus,
  Save,
  Upload,
  Search,
} from "lucide-react";
import {
  emptyProduct,
  parseProducts,
  serializeProducts,
  productId,
  PRODUCT_MAX_BYTES,
  type Product,
  type ProductDocument,
} from "../../shared/products";
import { useProducts } from "./ProductsContext";
import ProductEditor from "./ProductEditor";
import CategoryEditor from "./CategoryEditor";
import AdminSectionNav from "../AdminSectionNav";
import { download, message } from "../utils";
export default function ProductAdmin() {
  const {
    draft,
    deployed,
    setDraft,
    save,
    loading,
    notice,
    dirty,
    publish,
    reload,
    saving,
    canPublish,
    editing,
    setEditing,
    categoryEditing,
  } = useProducts();
  const [search, setSearch] = useState(""),
    [category, setCategory] = useState(""),
    [status, setStatus] = useState("all"),
    [categoriesOpen, setCategoriesOpen] = useState(categoryEditing !== null);
  const [feedback, setFeedback] = useState<{
      error: boolean;
      text: string;
    } | null>(null),
    [deleting, setDeleting] = useState<string | null>(null),
    [imported, setImported] = useState<ProductDocument | null>(null),
    [reset, setReset] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null),
    importSequence = useRef(0);
  const busy =
    loading || saving || editing !== null || categoryEditing !== null;
  const filtered = search.trim() !== "" || category !== "" || status !== "all";
  const products = draft.products.filter(
    (p) =>
      (!category || p.categoryId === category) &&
      (status === "all" || p.active === (status === "active")) &&
      `${p.name} ${p.code} ${p.tags}`
        .toLowerCase()
        .includes(search.trim().toLowerCase()),
  );
  function update(next: ProductDocument) {
    setDraft(next);
    setFeedback(null);
  }
  function attempt(action: () => void, text: string) {
    try {
      action();
      setFeedback({ error: false, text });
    } catch (e) {
      setFeedback({ error: true, text: message(e) });
    }
  }
  function move(p: Product, delta: number) {
    const next = [...draft.products],
      i = next.findIndex((x) => x.id === p.id);
    [next[i], next[i + delta]] = [next[i + delta], next[i]];
    update({ ...draft, products: next });
  }
  function begin(p: Product) {
    setImported(null);
    setDeleting(null);
    setReset(false);
    setEditing(structuredClone(p));
    setFeedback(null);
  }
  return (
    <div className="admin-workspace product-admin">
      <AdminSectionNav />
      <header className="workspace-heading">
        <div>
          <span className="admin-kicker">PRODUCT CATALOG / 页面组</span>
          <h1>产品管理</h1>
          <p>维护产品资料与展示状态，按材质组织卡片业务。</p>
        </div>
        {busy ? (
          <button className="button secondary" disabled>
            <Eye size={16} />
            预览产品草稿
          </button>
        ) : (
          <Link className="button secondary" to="/admin/products/preview">
            <Eye size={16} />
            预览产品草稿
          </Link>
        )}
      </header>
      <div className="cms-publish-bar">
        <b>产品资料独立管理，价格由价格组维护</b>
        <span className="cms-save-state">
          {dirty ? "有未保存的修改" : "草稿未修改"}
        </span>
        <p>
          {apiEnabled
            ? "编辑和上下架先作用于草稿；完成产品和分类编辑并加入草稿后，点击发布到服务器更新公开产品中心与首页目录。"
            : "编辑和上下架先作用于草稿；下载 products.json 并上传覆盖网站同名文件后，才更新公开产品中心与首页产品目录。"}
        </p>
        <div className="cms-toolbar">
          {apiEnabled && publish && reload && (
            <ServerPublishControls
              publish={publish}
              reload={reload}
              disabled={!!busy}
              canPublish={canPublish}
            />
          )}
          <button
            className="button secondary"
            disabled={busy}
            onClick={() => fileRef.current?.click()}
          >
            <Upload size={16} />
            导入产品配置
          </button>
          <button
            className="button secondary"
            disabled={busy}
            onClick={() =>
              attempt(save, "产品草稿已保存在此浏览器，尚未发布。")
            }
          >
            <Save size={16} />
            保存产品草稿
          </button>
          <button
            className="button primary"
            disabled={busy}
            onClick={() =>
              attempt(
                () =>
                  download(
                    serializeProducts(draft),
                    "products.json",
                    "application/json;charset=utf-8",
                  ),
                apiEnabled
                  ? "产品配置备份已下载，尚未发布。"
                  : "产品配置已下载，请上传 products.json 后发布。",
              )
            }
          >
            <Download size={16} />
            下载产品配置
          </button>
          <button
            className="product-text-button"
            disabled={busy || !deployed}
            onClick={() => setReset(true)}
          >
            恢复已发布产品
          </button>
        </div>
      </div>
      <input
        type="file"
        ref={fileRef}
        className="cms-visually-hidden"
        disabled={busy}
        accept=".json,application/json"
        aria-label="导入产品配置文件"
        onChange={async (e) => {
          const file = e.target.files?.[0];
          e.target.value = "";
          if (!file) return;
          const seq = ++importSequence.current;
          setImported(null);
          try {
            if (file.size > PRODUCT_MAX_BYTES)
              throw new Error("产品配置不能超过 1 MB。");
            const parsed = parseProducts(await file.text());
            if (seq === importSequence.current) {
              setImported(parsed);
              setFeedback(null);
            }
          } catch (err) {
            if (seq === importSequence.current)
              setFeedback({ error: true, text: message(err) });
          }
        }}
      />
      {notice && (
        <p className="cms-notice" role="status">
          {notice}
        </p>
      )}
      {feedback && (
        <p
          className={`cms-notice ${feedback.error ? "error" : ""}`}
          role={feedback.error ? "alert" : "status"}
        >
          {feedback.text}
        </p>
      )}
      {imported && (
        <div className="cms-confirm" role="alert">
          <p>
            导入 {imported.products.length} 个产品、{imported.categories.length}{" "}
            个分类，将替换当前产品草稿。
          </p>
          <button
            className="button primary"
            disabled={busy}
            onClick={() => {
              update(imported);
              setImported(null);
              setCategory("");
              setSearch("");
              setStatus("all");
            }}
          >
            确认导入产品
          </button>
          <button
            className="button secondary"
            onClick={() => {
              importSequence.current++;
              setImported(null);
            }}
          >
            取消导入
          </button>
        </div>
      )}
      {reset && (
        <div className="cms-confirm">
          <p>用已发布产品替换当前草稿？</p>
          <button
            className="button danger"
            disabled={busy || !deployed}
            onClick={() => {
              if (deployed) {
                update(structuredClone(deployed));
                setCategory("");
                setSearch("");
                setStatus("all");
                setReset(false);
              }
            }}
          >
            确认恢复产品
          </button>
          <button className="button secondary" onClick={() => setReset(false)}>
            取消
          </button>
        </div>
      )}
      {loading ? (
        <p role="status">正在读取产品配置…</p>
      ) : (
        <>
          <div className="product-summary">
            <div>
              <strong>{draft.products.length}</strong>
              <span>全部产品</span>
            </div>
            <div>
              <strong>{draft.products.filter((p) => p.active).length}</strong>
              <span>草稿中上架</span>
            </div>
            <div>
              <strong>
                {draft.products.filter((p) => p.active && p.featured).length}
              </strong>
              <span>上架且推荐</span>
            </div>
            <div>
              <strong>{draft.categories.length}</strong>
              <span>材质分类</span>
            </div>
          </div>
          <div className="product-filters">
            <label className="product-search">
              <Search size={17} />
              <input
                type="search"
                aria-label="搜索产品"
                placeholder="搜索名称、编号或标签"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </label>
            <label>
              分类
              <select
                aria-label="产品分类筛选"
                value={category}
                onChange={(e) => setCategory(e.target.value)}
              >
                <option value="">全部分类</option>
                {draft.categories.map((c) => (
                  <option key={c.id} value={c.id}>
                    {c.name}
                  </option>
                ))}
              </select>
            </label>
            <label>
              状态
              <select
                aria-label="产品状态筛选"
                value={status}
                onChange={(e) => setStatus(e.target.value)}
              >
                <option value="all">全部状态</option>
                <option value="active">上架</option>
                <option value="inactive">下架</option>
              </select>
            </label>
            <button
              className="button secondary"
              onClick={() => setCategoriesOpen(!categoriesOpen)}
              disabled={categoryEditing !== null}
            >
              管理分类
            </button>
            <button
              className="button primary"
              disabled={busy || draft.products.length >= 500}
              onClick={() => begin(emptyProduct(draft.categories[0].id))}
            >
              <Plus size={16} />
              新增产品
            </button>
          </div>
          {categoriesOpen && (
            <CategoryEditor
              document={draft}
              disabled={loading || editing !== null}
              onChange={(next) => {
                update(next);
                if (!next.categories.some((c) => c.id === category))
                  setCategory("");
              }}
            />
          )}
          {editing && (
            <ProductEditor
              key={editing.id}
              product={editing}
              document={draft}
              onChange={setEditing}
              onCancel={() => setEditing(null)}
              onSave={(next) => {
                update(next);
                setEditing(null);
                setFeedback({
                  error: false,
                  text: "产品资料已加入草稿，请保存本地草稿或下载配置。",
                });
              }}
            />
          )}
          {deleting && (
            <div className="cms-confirm" role="alert">
              <p>
                删除产品“{draft.products.find((p) => p.id === deleting)?.name}
                ”？此操作先修改草稿。
              </p>
              <button
                className="button danger"
                disabled={busy}
                onClick={() => {
                  update({
                    ...draft,
                    products: draft.products.filter((p) => p.id !== deleting),
                  });
                  setDeleting(null);
                }}
              >
                确认删除产品
              </button>
              <button
                className="button secondary"
                onClick={() => setDeleting(null)}
              >
                取消删除
              </button>
            </div>
          )}
          <div className="product-list-heading">
            <span>共 {products.length} 个匹配产品</span>
            <span>
              {filtered
                ? "清除筛选后可调整全局展示顺序。"
                : "列表顺序即前台展示顺序。"}
            </span>
          </div>
          <div className="product-table-wrap">
            <table className="product-table">
              <thead>
                <tr>
                  <th>产品资料</th>
                  <th>材质分类</th>
                  <th>草稿状态</th>
                  <th>展示顺序</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                {products.map((p) => {
                  const i = draft.products.indexOf(p);
                  return (
                    <tr key={p.id}>
                      <td>
                        <b>{p.name}</b>
                        <small>{p.code}</small>
                        <p>{p.summary}</p>
                      </td>
                      <td>
                        {
                          draft.categories.find((c) => c.id === p.categoryId)
                            ?.name
                        }
                        <small>
                          {p.quoteMode === "paper" ? "纸卡通用报价" : "仅展示"}
                        </small>
                      </td>
                      <td>
                        <span
                          className={`product-status ${p.active ? "active" : ""}`}
                        >
                          {p.active ? "上架" : "下架"}
                        </span>
                        {p.featured && <small>首页推荐</small>}
                      </td>
                      <td>
                        <div className="cms-icon-actions">
                          <button
                            disabled={busy || filtered || i === 0}
                            aria-label={`上移 ${p.name}`}
                            onClick={() => move(p, -1)}
                          >
                            <ArrowUp size={16} />
                          </button>
                          <button
                            disabled={
                              busy ||
                              filtered ||
                              i === draft.products.length - 1
                            }
                            aria-label={`下移 ${p.name}`}
                            onClick={() => move(p, 1)}
                          >
                            <ArrowDown size={16} />
                          </button>
                        </div>
                      </td>
                      <td>
                        <div className="product-row-actions">
                          <button
                            disabled={busy}
                            aria-label={`编辑 ${p.name}`}
                            onClick={() => begin(p)}
                          >
                            编辑
                          </button>
                          <button
                            disabled={busy}
                            aria-label={`${p.active ? "下架" : "上架"} ${p.name}`}
                            onClick={() =>
                              update({
                                ...draft,
                                products: draft.products.map((x) =>
                                  x.id === p.id
                                    ? { ...x, active: !x.active }
                                    : x,
                                ),
                              })
                            }
                          >
                            {p.active ? "下架" : "上架"}
                          </button>
                          <button
                            disabled={busy || draft.products.length >= 500}
                            aria-label={`复制 ${p.name}`}
                            onClick={() => {
                              let n = 1,
                                code = "";
                              do {
                                code = `${p.code.slice(0, 38)}-COPY${n++}`;
                              } while (
                                draft.products.some(
                                  (x) =>
                                    x.code.toLowerCase() === code.toLowerCase(),
                                )
                              );
                              begin({
                                ...p,
                                id: productId(),
                                code,
                                name: `${p.name.slice(0, 96)}副本`,
                                active: false,
                              });
                            }}
                          >
                            复制
                          </button>
                          <button
                            disabled={busy}
                            aria-label={`删除 ${p.name}`}
                            onClick={() => setDeleting(p.id)}
                          >
                            删除
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
            {products.length === 0 && (
              <div className="product-empty">
                <h2>暂无匹配产品</h2>
                <p>
                  {draft.products.length
                    ? "调整搜索或筛选条件。"
                    : "点击“新增产品”添加第一款卡片。"}
                </p>
              </div>
            )}
          </div>
        </>
      )}
    </div>
  );
}
