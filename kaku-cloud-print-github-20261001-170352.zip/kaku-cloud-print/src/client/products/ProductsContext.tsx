import { apiEnabled } from "../api/client";
import { useServerConfigDraft } from "../content/useServerConfigDraft";
import {
  createContext,
  useContext,
  useEffect,
  useRef,
  useState,
  type ReactNode,
} from "react";
import {
  defaultProducts,
  parseProducts,
  serializeProducts,
  type ProductDocument,
  type Product,
  type ProductCategory,
} from "../../shared/products";
const KEY = "kaku-products-draft-v1";
const Context = createContext<{
  deployed: ProductDocument | null;
  draft: ProductDocument;
  setDraft: (d: ProductDocument) => void;
  save: () => void;
  publish?: () => Promise<void>;
  reload?: () => Promise<void>;
  saving?: boolean;
  canPublish?: boolean;
  loading: boolean;
  notice: string;
  dirty: boolean;
  editing: Product | null;
  setEditing: (p: Product | null) => void;
  categoryEditing: ProductCategory | null;
  setCategoryEditing: (c: ProductCategory | null) => void;
}>({
  deployed: null,
  draft: defaultProducts,
  setDraft: () => {},
  save: () => {},
  loading: true,
  notice: "",
  dirty: false,
  editing: null,
  setEditing: () => {},
  categoryEditing: null,
  setCategoryEditing: () => {},
});
function StaticProductsProvider({ children }: { children: ReactNode }) {
  const [deployed, setDeployed] = useState<ProductDocument | null>(null),
    [draft, setDraftState] = useState<ProductDocument>(defaultProducts);
  const [loading, setLoading] = useState(true),
    [notice, setNotice] = useState(""),
    [saved, setSaved] = useState(() => JSON.stringify(defaultProducts));
  const [editing, setEditing] = useState<Product | null>(null);
  const [categoryEditing, setCategoryEditing] =
    useState<ProductCategory | null>(null);
  const hasDraft = useRef(false);
  const dirty =
    JSON.stringify(draft) !== saved ||
    editing !== null ||
    categoryEditing !== null;
  useEffect(() => {
    if (!dirty) return;
    const warn = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [dirty]);
  useEffect(() => {
    let active = true;
    const controller = new AbortController(),
      timeout = setTimeout(() => controller.abort(), 10000);
    const messages: string[] = [];
    try {
      const raw = localStorage.getItem(KEY);
      if (raw) {
        const value = parseProducts(raw);
        setDraftState(value);
        setSaved(JSON.stringify(value));
        hasDraft.current = true;
      }
    } catch {
      messages.push("本地产品草稿无法读取，原始数据未覆盖。");
    }
    async function load() {
      try {
        const response = await fetch(
          `${import.meta.env.BASE_URL}products.json?t=${Date.now()}`,
          { cache: "no-store", signal: controller.signal },
        );
        if (!response.ok) throw new Error("读取失败");
        const value = parseProducts(await response.text());
        if (active) {
          setDeployed(value);
          if (!hasDraft.current) {
            setDraftState(structuredClone(value));
            setSaved(JSON.stringify(value));
          }
        }
      } catch {
        messages.push(
          "已发布产品配置无法读取，公开产品列表暂不可用。编辑器使用本地草稿或初始模板，可导入备份修复。",
        );
      } finally {
        clearTimeout(timeout);
        if (active) {
          setNotice(messages.join(" "));
          setLoading(false);
        }
      }
    }
    void load();
    return () => {
      active = false;
      clearTimeout(timeout);
      controller.abort();
    };
  }, []);
  function setDraft(value: ProductDocument) {
    hasDraft.current = true;
    setDraftState(value);
  }
  function save() {
    localStorage.setItem(KEY, serializeProducts(draft));
    setSaved(JSON.stringify(draft));
    hasDraft.current = true;
  }
  return (
    <Context.Provider
      value={{
        deployed,
        draft,
        setDraft,
        save,
        loading,
        notice,
        dirty,
        editing,
        setEditing,
        categoryEditing,
        setCategoryEditing,
      }}
    >
      {children}
    </Context.Provider>
  );
}
export const useProducts = () => useContext(Context);

export function ProductsProvider({ children }: { children: ReactNode }) {
  return apiEnabled ? (
    <ServerProductsProvider>{children}</ServerProductsProvider>
  ) : (
    <StaticProductsProvider>{children}</StaticProductsProvider>
  );
}
function ServerProductsProvider({ children }: { children: ReactNode }) {
  const state = useServerConfigDraft(
    "/config/products",
    KEY,
    defaultProducts,
    parseProducts,
    serializeProducts,
  );
  const [editing, setEditing] = useState<Product | null>(null);
  const [categoryEditing, setCategoryEditing] =
    useState<ProductCategory | null>(null);
  useEffect(() => {
    if (!editing && !categoryEditing) return;
    const warn = (e: BeforeUnloadEvent) => {
      e.preventDefault();
      e.returnValue = "";
    };
    window.addEventListener("beforeunload", warn);
    return () => window.removeEventListener("beforeunload", warn);
  }, [editing, categoryEditing]);
  return (
    <Context.Provider
      value={{
        ...state,
        dirty: state.dirty || editing !== null || categoryEditing !== null,
        editing,
        setEditing,
        categoryEditing,
        setCategoryEditing,
      }}
    >
      {children}
    </Context.Provider>
  );
}
