import { useState } from "react";
import {
  parseProducts,
  productId,
  type ProductCategory,
  type ProductDocument,
} from "../../shared/products";
import { message } from "../utils";
import { useProducts } from "./ProductsContext";
export default function CategoryEditor({
  document,
  onChange,
  disabled,
}: {
  document: ProductDocument;
  onChange: (d: ProductDocument) => void;
  disabled: boolean;
}) {
  const { categoryEditing: editing, setCategoryEditing: setEditing } =
    useProducts();
  const [error, setError] = useState(""),
    [deleting, setDeleting] = useState<string | null>(null);
  function save() {
    if (!editing) return;
    try {
      const exists = document.categories.some((c) => c.id === editing.id);
      onChange(
        parseProducts(
          JSON.stringify({
            ...document,
            categories: exists
              ? document.categories.map((c) =>
                  c.id === editing.id ? editing : c,
                )
              : [...document.categories, editing],
          }),
        ),
      );
      setEditing(null);
      setError("");
    } catch (e) {
      setError(message(e));
    }
  }
  return (
    <section className="product-category-panel">
      <div className="cms-list-heading">
        <h2>材质分类</h2>
        <button
          className="button secondary"
          disabled={
            disabled || editing !== null || document.categories.length >= 50
          }
          onClick={() => {
            setEditing({ id: productId(), name: "", material: "other" });
            setDeleting(null);
            setError("");
          }}
        >
          新增分类
        </button>
      </div>
      <p className="admin-muted">
        分类有产品使用时不能删除。非纸质分类只提供产品展示，不使用纸卡报价。
      </p>
      <div className="product-category-list">
        {document.categories.map((c) => (
          <div key={c.id}>
            <div>
              <b>{c.name}</b>
              <span>
                {c.material === "paper" ? "纸质" : "其他材质"} ·{" "}
                {document.products.filter((p) => p.categoryId === c.id).length}{" "}
                个产品
              </span>
            </div>
            <button
              disabled={disabled || editing !== null}
              onClick={() => {
                setEditing({ ...c });
                setDeleting(null);
                setError("");
              }}
            >
              编辑分类 {c.name}
            </button>
            <button
              disabled={disabled || editing !== null}
              onClick={() => {
                if (document.products.some((p) => p.categoryId === c.id)) {
                  setError("此分类仍有产品使用，请先移动或删除这些产品。");
                  return;
                }
                if (document.categories.length === 1) {
                  setError("至少保留一个材质分类。");
                  return;
                }
                setDeleting(c.id);
                setError("");
              }}
            >
              删除分类 {c.name}
            </button>
          </div>
        ))}
      </div>
      {error && (
        <p role="alert" className="cms-notice error">
          {error}
        </p>
      )}
      {editing && (
        <div className="product-category-editor">
          <div className="cms-field-grid">
            <label className="cms-field">
              分类名称
              <input
                maxLength={60}
                value={editing.name}
                onChange={(e) =>
                  setEditing({ ...editing, name: e.target.value })
                }
              />
            </label>
            <label className="cms-field">
              分类材质类型
              <select
                value={editing.material}
                onChange={(e) =>
                  setEditing({
                    ...editing,
                    material: e.target.value as ProductCategory["material"],
                  })
                }
              >
                <option value="paper">纸质卡片</option>
                <option value="other">其他材质（仅展示）</option>
              </select>
            </label>
          </div>
          <div className="cms-toolbar">
            <button
              className="button primary"
              disabled={disabled}
              onClick={save}
            >
              保存分类到草稿
            </button>
            <button
              className="button secondary"
              onClick={() => setEditing(null)}
            >
              取消分类编辑
            </button>
          </div>
        </div>
      )}
      {deleting && (
        <div className="cms-confirm">
          <p>
            删除分类“{document.categories.find((c) => c.id === deleting)?.name}
            ”？
          </p>
          <button
            className="button danger"
            disabled={disabled}
            onClick={() => {
              try {
                onChange(
                  parseProducts(
                    JSON.stringify({
                      ...document,
                      categories: document.categories.filter(
                        (c) => c.id !== deleting,
                      ),
                    }),
                  ),
                );
                setDeleting(null);
              } catch (e) {
                setError(message(e));
              }
            }}
          >
            确认删除分类
          </button>
          <button
            className="button secondary"
            onClick={() => setDeleting(null)}
          >
            取消
          </button>
        </div>
      )}
    </section>
  );
}
