import {Link,useSearchParams} from 'react-router-dom';
import type {PricingConfig,ProductReference} from '../../shared/contracts';
import QuotePage from '../QuotePage';
import {useProducts} from './ProductsContext';
export default function ProductQuoteRoute({config}:{config:PricingConfig}){
 const [query]=useSearchParams();const {deployed,loading}=useProducts();const ids=query.getAll('product');
 if(!ids.length)return <QuotePage key="general" config={config}/>;
 if(ids.length!==1||!/^[a-zA-Z0-9_-]{1,100}$/.test(ids[0]))return <section className="admin-access-message"><h1>产品参数无效</h1><p>请从产品中心重新选择产品。</p><Link to="/products">返回产品中心</Link></section>;
 if(loading)return <div className="loading-state" role="status">正在核对产品资料…</div>;
 if(!deployed)return <section className="admin-access-message"><h1>产品资料暂不可用</h1><p>无法核对产品的最新状态，请稍后刷新。</p><Link to="/products">返回产品中心</Link></section>;
 const product=deployed.products.find(p=>p.id===ids[0]);const category=deployed.categories.find(c=>c.id===product?.categoryId);
 if(!product?.active||product.quoteMode!=='paper'||category?.material!=='paper')return <section className="admin-access-message"><h1>该产品暂不可报价</h1><p>产品不存在、已下架或暂不支持在线报价，请返回产品中心选择。</p><Link to="/products">返回产品中心</Link></section>;
 const reference:ProductReference={id:product.id,code:product.code,name:product.name,categoryId:category.id,categoryName:category.name};
 return <QuotePage key={product.id} config={config} product={reference}/>;
}
