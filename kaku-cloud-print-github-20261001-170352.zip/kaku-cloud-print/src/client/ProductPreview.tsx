import { Check, Layers, Maximize2, PackageCheck } from "lucide-react";
import { useState } from "react";
import type { QuoteInput } from "../shared/contracts";

export default function ProductPreview({ input }: { input: QuoteInput }) {
  const [variant, setVariant] = useState(0);
  return (
    <aside className="product-aside">
      <div
        className={`product-art theme-${variant}`}
        role="img"
        aria-label="插卡设计示意：品牌感谢卡与异形卡片"
      >
        <div className="art-grid" />
        <span className="art-label">
          A LITTLE CARD.
          <br />A LASTING IMPRESSION.
        </span>
        <div className="sample-card card-back">
          <span className="mini-sun">✳</span>
          <span>
            GOOD THINGS
            <br />
            TAKE SHAPE.
          </span>
          <i>特别的心意，值得被看见。</i>
        </div>
        <div
          className={`sample-card card-front ${input.cutting === "die" ? "die-shape" : ""}`}
        >
          <span className="sample-stamp">MADE WITH CARE</span>
          <span className="card-flower">✳</span>
          <strong>
            Thank
            <br />
            you.
          </strong>
          <span className="sample-bottom">
            谢谢你，选择我们。
            <br />
            <i>A little note, just for you.</i>
          </span>
        </div>
        <div className="art-caption">
          <span>定制插卡</span>
          <span>让品牌，多一点温度 ↗</span>
        </div>
      </div>
      <div className="art-thumbnails" aria-label="样式预览">
        {["品牌感谢卡", "自然绿", "暖橘色"].map((name, i) => (
          <button
            key={i}
            title={name}
            aria-label={`预览${name}`}
            aria-pressed={variant === i}
            onClick={() => setVariant(i)}
            className={`thumb thumb-${i} ${variant === i ? "selected" : ""}`}
          >
            <span>
              Thank
              <br />
              you.
            </span>
          </button>
        ))}
        <span>
          效果示意
          <br />
          非印刷稿
        </span>
      </div>
      <div className="product-caption">
        <h2>小小一张，心意满满</h2>
        <p>
          包装插卡、品牌感谢卡、活动宣传卡，
          <br />
          让每一次开箱都有你的品牌印记。
        </p>
      </div>
      <div className="product-benefits">
        <div>
          <Layers />
          <span>
            <b>多种工艺</b>
            <small>覆膜 · 模切 · 烫金 · 凹凸</small>
          </span>
        </div>
        <div>
          <Maximize2 />
          <span>
            <b>尺寸随心定</b>
            <small>预设尺寸或自定义长宽</small>
          </span>
        </div>
        <div>
          <PackageCheck />
          <span>
            <b>按需计算</b>
            <small>规格、数量、工艺费用清晰</small>
          </span>
        </div>
      </div>
      <div className="paper-note">
        <Check size={14} />
        <span>按所选规格计算，报价单可下载留存</span>
      </div>
    </aside>
  );
}
