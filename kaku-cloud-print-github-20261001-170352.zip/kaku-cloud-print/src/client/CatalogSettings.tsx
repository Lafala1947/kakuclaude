import type { PricingConfig } from "../shared/contracts";
import { extraGroups, feeUnits, type ExtraFee } from "../shared/catalog";

function FeeEditor({
  name,
  fee,
  onChange,
  coating = false,
}: {
  name: string;
  fee: ExtraFee;
  onChange: (fee: ExtraFee) => void;
  coating?: boolean;
}) {
  return (
    <div className="catalog-fee-row">
      <label className="catalog-enabled">
        <input
          aria-label={`启用${name}`}
          type="checkbox"
          checked={fee.enabled}
          onChange={(e) => onChange({ ...fee, enabled: e.target.checked })}
        />
        <span>{name}</span>
      </label>
      <label>
        <span>加工单价</span>
        <input
          aria-label={`${name}加工单价`}
          type="number"
          min="0"
          step="0.0001"
          placeholder="待配置"
          value={fee.rate ?? ""}
          onChange={(e) =>
            onChange({
              ...fee,
              rate: e.target.value === "" ? null : Number(e.target.value),
            })
          }
        />
      </label>
      <label>
        <span>计价单位</span>
        <select
          aria-label={`${name}计价单位`}
          value={fee.unit}
          onChange={(e) =>
            onChange({ ...fee, unit: e.target.value as ExtraFee["unit"] })
          }
        >
          {Object.entries(feeUnits)
            .filter(([value]) => coating || value !== "sheetAreaSide")
            .map(([value, label]) => (
              <option value={value} key={value}>
                {label}
              </option>
            ))}
        </select>
      </label>
      <label>
        <span>每单起版 / 起步费</span>
        <input
          aria-label={`${name}起步费`}
          type="number"
          min="0"
          step="0.01"
          value={Number.isFinite(fee.setup) ? fee.setup : ""}
          onChange={(e) =>
            onChange({
              ...fee,
              setup: e.target.value === "" ? NaN : Number(e.target.value),
            })
          }
        />
      </label>
      <span
        className={`catalog-state ${fee.enabled && fee.rate !== null ? "configured" : ""}`}
      >
        {!fee.enabled ? "未启用" : fee.rate === null ? "待配置" : "已配置"}
      </span>
    </div>
  );
}

export default function CatalogSettings({
  group,
  config,
  onChange,
}: {
  group: string;
  config: PricingConfig;
  onChange: (c: PricingConfig) => void;
}) {
  if (group === "paper")
    return (
      <section className="catalog-settings">
        <h3>其他可选材料</h3>
        <p>基础材料沿用上方纸张参数。新增材料未填写吨价前不参与报价。</p>
        {Object.entries(config.materials).map(([id, item]) => (
          <div className="material-fee-row" key={id}>
            <label className="catalog-enabled">
              <input
                aria-label={`启用${item.name}`}
                type="checkbox"
                checked={item.enabled}
                onChange={(e) =>
                  onChange({
                    ...config,
                    materials: {
                      ...config.materials,
                      [id]: { ...item, enabled: e.target.checked },
                    },
                  })
                }
              />
              <span>{item.name}</span>
            </label>
            <div className="admin-fields">
              <label className="admin-field">
                <span>材料名称</span>
                <input
                  aria-label={`${item.name}名称`}
                  value={item.name}
                  onChange={(e) =>
                    onChange({
                      ...config,
                      materials: {
                        ...config.materials,
                        [id]: { ...item, name: e.target.value },
                      },
                    })
                  }
                />
              </label>
              <label className="admin-field">
                <span>克重（g/㎡）</span>
                <input
                  aria-label={`${item.name}克重`}
                  type="number"
                  min="1"
                  value={Number.isFinite(item.gsm) ? item.gsm : ""}
                  onChange={(e) =>
                    onChange({
                      ...config,
                      materials: {
                        ...config.materials,
                        [id]: {
                          ...item,
                          gsm:
                            e.target.value === ""
                              ? NaN
                              : Number(e.target.value),
                        },
                      },
                    })
                  }
                />
              </label>
              <label className="admin-field">
                <span>采购吨价（元/吨）</span>
                <input
                  aria-label={`${item.name}吨价`}
                  type="number"
                  min="0"
                  step="0.01"
                  placeholder="待配置"
                  value={item.tonPrice ?? ""}
                  onChange={(e) =>
                    onChange({
                      ...config,
                      materials: {
                        ...config.materials,
                        [id]: {
                          ...item,
                          tonPrice:
                            e.target.value === ""
                              ? null
                              : Number(e.target.value),
                        },
                      },
                    })
                  }
                />
              </label>
            </div>
          </div>
        ))}
      </section>
    );
  if (group === "printing")
    return (
      <section className="catalog-settings">
        <h3>四色加 1 专</h3>
        <p>以下为现有彩色印刷费用之外的专色附加费。</p>
        <FeeEditor
          name="四色加1专"
          fee={config.spotInk}
          onChange={(spotInk) => onChange({ ...config, spotInk })}
        />
      </section>
    );
  if (group !== "finishing") return null;
  return (
    <section className="catalog-settings">
      <h3>产品页扩展工艺</h3>
      <p>
        勾选启用并填写加工单价后可选；单价填 0
        表示明确免费。新增费用不是原参考站价格。
      </p>
      {extraGroups.map((g) => (
        <div className="catalog-group" key={g.id}>
          <h4>{g.label}</h4>
          {g.id === "coating" && (
            <p>
              同一订单只能选择一种覆膜/过油；选择后替代基础覆膜费用，不重复计算。加工面数由前台选择。
            </p>
          )}
          {g.id === "common" && (
            <p>
              高品质模切作为基础模切费之外的附加费。其他工艺按下方单位计费。
            </p>
          )}
          {g.id === "shape" && (
            <p>圆形 / 圆角触发一次基础模切版与加工费，下方为附加费用。</p>
          )}
          {g.items.map(([id, name]) => (
            <FeeEditor
              key={id}
              coating={g.id === "coating"}
              name={name}
              fee={config.extras[id]}
              onChange={(fee) =>
                onChange({ ...config, extras: { ...config.extras, [id]: fee } })
              }
            />
          ))}
        </div>
      ))}
      <div className="formula-note">
        <b>单位说明</b>
        <p>
          “成品张 / 成品㎡”按含损耗加工数量计；“大纸张 /
          大纸㎡”按分摊款数均摊；“单”整单一次；“款”按购买款数。“起步费”每单加一次。先核对试算，再导出发布。
        </p>
      </div>
    </section>
  );
}
